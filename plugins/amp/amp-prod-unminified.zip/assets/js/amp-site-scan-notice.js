/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 184:
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2018 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
	'use strict';

	var hasOwn = {}.hasOwnProperty;

	function classNames() {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg)) {
				if (arg.length) {
					var inner = classNames.apply(null, arg);
					if (inner) {
						classes.push(inner);
					}
				}
			} else if (argType === 'object') {
				if (arg.toString === Object.prototype.toString) {
					for (var key in arg) {
						if (hasOwn.call(arg, key) && arg[key]) {
							classes.push(key);
						}
					}
				} else {
					classes.push(arg.toString());
				}
			}
		}

		return classes.join(' ');
	}

	if ( true && module.exports) {
		classNames.default = classNames;
		module.exports = classNames;
	} else if (true) {
		// register as 'classnames', consistent with npm package name
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return classNames;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else {}
}());


/***/ }),

/***/ 703:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = __webpack_require__(414);

function emptyFunction() {}
function emptyFunctionWithReset() {}
emptyFunctionWithReset.resetWarningCache = emptyFunction;

module.exports = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      // It is still safe when called from React.
      return;
    }
    var err = new Error(
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
    err.name = 'Invariant Violation';
    throw err;
  };
  shim.isRequired = shim;
  function getShim() {
    return shim;
  };
  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,

    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };

  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ 697:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (false) { var throwOnDirectAccess, ReactIs; } else {
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = __webpack_require__(703)();
}


/***/ }),

/***/ 414:
/***/ (function(module) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
!function() {
"use strict";

;// CONCATENATED MODULE: external ["wp","element"]
var external_wp_element_namespaceObject = window["wp"]["element"];
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
;// CONCATENATED MODULE: external "ampSiteScanNotice"
var external_ampSiteScanNotice_namespaceObject = ampSiteScanNotice;
;// CONCATENATED MODULE: external ["wp","domReady"]
var external_wp_domReady_namespaceObject = window["wp"]["domReady"];
var external_wp_domReady_default = /*#__PURE__*/__webpack_require__.n(external_wp_domReady_namespaceObject);
;// CONCATENATED MODULE: external ["wp","i18n"]
var external_wp_i18n_namespaceObject = window["wp"]["i18n"];
;// CONCATENATED MODULE: ./assets/src/components/error-context-provider/index.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


const ErrorContext = (0,external_wp_element_namespaceObject.createContext)();
/**
 * Error context provider.
 *
 * @param {Object} props          Component props.
 * @param {any}    props.children Component children.
 */

function ErrorContextProvider(_ref) {
  let {
    children
  } = _ref;
  const [error, setError] = (0,external_wp_element_namespaceObject.useState)(null);
  return (0,external_wp_element_namespaceObject.createElement)(ErrorContext.Provider, {
    value: {
      error,
      setError
    }
  }, children);
}
;// CONCATENATED MODULE: external ["wp","apiFetch"]
var external_wp_apiFetch_namespaceObject = window["wp"]["apiFetch"];
var external_wp_apiFetch_default = /*#__PURE__*/__webpack_require__.n(external_wp_apiFetch_namespaceObject);
;// CONCATENATED MODULE: external ["wp","url"]
var external_wp_url_namespaceObject = window["wp"]["url"];
;// CONCATENATED MODULE: ./assets/src/utils/use-async-error.js
/**
 * WordPress dependencies
 */

/**
 * The error boundary component doesn't automatically catch errors in async functions.
 * This allows errors to be explicitly thrown.
 */

function useAsyncError() {
  const [error, setAsyncError] = (0,external_wp_element_namespaceObject.useState)();
  const memoizedSetError = (0,external_wp_element_namespaceObject.useCallback)(e => {
    setAsyncError(() => {
      throw e;
    });
  }, []);
  return {
    error,
    setAsyncError: memoizedSetError
  };
}
;// CONCATENATED MODULE: ./assets/src/components/options-context-provider/index.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const Options = (0,external_wp_element_namespaceObject.createContext)();
/**
 * Returns a promise that resolves after one second.
 */

function waitASecond() {
  return new Promise(resolve => {
    setTimeout(resolve, 1000);
  });
}
/**
 * Context provider for options retrieval and updating.
 *
 * @param {Object}  props                       Component props.
 * @param {?any}    props.children              Component children.
 * @param {string}  props.optionsRestPath       REST endpoint to retrieve options.
 * @param {boolean} props.populateDefaultValues Whether default values should be populated.
 * @param {boolean} props.hasErrorBoundary      Whether the component is wrapped in an error boundary.
 * @param {boolean} props.delaySave             Whether to delay updating state when saving data.
 */


function OptionsContextProvider(_ref) {
  let {
    children,
    optionsRestPath,
    populateDefaultValues,
    hasErrorBoundary = false,
    delaySave = false
  } = _ref;
  const [updates, setUpdates] = (0,external_wp_element_namespaceObject.useState)({});
  const [fetchingPluginSuppression, setFetchingPluginSuppression] = (0,external_wp_element_namespaceObject.useState)(false);
  const [fetchingOptions, setFetchingOptions] = (0,external_wp_element_namespaceObject.useState)(null);
  const [savedOptions, setSavedOptions] = (0,external_wp_element_namespaceObject.useState)({});
  const [savingOptions, setSavingOptions] = (0,external_wp_element_namespaceObject.useState)(false);
  const [didSaveOptions, setDidSaveOptions] = (0,external_wp_element_namespaceObject.useState)(false);
  const [originalOptions, setOriginalOptions] = (0,external_wp_element_namespaceObject.useState)({});
  const [modifiedOptions, setModifiedOptions] = (0,external_wp_element_namespaceObject.useState)({});
  const {
    error,
    setError
  } = (0,external_wp_element_namespaceObject.useContext)(ErrorContext);
  const {
    setAsyncError
  } = useAsyncError();
  const [readerModeWasOverridden, setReaderModeWasOverridden] = (0,external_wp_element_namespaceObject.useState)(false); // This component sets state inside async functions. Use this ref to prevent state updates after unmount.

  const hasUnmounted = (0,external_wp_element_namespaceObject.useRef)(false);
  (0,external_wp_element_namespaceObject.useEffect)(() => () => {
    hasUnmounted.current = true;
  }, []);
  /**
   * Fetches plugin suppression data.
   */

  const refetchPluginSuppression = (0,external_wp_element_namespaceObject.useCallback)(() => {
    if (error || fetchingPluginSuppression) {
      return;
    }
    /**
     * Fetches suppression data from the REST endpoint.
     */


    (async () => {
      setFetchingPluginSuppression(true);

      try {
        const fetchedPluginSuppression = await external_wp_apiFetch_default()({
          path: (0,external_wp_url_namespaceObject.addQueryArgs)(optionsRestPath, {
            _fields: ['suppressed_plugins', 'suppressible_plugins']
          })
        });

        if (true === hasUnmounted.current) {
          return;
        }

        setOriginalOptions({ ...originalOptions,
          ...fetchedPluginSuppression
        });
      } catch (e) {
        if (true === hasUnmounted.current) {
          return;
        }

        setError(e);

        if (hasErrorBoundary) {
          setAsyncError(e);
        }

        return;
      }

      setFetchingPluginSuppression(false);
    })();
  }, [error, fetchingPluginSuppression, hasErrorBoundary, optionsRestPath, originalOptions, setAsyncError, setError]);
  /**
   * Fetches options.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (error || Object.keys(originalOptions).length || fetchingOptions) {
      return;
    }
    /**
     * Fetches plugin options from the REST endpoint.
     */


    (async () => {
      setFetchingOptions(true);

      try {
        const fetchedOptions = await external_wp_apiFetch_default()({
          path: optionsRestPath
        });

        if (true === hasUnmounted.current) {
          return;
        }

        if (!populateDefaultValues && fetchedOptions.plugin_configured === false) {
          fetchedOptions.mobile_redirect = true;
          fetchedOptions.reader_theme = null;
          fetchedOptions.theme_support = null;
        }

        setOriginalOptions(fetchedOptions);
      } catch (e) {
        if (true === hasUnmounted.current) {
          return;
        }

        setError(e);

        if (hasErrorBoundary) {
          setAsyncError(e);
        }

        return;
      }

      setFetchingOptions(false);
    })();
  }, [error, fetchingOptions, hasErrorBoundary, originalOptions, optionsRestPath, populateDefaultValues, setAsyncError, setError]);
  /**
   * Sends options to the REST endpoint to be saved.
   *
   * @param {Object} data Plugin options to update.
   */

  const saveOptions = (0,external_wp_element_namespaceObject.useCallback)(async () => {
    setSavingOptions(true);

    try {
      const updatesToSave = { ...updates
      }; // If the reader theme was set to null on initialization (i.e., this is the first time through the wizard
      // and reader mode was selected), remove it from the updates.

      if (null === updatesToSave.reader_theme) {
        delete updatesToSave.reader_theme;
      } // If this is the first time running the wizard and mobile_redirect is not in updates, set mobile_redirect to true.
      // We do this here instead of in the fetch effect to prevent the exit confirmation before the user has interacted.


      if (!originalOptions.plugin_configured && !('mobile_redirect' in updatesToSave)) {
        updatesToSave.mobile_redirect = originalOptions.mobile_redirect;
      }

      if (!originalOptions.plugin_configured) {
        updatesToSave.plugin_configured = true;
      } // Ensure this promise lasts at least a second so that the "Saving Options" load screen is
      // visible long enough for the user to see it is happening.


      const [retrievedOptions] = await Promise.all([external_wp_apiFetch_default()({
        method: 'post',
        path: optionsRestPath,
        data: updatesToSave
      }), delaySave ? waitASecond() : () => undefined]);

      if (true === hasUnmounted.current) {
        return;
      }

      setOriginalOptions(retrievedOptions);
      setError(null);
    } catch (e) {
      if (true === hasUnmounted.current) {
        return;
      }

      setSavingOptions(false);
      setError(e);

      if (hasErrorBoundary) {
        setAsyncError(e);
      }

      return;
    }

    setModifiedOptions({ ...modifiedOptions,
      ...updates
    });
    setSavedOptions(updates);
    setUpdates({});
    setDidSaveOptions(true);
    setSavingOptions(false);
  }, [delaySave, hasErrorBoundary, optionsRestPath, setAsyncError, originalOptions, setError, updates, modifiedOptions]);
  /**
   * Updates options in state.
   *
   * @param {Object} newOptions Updated options values.
   */

  const updateOptions = (0,external_wp_element_namespaceObject.useCallback)(newOptions => {
    setUpdates({ ...updates,
      ...newOptions
    });
    setDidSaveOptions(false);
  }, [updates]); // Allows an item in the updates object to be removed.

  const unsetOption = (0,external_wp_element_namespaceObject.useCallback)(option => {
    const newOptions = { ...updates
    };
    delete newOptions[option];
    setUpdates(newOptions);
  }, [updates]);
  return (0,external_wp_element_namespaceObject.createElement)(Options.Provider, {
    value: {
      editedOptions: { ...originalOptions,
        ...updates
      },
      fetchingOptions,
      hasOptionsChanges: Boolean(Object.keys(updates).length),
      didSaveOptions,
      updates,
      originalOptions,
      saveOptions,
      savedOptions,
      savingOptions,
      unsetOption,
      updateOptions,
      readerModeWasOverridden,
      refetchPluginSuppression,
      setReaderModeWasOverridden,
      modifiedOptions
    }
  }, children);
}
;// CONCATENATED MODULE: ./assets/src/components/plugins-context-provider/index.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




const Plugins = (0,external_wp_element_namespaceObject.createContext)();
/**
 * Plugins context provider.
 *
 * @param {Object} props          Component props.
 * @param {any}    props.children Component children.
 */

function PluginsContextProvider(_ref) {
  let {
    children
  } = _ref;
  const [plugins, setPlugins] = (0,external_wp_element_namespaceObject.useState)([]);
  const [fetchingPlugins, setFetchingPlugins] = (0,external_wp_element_namespaceObject.useState)(null);
  const [error, setError] = (0,external_wp_element_namespaceObject.useState)();
  /**
   * This component sets state inside async functions.
   * Use this ref to prevent state updates after unmount.
   */

  const hasUnmounted = (0,external_wp_element_namespaceObject.useRef)(false);
  (0,external_wp_element_namespaceObject.useEffect)(() => () => {
    hasUnmounted.current = true;
  }, []);
  /**
   * Fetches validated URL data.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (error || plugins.length > 0 || fetchingPlugins) {
      return;
    }

    (async () => {
      setFetchingPlugins(true);

      try {
        const fetchedPlugins = await external_wp_apiFetch_default()({
          path: (0,external_wp_url_namespaceObject.addQueryArgs)('/wp/v2/plugins', {
            _fields: ['author', 'name', 'plugin', 'status', 'version']
          })
        });

        if (hasUnmounted.current === true) {
          return;
        }

        setPlugins(fetchedPlugins);
      } catch (e) {
        if (hasUnmounted.current === true) {
          return;
        }

        setError(e);
      }

      setFetchingPlugins(false);
    })();
  }, [error, fetchingPlugins, plugins]);
  return (0,external_wp_element_namespaceObject.createElement)(Plugins.Provider, {
    value: {
      fetchingPlugins,
      plugins
    }
  }, children);
}
;// CONCATENATED MODULE: ./assets/src/common/constants.js
// See https://github.com/ampproject/amphtml/blob/e7a1b3ff97645ec0ec482192205134bd0735943c/extensions/amp-fit-text/0.1/amp-fit-text.js#L81-L85
const MIN_FONT_SIZE = 6;
const MAX_FONT_SIZE = 72;
const FILE_TYPE_ERROR_VIEW = 'select-file-type-error';
const READER = 'reader';
const STANDARD = 'standard';
const TRANSITIONAL = 'transitional';
const DEFAULT_MOBILE_BREAKPOINT = 783;
;// CONCATENATED MODULE: ./assets/src/common/helpers/get-plugin-slug-from-file.js
/**
 * Get plugin slug from file path.
 *
 * If the plugin file is in a directory, then the slug is just the directory name. Otherwise, if the file is not
 * inside of a directory and is just a single-file plugin, then the slug is the filename of the PHP file.
 *
 * If the file path contains a file extension, it will be stripped as well.
 *
 * See the corresponding PHP logic in `\AmpProject\AmpWP\get_plugin_slug_from_file()`.
 *
 * @param {string} path Plugin file path.
 * @return {string} Plugin slug.
 */
function getPluginSlugFromFile() {
  let path = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  return path.replace(/\/.*$/, '').replace(/\.php$/, '');
}
;// CONCATENATED MODULE: ./assets/src/components/site-scan-context-provider/get-sources-from-scannable-urls.js
/**
 * Internal dependencies
 */

/**
 * From an array of scannable URLs, get plugin and theme slugs along with URLs for which AMP validation errors occur.
 *
 * See the corresponding PHP logic in `\AMP_Validated_URL_Post_Type::render_sources_column()`.
 *
 * @param {Array}   scannableUrls      Array of scannable URLs.
 * @param {Object}  options            Additional options object.
 * @param {boolean} options.useAmpUrls Whether to return `amp_url` instead of the regular URL in the lists of sources.
 * @return {Object} An object consisting of `plugins` and `themes` arrays.
 */

function getSourcesFromScannableUrls() {
  let scannableUrls = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  let {
    useAmpUrls = false
  } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  const plugins = new Map();
  const themes = new Map();

  for (const scannableUrl of scannableUrls) {
    const {
      amp_url: ampUrl,
      url,
      validation_errors: validationErrors
    } = scannableUrl;

    if (!(validationErrors !== null && validationErrors !== void 0 && validationErrors.length)) {
      continue;
    }

    for (const validationError of validationErrors) {
      var _validationError$sour;

      if (!(validationError !== null && validationError !== void 0 && (_validationError$sour = validationError.sources) !== null && _validationError$sour !== void 0 && _validationError$sour.length)) {
        continue;
      }

      for (const source of validationError.sources) {
        if (source.type === 'plugin') {
          const pluginSlug = getPluginSlugFromFile(source.name);

          if ('gutenberg' === pluginSlug && validationError.sources.length > 1) {
            continue;
          }

          plugins.set(pluginSlug, new Set([...(plugins.get(pluginSlug) || []), useAmpUrls ? ampUrl : url]));
        } else if (source.type === 'theme') {
          themes.set(source.name, new Set([...(themes.get(source.name) || []), useAmpUrls ? ampUrl : url]));
        }
      }
    }
  } // Skip including AMP in the summary, since AMP is like core.


  plugins.delete('amp');
  return {
    plugins: [...plugins].map(_ref => {
      let [slug, urls] = _ref;
      return {
        slug,
        urls: [...urls]
      };
    }),
    themes: [...themes].map(_ref2 => {
      let [slug, urls] = _ref2;
      return {
        slug,
        urls: [...urls]
      };
    })
  };
}
;// CONCATENATED MODULE: ./assets/src/components/site-scan-context-provider/index.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */





const SiteScan = (0,external_wp_element_namespaceObject.createContext)();
/**
 * Site Scan Actions.
 */

const ACTION_SET_STATUS = 'ACTION_SET_STATUS';
const ACTION_SCANNABLE_URLS_REQUEST = 'ACTION_SCANNABLE_URLS_REQUEST';
const ACTION_SCANNABLE_URLS_RECEIVE = 'ACTION_SCANNABLE_URLS_RECEIVE';
const ACTION_SCAN_INITIALIZE = 'ACTION_SCAN_INITIALIZE';
const ACTION_SCAN_URL = 'ACTION_SCAN_URL';
const ACTION_SCAN_RECEIVE_RESULTS = 'ACTION_SCAN_RECEIVE_RESULTS';
const ACTION_SCAN_COMPLETE = 'ACTION_SCAN_COMPLETE';
const ACTION_SCAN_CANCEL = 'ACTION_SCAN_CANCEL';
/**
 * Site Scan Statuses.
 */

const STATUS_REQUEST_SCANNABLE_URLS = 'STATUS_REQUEST_SCANNABLE_URLS';
const STATUS_FETCHING_SCANNABLE_URLS = 'STATUS_FETCHING_SCANNABLE_URLS';
const STATUS_REFETCHING_PLUGIN_SUPPRESSION = 'STATUS_REFETCHING_PLUGIN_SUPPRESSION';
const STATUS_READY = 'STATUS_READY';
const STATUS_IDLE = 'STATUS_IDLE';
const STATUS_IN_PROGRESS = 'STATUS_IN_PROGRESS';
const STATUS_COMPLETED = 'STATUS_COMPLETED';
const STATUS_FAILED = 'STATUS_FAILED';
const STATUS_CANCELLED = 'STATUS_CANCELLED';
const STATUS_SKIPPED = 'STATUS_SKIPPED';
/**
 * Initial Site Scan state.
 *
 * @type {Object}
 */

const INITIAL_STATE = {
  currentlyScannedUrlIndexes: [],
  forceStandardMode: false,
  scannableUrls: [],
  scanOnce: false,
  status: '',
  scansCount: 0,
  urlIndexesPendingScan: []
};
/**
 * The maximum number of validation requests that can be issued concurrently.
 *
 * @type {number}
 */

const CONCURRENT_VALIDATION_REQUESTS_MAX_COUNT = 3;
/**
 * The number of milliseconds to wait between subsequent validation requests.
 *
 * @type {number}
 */

const CONCURRENT_VALIDATION_REQUESTS_WAIT_MS = 500;
/**
 * Site Scan Reducer.
 *
 * @param {Object} state  Current state.
 * @param {Object} action Action to call.
 * @return {Object} New state.
 */
//eslint-disable-next-line complexity

function siteScanReducer(state, action) {
  // Bail out early if Site Scan is skipped, i.e. if there is no validation nonce provided meaning the current user
  // does not have capabilities for running AMP validation.
  if (state.status === STATUS_SKIPPED) {
    return state;
  }

  switch (action.type) {
    case ACTION_SET_STATUS:
      {
        return { ...state,
          status: action.status
        };
      }

    case ACTION_SCANNABLE_URLS_REQUEST:
      {
        var _action$forceStandard;

        return { ...state,
          status: STATUS_REQUEST_SCANNABLE_URLS,
          forceStandardMode: (_action$forceStandard = action === null || action === void 0 ? void 0 : action.forceStandardMode) !== null && _action$forceStandard !== void 0 ? _action$forceStandard : false,
          currentlyScannedUrlIndexes: [],
          urlIndexesPendingScan: []
        };
      }

    case ACTION_SCANNABLE_URLS_RECEIVE:
      {
        const hasScannableUrls = Array.isArray(action.scannableUrls) && action.scannableUrls.length > 0;
        return { ...state,
          status: state.scanOnce && state.scansCount > 0 || !hasScannableUrls ? STATUS_COMPLETED : STATUS_READY,
          scannableUrls: hasScannableUrls ? action.scannableUrls : []
        };
      }

    case ACTION_SCAN_INITIALIZE:
      {
        if (![STATUS_READY, STATUS_COMPLETED, STATUS_FAILED, STATUS_CANCELLED].includes(state.status)) {
          return state;
        }

        if (state.scanOnce && state.scansCount > 0) {
          return { ...state,
            status: STATUS_COMPLETED
          };
        }

        return { ...state,
          status: STATUS_IDLE,
          currentlyScannedUrlIndexes: [],
          scansCount: state.scansCount + 1,
          urlIndexesPendingScan: state.scannableUrls.map((url, index) => index)
        };
      }

    case ACTION_SCAN_URL:
      {
        if (![STATUS_IDLE, STATUS_IN_PROGRESS].includes(state.status)) {
          return state;
        }

        return { ...state,
          status: STATUS_IN_PROGRESS,
          currentlyScannedUrlIndexes: [...state.currentlyScannedUrlIndexes, action.currentlyScannedUrlIndex],
          urlIndexesPendingScan: state.urlIndexesPendingScan.filter(index => index !== action.currentlyScannedUrlIndex)
        };
      }

    case ACTION_SCAN_RECEIVE_RESULTS:
      {
        var _action$error;

        if (![STATUS_IDLE, STATUS_IN_PROGRESS].includes(state.status)) {
          return state;
        }

        return { ...state,
          status: STATUS_IDLE,
          currentlyScannedUrlIndexes: state.currentlyScannedUrlIndexes.filter(index => index !== action.currentlyScannedUrlIndex),
          scannableUrls: [...state.scannableUrls.slice(0, action.currentlyScannedUrlIndex), { ...state.scannableUrls[action.currentlyScannedUrlIndex],
            stale: false,
            error: (_action$error = action.error) !== null && _action$error !== void 0 ? _action$error : false,
            validated_url_post: action.error ? {} : action.validatedUrlPost,
            validation_errors: action.error ? [] : action.validationErrors
          }, ...state.scannableUrls.slice(action.currentlyScannedUrlIndex + 1)]
        };
      }

    case ACTION_SCAN_COMPLETE:
      {
        const hasFailed = state.scannableUrls.every(scannableUrl => Boolean(scannableUrl.error));
        return { ...state,
          status: hasFailed ? STATUS_FAILED : STATUS_REFETCHING_PLUGIN_SUPPRESSION
        };
      }

    case ACTION_SCAN_CANCEL:
      {
        if (![STATUS_IDLE, STATUS_IN_PROGRESS].includes(state.status)) {
          return state;
        }

        return { ...state,
          status: STATUS_CANCELLED,
          currentlyScannedUrlIndexes: [],
          urlIndexesPendingScan: []
        };
      }

    default:
      {
        throw new Error(`Unhandled action type: ${action.type}`);
      }
  }
}
/**
 * Context provider for site scanning.
 *
 * @param {Object}  props                                        Component props.
 * @param {?any}    props.children                               Component children.
 * @param {boolean} props.fetchCachedValidationErrors            Whether to fetch cached validation errors on mount.
 * @param {boolean} props.refetchPluginSuppressionOnScanComplete Whether to refetch plugin suppression data when site scan is complete.
 * @param {boolean} props.resetOnOptionsChange                   Whether to reset scanner and refetch scannable URLs whenever AMP options are changed.
 * @param {string}  props.scannableUrlsRestPath                  The REST path for interacting with the scannable URL resources.
 * @param {boolean} props.scanOnce                               Whether to scan only once.
 * @param {string}  props.validateNonce                          The AMP validate nonce.
 */

function SiteScanContextProvider(_ref) {
  var _scannableUrls$0$urlT, _scannableUrls$;

  let {
    children,
    fetchCachedValidationErrors = false,
    refetchPluginSuppressionOnScanComplete = false,
    resetOnOptionsChange = false,
    scannableUrlsRestPath,
    scanOnce = false,
    validateNonce
  } = _ref;
  const {
    originalOptions: {
      theme_support: themeSupport
    },
    savedOptions,
    refetchPluginSuppression
  } = (0,external_wp_element_namespaceObject.useContext)(Options);
  const {
    setAsyncError
  } = useAsyncError();
  const [state, dispatch] = (0,external_wp_element_namespaceObject.useReducer)(siteScanReducer, { ...INITIAL_STATE,
    scanOnce
  });
  const {
    currentlyScannedUrlIndexes,
    forceStandardMode,
    scannableUrls,
    urlIndexesPendingScan,
    status
  } = state;
  const urlType = forceStandardMode || themeSupport === STANDARD ? 'url' : 'amp_url';
  const previewPermalink = (_scannableUrls$0$urlT = scannableUrls === null || scannableUrls === void 0 ? void 0 : (_scannableUrls$ = scannableUrls[0]) === null || _scannableUrls$ === void 0 ? void 0 : _scannableUrls$[urlType]) !== null && _scannableUrls$0$urlT !== void 0 ? _scannableUrls$0$urlT : '';
  /**
   * Memoize properties.
   */

  const {
    hasSiteScanResults,
    pluginsWithAmpIncompatibility,
    stale,
    themesWithAmpIncompatibility
  } = (0,external_wp_element_namespaceObject.useMemo)(() => {
    // Skip if the scan is in progress.
    if (![STATUS_READY, STATUS_COMPLETED, STATUS_SKIPPED].includes(status)) {
      return {
        hasSiteScanResults: false,
        pluginsWithAmpIncompatibility: [],
        stale: false,
        themesWithAmpIncompatibility: []
      };
    }

    const slugs = getSourcesFromScannableUrls(scannableUrls, {
      useAmpUrls: urlType === 'amp_url'
    });
    return {
      hasSiteScanResults: scannableUrls.some(scannableUrl => Boolean(scannableUrl === null || scannableUrl === void 0 ? void 0 : scannableUrl.validation_errors)),
      pluginsWithAmpIncompatibility: slugs.plugins,
      stale: scannableUrls.some(scannableUrl => (scannableUrl === null || scannableUrl === void 0 ? void 0 : scannableUrl.stale) === true),
      themesWithAmpIncompatibility: slugs.themes
    };
  }, [scannableUrls, status, urlType]);
  /**
   * Preflight check.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (!validateNonce && status !== STATUS_SKIPPED) {
      dispatch({
        type: ACTION_SET_STATUS,
        status: STATUS_SKIPPED
      });
    }
  }, [status, validateNonce]);
  /**
   * This component sets state inside async functions. Use this ref to prevent
   * state updates after unmount.
   */

  const hasUnmounted = (0,external_wp_element_namespaceObject.useRef)(false);
  (0,external_wp_element_namespaceObject.useEffect)(() => () => {
    hasUnmounted.current = true;
  }, []);
  const fetchScannableUrls = (0,external_wp_element_namespaceObject.useCallback)(function () {
    let args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    dispatch({
      type: ACTION_SCANNABLE_URLS_REQUEST,
      forceStandardMode: args === null || args === void 0 ? void 0 : args.forceStandardMode
    });
  }, []);
  const startSiteScan = (0,external_wp_element_namespaceObject.useCallback)(() => {
    dispatch({
      type: ACTION_SCAN_INITIALIZE
    });
  }, []);
  const cancelSiteScan = (0,external_wp_element_namespaceObject.useCallback)(() => {
    dispatch({
      type: ACTION_SCAN_CANCEL
    });
  }, []);
  /**
   * Whenever options change, cancel the current scan (if in progress) and
   * refetch the scannable URLs.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (resetOnOptionsChange && Object.keys(savedOptions).length > 0) {
      dispatch({
        type: ACTION_SCANNABLE_URLS_REQUEST
      });
    }
  }, [resetOnOptionsChange, savedOptions]);
  /**
   * Trigger site scan if the suppressed plugins list has changed and the
   * scanner is ready to start a scan.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (status === STATUS_READY && Object.keys(savedOptions.suppressed_plugins || {}).length > 0) {
      dispatch({
        type: ACTION_SCAN_INITIALIZE
      });
    }
  }, [savedOptions === null || savedOptions === void 0 ? void 0 : savedOptions.suppressed_plugins, status]);
  /**
   * Once the site scan is complete, refetch the plugin suppression data so
   * that the suppressed table is updated with the latest validation errors.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (status !== STATUS_REFETCHING_PLUGIN_SUPPRESSION) {
      return;
    }

    if (refetchPluginSuppressionOnScanComplete) {
      refetchPluginSuppression();
    }

    dispatch({
      type: ACTION_SET_STATUS,
      status: STATUS_COMPLETED
    });
  }, [refetchPluginSuppression, refetchPluginSuppressionOnScanComplete, status]);
  /**
   * Delay concurrent validation requests.
   */

  const [shouldDelayValidationRequest, setShouldDelayValidationRequest] = (0,external_wp_element_namespaceObject.useState)(false);
  (0,external_wp_element_namespaceObject.useEffect)(() => {
    let timeoutId;

    if (shouldDelayValidationRequest) {
      (async () => {
        await new Promise(resolve => {
          timeoutId = setTimeout(resolve, CONCURRENT_VALIDATION_REQUESTS_WAIT_MS);
        });

        if (true === hasUnmounted.current) {
          return;
        }

        setShouldDelayValidationRequest(false);
      })();
    }

    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [shouldDelayValidationRequest]);
  /**
   * Fetch scannable URLs from the REST endpoint.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    (async () => {
      if (status !== STATUS_REQUEST_SCANNABLE_URLS) {
        return;
      }

      dispatch({
        type: ACTION_SET_STATUS,
        status: STATUS_FETCHING_SCANNABLE_URLS
      });

      try {
        const fields = ['url', 'amp_url', 'type', 'label'];
        const response = await external_wp_apiFetch_default()({
          path: (0,external_wp_url_namespaceObject.addQueryArgs)(scannableUrlsRestPath, {
            _fields: fetchCachedValidationErrors ? [...fields, 'validation_errors', 'stale'] : fields,
            force_standard_mode: forceStandardMode ? 1 : undefined
          })
        });

        if (true === hasUnmounted.current) {
          return;
        }

        dispatch({
          type: ACTION_SCANNABLE_URLS_RECEIVE,
          scannableUrls: response
        });
      } catch (e) {
        if (true === hasUnmounted.current) {
          return;
        }

        setAsyncError(e);
      }
    })();
  }, [fetchCachedValidationErrors, forceStandardMode, scannableUrlsRestPath, setAsyncError, status]);
  /**
   * Scan site URLs sequentially.
   */

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (![STATUS_IDLE, STATUS_IN_PROGRESS].includes(status)) {
      return;
    }
    /**
     * If there are no more URLs to scan and no URLs are scanned at the
     * moment, finish the site scan.
     */


    if (urlIndexesPendingScan.length === 0) {
      if (currentlyScannedUrlIndexes.length === 0) {
        dispatch({
          type: ACTION_SCAN_COMPLETE
        });
      }

      return;
    }

    if (shouldDelayValidationRequest || currentlyScannedUrlIndexes.length >= CONCURRENT_VALIDATION_REQUESTS_MAX_COUNT) {
      return;
    }

    setShouldDelayValidationRequest(true);
    const currentlyScannedUrlIndex = urlIndexesPendingScan[0];
    dispatch({
      type: ACTION_SCAN_URL,
      currentlyScannedUrlIndex
    });

    (async () => {
      const results = {};

      try {
        const scannableUrl = scannableUrls[currentlyScannedUrlIndex];
        const url = scannableUrl[urlType];
        const args = {
          amp_validate: {
            cache: true,
            cache_bust: Math.random(),
            force_standard_mode: forceStandardMode || undefined,
            nonce: validateNonce,
            omit_stylesheets: true
          }
        };
        const response = await fetch((0,external_wp_url_namespaceObject.addQueryArgs)(url, args));
        const data = await response.json();

        if (true === hasUnmounted.current) {
          return;
        }

        if (response.ok) {
          results.validatedUrlPost = data.validated_url_post;
          results.validationErrors = data.results.map(_ref2 => {
            let {
              error
            } = _ref2;
            return error;
          });
        } else {
          results.error = (data === null || data === void 0 ? void 0 : data.code) || true;
        }
      } catch (e) {
        if (true === hasUnmounted.current) {
          return;
        }

        results.error = true;
      }

      dispatch({
        type: ACTION_SCAN_RECEIVE_RESULTS,
        currentlyScannedUrlIndex,
        ...results
      });
      setShouldDelayValidationRequest(false);
    })();
  }, [currentlyScannedUrlIndexes.length, forceStandardMode, scannableUrls, shouldDelayValidationRequest, status, urlIndexesPendingScan, urlType, validateNonce]);
  return (0,external_wp_element_namespaceObject.createElement)(SiteScan.Provider, {
    value: {
      cancelSiteScan,
      fetchScannableUrls,
      forceStandardMode,
      hasSiteScanResults,
      isBusy: [STATUS_IDLE, STATUS_IN_PROGRESS].includes(status),
      isCancelled: status === STATUS_CANCELLED,
      isCompleted: [STATUS_REFETCHING_PLUGIN_SUPPRESSION, STATUS_COMPLETED].includes(status),
      isFailed: status === STATUS_FAILED,
      isFetchingScannableUrls: [STATUS_REQUEST_SCANNABLE_URLS, STATUS_FETCHING_SCANNABLE_URLS].includes(status),
      isInitializing: !Boolean(status),
      isReady: status === STATUS_READY,
      isSiteScannable: scannableUrls.length > 0,
      isSkipped: status === STATUS_SKIPPED,
      pluginsWithAmpIncompatibility,
      previewPermalink,
      scannableUrls,
      scannedUrlsMaxIndex: ([STATUS_IN_PROGRESS, STATUS_IDLE].includes(status) ? Math.min(scannableUrls.length, ...urlIndexesPendingScan) : 0) - 1,
      stale,
      startSiteScan,
      themesWithAmpIncompatibility
    }
  }, children);
}
;// CONCATENATED MODULE: external ["wp","components"]
var external_wp_components_namespaceObject = window["wp"]["components"];
;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}
;// CONCATENATED MODULE: external ["wp","compose"]
var external_wp_compose_namespaceObject = window["wp"]["compose"];
;// CONCATENATED MODULE: ./assets/src/components/clipboard-button/index.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




const TIMEOUT = 4000; // Adapted from @wordpress/components: <https://github.com/WordPress/gutenberg/blob/3c00d85b12ee45365e3ab329301a07312d99ffdf/packages/components/src/clipboard-button/index.js#L18-L69>.

function ClipboardButton(_ref) {
  let {
    children,
    onCopy,
    onFinishCopy,
    text,
    ...buttonProps
  } = _ref;
  const timeoutId = (0,external_wp_element_namespaceObject.useRef)();
  const ref = (0,external_wp_compose_namespaceObject.useCopyToClipboard)(text, () => {
    if (onCopy) {
      onCopy();
    }

    clearTimeout(timeoutId.current);

    if (onFinishCopy) {
      timeoutId.current = setTimeout(() => onFinishCopy(), TIMEOUT);
    }
  });
  (0,external_wp_element_namespaceObject.useEffect)(() => {
    clearTimeout(timeoutId.current);
  }, []); // Workaround for inconsistent behavior in Safari, where <textarea> is not
  // the document.activeElement at the moment when the copy event fires.
  // This causes documentHasSelection() in the copy-handler component to
  // mistakenly override the ClipboardButton, and copy a serialized string
  // of the current block instead.

  const focusOnCopyEventTarget = event => {
    event.target.focus();
  };

  return (0,external_wp_element_namespaceObject.createElement)(external_wp_components_namespaceObject.Button, _extends({}, buttonProps, {
    className: "components-clipboard-button",
    ref: ref,
    onCopy: focusOnCopyEventTarget
  }), children);
}
;// CONCATENATED MODULE: ./assets/src/components/error-screen/index.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



/**
 * Screen that shows when an error has broken the application.
 *
 * @param {Object} props                 Component props.
 * @param {Object} props.error           Error object containing a message string.
 * @param {string} props.finishLinkLabel Label of a link to return to the admin.
 * @param {string} props.finishLinkUrl   Url of a link to return to the admin.
 * @param {string} props.title           Custom message title.
 */

function ErrorScreen(_ref) {
  let {
    error,
    finishLinkLabel,
    finishLinkUrl,
    title
  } = _ref;
  const [hasCopied, setHasCopied] = (0,external_wp_element_namespaceObject.useState)(false);
  const {
    message,
    stack
  } = error;
  return (0,external_wp_element_namespaceObject.createElement)("div", {
    className: "error-screen-container"
  }, (0,external_wp_element_namespaceObject.createElement)(external_wp_components_namespaceObject.Panel, {
    className: "error-screen"
  }, (0,external_wp_element_namespaceObject.createElement)("h1", null, title || (0,external_wp_i18n_namespaceObject.__)('Something went wrong.', 'amp')), (0,external_wp_element_namespaceObject.createElement)("p", {
    dangerouslySetInnerHTML: {
      __html: message || (0,external_wp_i18n_namespaceObject.__)('There was an error loading the page.', 'amp')
    }
  }), (0,external_wp_element_namespaceObject.createElement)("p", {
    dangerouslySetInnerHTML: {
      __html: (0,external_wp_i18n_namespaceObject.sprintf)( // translators: %s is the AMP support forum URL.
      (0,external_wp_i18n_namespaceObject.__)('Please submit details to our <a href="%s" target="_blank" rel="noreferrer noopener">support forum</a>.', 'amp'), (0,external_wp_i18n_namespaceObject.__)('https://wordpress.org/support/plugin/amp/', 'amp'))
    }
  }), stack && (0,external_wp_element_namespaceObject.createElement)("details", null, (0,external_wp_element_namespaceObject.createElement)("summary", null, (0,external_wp_i18n_namespaceObject.__)('Details', 'amp')), (0,external_wp_element_namespaceObject.createElement)("pre", null, stack), (0,external_wp_element_namespaceObject.createElement)(ClipboardButton, {
    isSmall: true,
    isSecondary: true,
    text: JSON.stringify({
      message,
      stack
    }, null, 2),
    onCopy: () => setHasCopied(true),
    onFinishCopy: () => setHasCopied(false)
  }, hasCopied ? (0,external_wp_i18n_namespaceObject.__)('Copied!', 'amp') : (0,external_wp_i18n_namespaceObject.__)('Copy Error', 'amp'))), finishLinkUrl && finishLinkLabel && (0,external_wp_element_namespaceObject.createElement)("p", null, (0,external_wp_element_namespaceObject.createElement)("a", {
    href: finishLinkUrl
  }, finishLinkLabel))));
}
;// CONCATENATED MODULE: ./assets/src/components/error-boundary/index.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Catches errors in the application and displays a fallback screen.
 *
 * @see https://reactjs.org/docs/error-boundaries.html
 */

class ErrorBoundary extends external_wp_element_namespaceObject.Component {
  constructor(props) {
    super(props);
    this.timeout = null;
    this.state = {
      error: null
    };
  }

  componentDidMount() {
    this.mounted = true;
  }

  componentWillUnmount() {
    this.mounted = false;
  }

  componentDidCatch(error) {
    this.setState({
      error
    });
  }

  render() {
    const {
      error
    } = this.state;
    const {
      children,
      exitLinkLabel,
      exitLinkUrl,
      title
    } = this.props;

    if (error) {
      return (0,external_wp_element_namespaceObject.createElement)(ErrorScreen, {
        error: error,
        finishLinkLabel: exitLinkLabel,
        finishLinkUrl: exitLinkUrl,
        title: title
      });
    }

    return children;
  }

}
// EXTERNAL MODULE: ./node_modules/classnames/index.js
var classnames = __webpack_require__(184);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
;// CONCATENATED MODULE: ./assets/src/components/amp-admin-notice/index.js


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */


const AMP_ADMIN_NOTICE_TYPE_INFO = 'info';
const AMP_ADMIN_NOTICE_TYPE_SUCCESS = 'success';
const AMP_ADMIN_NOTICE_TYPE_WARNING = 'warning';
const AMP_ADMIN_NOTICE_TYPE_ERROR = 'error';
/**
 * WordPress admin notice.
 *
 * @param {Object}   props               Component props.
 * @param {Element}  props.children      Component children.
 * @param {string}   props.className     Additional class names.
 * @param {boolean}  props.isDismissible Indicates whether the notice should be dismissible.
 * @param {Function} props.onDismiss     Function to be called whenever the notice gets dismissed.
 * @param {string}   props.type          Specifies type of the notice.
 */

function AmpAdminNotice(_ref) {
  let {
    children,
    className,
    isDismissible = false,
    onDismiss,
    type = AMP_ADMIN_NOTICE_TYPE_INFO
  } = _ref;
  const [dismissed, setDismissed] = (0,external_wp_element_namespaceObject.useState)(false);
  const dismissHandler = (0,external_wp_element_namespaceObject.useCallback)(() => {
    setDismissed(true);

    if (typeof onDismiss === 'function') {
      onDismiss();
    }
  }, [onDismiss]);

  if (isDismissible && dismissed) {
    return null;
  }

  return (0,external_wp_element_namespaceObject.createElement)("div", {
    className: classnames_default()('amp-admin-notice', className, {
      'amp-admin-notice--dismissible': isDismissible,
      'amp-admin-notice--info': type === AMP_ADMIN_NOTICE_TYPE_INFO,
      'amp-admin-notice--success': type === AMP_ADMIN_NOTICE_TYPE_SUCCESS,
      'amp-admin-notice--warning': type === AMP_ADMIN_NOTICE_TYPE_WARNING,
      'amp-admin-notice--error': type === AMP_ADMIN_NOTICE_TYPE_ERROR
    })
  }, children, isDismissible && (0,external_wp_element_namespaceObject.createElement)("button", {
    type: "button",
    onClick: dismissHandler,
    className: "amp-admin-notice__dismiss"
  }, (0,external_wp_element_namespaceObject.createElement)(external_wp_components_namespaceObject.VisuallyHidden, {
    as: "span"
  }, (0,external_wp_i18n_namespaceObject.__)('Dismiss', 'amp'))));
}
;// CONCATENATED MODULE: ./assets/src/components/loading/index.js


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Loading indicator.
 *
 * @param {Object}  props        Component props.
 * @param {boolean} props.inline Display indicator as an inline element.
 */
// @todo WIP: Updated design needed.

function Loading(_ref) {
  let {
    inline = false
  } = _ref;
  const Tag = inline ? 'span' : 'div';
  return (0,external_wp_element_namespaceObject.createElement)(Tag, {
    className: classnames_default()('amp-spinner-container', {
      'amp-spinner-container--inline': inline
    })
  }, (0,external_wp_element_namespaceObject.createElement)(external_wp_components_namespaceObject.Spinner, null));
}
;// CONCATENATED MODULE: ./assets/src/common/helpers/is-external-url.js
/**
 * Check if the provided URL is external.
 *
 * @param {string} url URL to be checked.
 * @return {boolean} True if the URL is external, false otherwise.
 */
const isExternalUrl = url => {
  var _global, _global$location;

  return ((_global = __webpack_require__.g) === null || _global === void 0 ? void 0 : (_global$location = _global.location) === null || _global$location === void 0 ? void 0 : _global$location.host) !== new URL(url).host;
};
;// CONCATENATED MODULE: ./assets/src/admin/site-scan-notice/plugins-with-amp-incompatibility.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */



/**
 * Render a DETAILS element for each plugin causing AMP incompatibilities.
 *
 * @param {Object} props                               Component props.
 * @param {Array}  props.pluginsWithAmpIncompatibility Array of plugins with AMP incompatibilities.
 */

function PluginsWithAmpIncompatibility(_ref) {
  let {
    pluginsWithAmpIncompatibility
  } = _ref;
  const {
    fetchingPlugins,
    plugins
  } = (0,external_wp_element_namespaceObject.useContext)(Plugins);

  if (fetchingPlugins) {
    return null;
  }

  const pluginNames = Object.values(plugins).reduce((accumulatedPluginNames, plugin) => {
    return { ...accumulatedPluginNames,
      [getPluginSlugFromFile(plugin.plugin)]: plugin.name
    };
  }, {});
  return (0,external_wp_element_namespaceObject.createElement)(external_wp_element_namespaceObject.Fragment, null, (0,external_wp_element_namespaceObject.createElement)("p", null, (0,external_wp_i18n_namespaceObject._n)('AMP compatibility issues discovered with the following plugin:', 'AMP compatibility issues discovered with the following plugins:', pluginsWithAmpIncompatibility.length, 'amp')), pluginsWithAmpIncompatibility.map(pluginWithAmpIncompatibility => (0,external_wp_element_namespaceObject.createElement)("details", {
    key: pluginWithAmpIncompatibility.slug,
    className: "amp-site-scan-notice__plugin-details"
  }, (0,external_wp_element_namespaceObject.createElement)("summary", {
    className: "amp-site-scan-notice__plugin-summary",
    dangerouslySetInnerHTML: {
      __html: (0,external_wp_i18n_namespaceObject.sprintf)(
      /* translators: 1: plugin name; 2: number of URLs with AMP validation issues. */
      (0,external_wp_i18n_namespaceObject._n)('<b>%1$s</b> on %2$d URL', '<b>%1$s</b> on %2$d URLs', pluginWithAmpIncompatibility.urls.length, 'amp'), pluginNames[pluginWithAmpIncompatibility.slug], pluginWithAmpIncompatibility.urls.length)
    }
  }), (0,external_wp_element_namespaceObject.createElement)("ul", {
    className: "amp-site-scan-notice__urls-list"
  }, pluginWithAmpIncompatibility.urls.map(url => (0,external_wp_element_namespaceObject.createElement)("li", {
    key: url
  }, (0,external_wp_element_namespaceObject.createElement)("a", {
    href: url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, url)))))));
}
;// CONCATENATED MODULE: ./assets/src/admin/site-scan-notice/notice.js



/**
 * External dependencies
 */
 // From WP inline script.

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */





 // Define Plugin Suppression link.

const PLUGIN_SUPPRESSION_LINK = new URL(external_ampSiteScanNotice_namespaceObject.SETTINGS_LINK);
PLUGIN_SUPPRESSION_LINK.hash = 'plugin-suppression';
function SiteScanNotice() {
  const {
    cancelSiteScan,
    fetchScannableUrls,
    isCancelled,
    isCompleted,
    isFailed,
    isInitializing,
    isReady,
    pluginsWithAmpIncompatibility,
    startSiteScan
  } = (0,external_wp_element_namespaceObject.useContext)(SiteScan); // Cancel scan on component unmount.

  (0,external_wp_element_namespaceObject.useEffect)(() => cancelSiteScan, [cancelSiteScan]); // Fetch scannable URLs on mount. Start site scan right after the component is mounted and the scanner is ready.

  (0,external_wp_element_namespaceObject.useEffect)(() => {
    if (isInitializing) {
      fetchScannableUrls();
    } else if (isReady) {
      startSiteScan();
    }
  }, [fetchScannableUrls, isInitializing, isReady, startSiteScan]);
  const commonNoticeProps = {
    className: 'amp-site-scan-notice',
    isDismissible: true,
    onDismiss: cancelSiteScan
  };

  if (isFailed || isCancelled) {
    return (0,external_wp_element_namespaceObject.createElement)(AmpAdminNotice, _extends({
      type: AMP_ADMIN_NOTICE_TYPE_ERROR
    }, commonNoticeProps), (0,external_wp_element_namespaceObject.createElement)("p", null, (0,external_wp_i18n_namespaceObject.__)('AMP could not check your site for compatibility issues.', 'amp')));
  }

  if (isCompleted && pluginsWithAmpIncompatibility.length === 0) {
    return (0,external_wp_element_namespaceObject.createElement)(AmpAdminNotice, _extends({
      type: AMP_ADMIN_NOTICE_TYPE_SUCCESS
    }, commonNoticeProps), (0,external_wp_element_namespaceObject.createElement)("p", null, (0,external_wp_i18n_namespaceObject.__)('No AMP compatibility issues detected.', 'amp')));
  }

  if (isCompleted && pluginsWithAmpIncompatibility.length > 0) {
    return (0,external_wp_element_namespaceObject.createElement)(AmpAdminNotice, _extends({
      type: AMP_ADMIN_NOTICE_TYPE_WARNING
    }, commonNoticeProps), (0,external_wp_element_namespaceObject.createElement)(PluginsWithAmpIncompatibility, {
      pluginsWithAmpIncompatibility: pluginsWithAmpIncompatibility
    }), (0,external_wp_element_namespaceObject.createElement)("div", {
      className: "amp-site-scan-notice__cta"
    }, (0,external_wp_element_namespaceObject.createElement)("a", {
      href: PLUGIN_SUPPRESSION_LINK,
      className: "button"
    }, (0,external_wp_i18n_namespaceObject.__)('Review Plugin Suppression', 'amp')), (0,external_wp_element_namespaceObject.createElement)("a", _extends({
      href: external_ampSiteScanNotice_namespaceObject.AMP_COMPATIBLE_PLUGINS_URL,
      className: "button"
    }, isExternalUrl(external_ampSiteScanNotice_namespaceObject.AMP_COMPATIBLE_PLUGINS_URL) ? {
      target: '_blank',
      rel: 'noopener noreferrer'
    } : {}), (0,external_wp_i18n_namespaceObject.__)('View AMP-Compatible Plugins', 'amp'))));
  }

  return (0,external_wp_element_namespaceObject.createElement)(AmpAdminNotice, _extends({
    type: AMP_ADMIN_NOTICE_TYPE_INFO
  }, commonNoticeProps), (0,external_wp_element_namespaceObject.createElement)("p", null, (0,external_wp_i18n_namespaceObject.__)('Checking your site for AMP compatibility issues…', 'amp'), (0,external_wp_element_namespaceObject.createElement)(Loading, {
    inline: true
  })));
}
;// CONCATENATED MODULE: ./assets/src/admin/site-scan-notice/index.js


/**
 * External dependencies
 */

 // From WP inline script.

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */









let errorHandler;
/**
 * Context providers for the application.
 *
 * @param {Object} props          Component props.
 * @param {any}    props.children Component children.
 */

function Providers(_ref) {
  let {
    children
  } = _ref;
  __webpack_require__.g.removeEventListener('error', errorHandler);
  return (0,external_wp_element_namespaceObject.createElement)(ErrorContextProvider, null, (0,external_wp_element_namespaceObject.createElement)(ErrorBoundary, {
    title: (0,external_wp_i18n_namespaceObject.__)('The AMP Site Scanner has experienced an error.', 'amp')
  }, (0,external_wp_element_namespaceObject.createElement)(OptionsContextProvider, {
    hasErrorBoundary: true,
    optionsRestPath: external_ampSiteScanNotice_namespaceObject.OPTIONS_REST_PATH,
    populateDefaultValues: false
  }, (0,external_wp_element_namespaceObject.createElement)(PluginsContextProvider, null, (0,external_wp_element_namespaceObject.createElement)(SiteScanContextProvider, {
    scannableUrlsRestPath: external_ampSiteScanNotice_namespaceObject.SCANNABLE_URLS_REST_PATH,
    validateNonce: external_ampSiteScanNotice_namespaceObject.VALIDATE_NONCE
  }, children)))));
}

external_wp_domReady_default()(() => {
  const root = document.getElementById(external_ampSiteScanNotice_namespaceObject.APP_ROOT_ID);

  if (!root) {
    return;
  }

  errorHandler = event => {
    // Handle only own errors.
    if (event.filename && /amp-site-scan-notice(\.min)?\.js/.test(event.filename)) {
      (0,external_wp_element_namespaceObject.render)((0,external_wp_element_namespaceObject.createElement)(ErrorScreen, {
        error: event.error
      }), root);
    }
  };

  __webpack_require__.g.addEventListener('error', errorHandler);
  (0,external_wp_element_namespaceObject.render)((0,external_wp_element_namespaceObject.createElement)(Providers, null, (0,external_wp_element_namespaceObject.createElement)(SiteScanNotice, null)), root);
});
}();
/******/ })()
;