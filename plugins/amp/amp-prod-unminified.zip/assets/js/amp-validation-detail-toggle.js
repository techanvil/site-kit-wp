/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

;// CONCATENATED MODULE: external ["wp","domReady"]
var external_wp_domReady_namespaceObject = window["wp"]["domReady"];
var external_wp_domReady_default = /*#__PURE__*/__webpack_require__.n(external_wp_domReady_namespaceObject);
;// CONCATENATED MODULE: external ["wp","i18n"]
var external_wp_i18n_namespaceObject = window["wp"]["i18n"];
;// CONCATENATED MODULE: ./assets/src/amp-validation/set-validation-error-rows-classes.js
/**
 * Set the initial class names on the errors rows.
 *
 * This is needed because \WP_Terms_List_Table::single_row() does not allow for additional
 * attributes to be added to the <tr> element.
 */
/* harmony default export */ function set_validation_error_rows_classes() {
  document.querySelectorAll('tr[id]').forEach(row => {
    setStatusNew(row);
    setStatusKept(row);
  });
}
/**
 * Set the initial 'new' (aka 'unseen') class names on the rows based on the presence of a hidden input value.
 *
 * @param {HTMLTableRowElement} row HTML row element.
 */

function setStatusNew(row) {
  const input = row.querySelector('.amp-validation-error-new');

  if (!input) {
    return;
  }

  row.classList.toggle('new', Boolean(parseInt(input.value)));
}
/**
 * Set the 'kept' class names based on the select input field state.
 *
 * @param {HTMLTableRowElement} row HTML row element.
 */


function setStatusKept(row) {
  const input = row.querySelector('.amp-validation-error-status');

  if (!input) {
    return;
  }

  const {
    tagName,
    value
  } = input;
  const hasClass = tagName === 'SELECT' ? value === '2' // See AMP_Validation_Error_Taxonomy::VALIDATION_ERROR_ACK_REJECTED_STATUS.
  : value === '0'; // '0' -> kept; '1' -> removed

  row.classList.toggle('kept', hasClass);
}
;// CONCATENATED MODULE: ./assets/src/amp-validation/amp-validation-detail-toggle.js
/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


const OPEN_CLASS = 'is-open';
/**
 * Adds detail toggle buttons to the header and footer rows of the validation error "details" column.
 * The buttons are added via JS because there's no easy way to append them to the heading of a sortable
 * table column via backend code.
 *
 * @param {string} containerSelector Selector for elements that will have the button added.
 * @param {string} ariaLabel         Screen reader label for the button.
 * @return {Array} Array of added buttons.
 */

function addToggleButtons(containerSelector, ariaLabel) {
  const addButton = container => {
    const button = document.createElement('button');
    button.setAttribute('aria-label', ariaLabel);
    button.setAttribute('type', 'button');
    button.setAttribute('class', 'error-details-toggle');
    container.appendChild(button);
    return button;
  };

  return [...document.querySelectorAll(containerSelector)].map(container => addButton(container));
}

function addToggleAllListener(_ref) {
  let {
    btn,
    toggleAllButtonSelector = null,
    targetDetailsSelector
  } = _ref;
  let open = false;
  const targetDetails = [...document.querySelectorAll(targetDetailsSelector)];
  let toggleAllButtons = [];

  if (toggleAllButtonSelector) {
    toggleAllButtons = [...document.querySelectorAll(toggleAllButtonSelector)];
  }

  const onButtonClick = () => {
    open = !open;
    toggleAllButtons.forEach(toggleAllButton => {
      toggleAllButton.classList.toggle(OPEN_CLASS);
    });
    targetDetails.forEach(detail => {
      if (open) {
        detail.setAttribute('open', true);
      } else {
        detail.removeAttribute('open');
      }
    });
  };

  btn.addEventListener('click', onButtonClick);
}

external_wp_domReady_default()(() => {
  addToggleButtons('th.column-details.manage-column', (0,external_wp_i18n_namespaceObject.__)('Toggle all details', 'amp')).forEach(btn => {
    addToggleAllListener({
      btn,
      toggleAllButtonSelector: '.column-details button.error-details-toggle',
      targetDetailsSelector: '.column-details details'
    });
  });
  addToggleButtons('th.manage-column.column-sources_with_invalid_output', (0,external_wp_i18n_namespaceObject.__)('Toggle all sources', 'amp')).forEach(btn => {
    addToggleAllListener({
      btn,
      toggleAllButtonSelector: '.column-sources_with_invalid_output button.error-details-toggle',
      targetDetailsSelector: 'details.source'
    });
  });
  set_validation_error_rows_classes();
});
/******/ })()
;