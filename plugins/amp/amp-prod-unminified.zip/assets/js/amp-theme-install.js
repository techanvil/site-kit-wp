/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

;// CONCATENATED MODULE: external "ampThemes"
var external_ampThemes_namespaceObject = ampThemes;
;// CONCATENATED MODULE: external ["wp","i18n"]
var external_wp_i18n_namespaceObject = window["wp"]["i18n"];
;// CONCATENATED MODULE: external ["wp","domReady"]
var external_wp_domReady_namespaceObject = window["wp"]["domReady"];
var external_wp_domReady_default = /*#__PURE__*/__webpack_require__.n(external_wp_domReady_namespaceObject);
;// CONCATENATED MODULE: ./assets/src/admin/theme-install/view/theme.js
/**
 * External dependencies
 */
 // From WP inline script.

/**
 * WordPress dependencies
 */


const wpThemeView = wp.themes.view.Theme;
/* harmony default export */ var theme = (wpThemeView.extend({
  /**
   * Check if "AMP Compatible" tab is open or not.
   */
  isAmpCompatibleTab() {
    const queryParams = new URLSearchParams(window.location.search.substr(1));
    return queryParams.get('browse') === external_ampThemes_namespaceObject.AMP_COMPATIBLE;
  },

  /**
   * Render theme card.
   *
   * @param {...any} args Render arguments.
   */
  render() {
    var _this$$el;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    wpThemeView.prototype.render.apply(this, args);

    if (0 >= ((_this$$el = this.$el) === null || _this$$el === void 0 ? void 0 : _this$$el.length) || !this.$el[0]) {
      return;
    }

    const element = this.$el[0];
    const data = this.model.toJSON();
    let slug = data === null || data === void 0 ? void 0 : data.slug;

    if (!slug) {
      slug = data === null || data === void 0 ? void 0 : data.id;
    }

    if (slug && this.isAmpTheme(slug)) {
      /*
       * Note: the setTimeout is needed because when the user taps on the AMP Compatible tab, the UI will render
       * before history.pushState() is called, meaning isAmpCompatibleTab cannot be called yet to inspect the
       * current location. By waiting for the next tick, we can safely read it.
       */
      setTimeout(() => {
        if (this.isAmpCompatibleTab()) {
          return;
        }

        const messageElement = document.createElement('div');
        const iconElement = document.createElement('span');
        const tooltipElement = document.createElement('span');
        messageElement.classList.add('amp-extension-card-message');
        iconElement.classList.add('amp-logo-icon');
        tooltipElement.classList.add('tooltiptext');
        tooltipElement.append((0,external_wp_i18n_namespaceObject.__)('This is known to work well with the AMP plugin.', 'amp'));
        messageElement.append(iconElement, tooltipElement);
        element.appendChild(messageElement);
      });
    }

    if (slug && !this.isWPORGTheme(slug)) {
      const externalLinkIcon = document.createElement('span');
      externalLinkIcon.classList.add('dashicons', 'dashicons-external');
      externalLinkIcon.setAttribute('aria-hidden', 'true');
      const screenReaderText = document.createElement('span');
      screenReaderText.classList.add('screen-reader-text');
      screenReaderText.append((0,external_wp_i18n_namespaceObject.__)('(opens in a new tab)', 'amp'));
      const siteLinkButton = document.createElement('a');
      siteLinkButton.classList.add('button', 'button-primary');
      siteLinkButton.append((0,external_wp_i18n_namespaceObject.__)('Visit Site', 'amp'), screenReaderText, externalLinkIcon);

      if (data !== null && data !== void 0 && data.preview_url) {
        siteLinkButton.href = data.preview_url;
      } else {
        siteLinkButton.href = data.homepage;
      }

      siteLinkButton.target = '_blank';
      siteLinkButton.rel = 'noopener noreferrer';
      siteLinkButton.setAttribute('aria-label', (0,external_wp_i18n_namespaceObject.sprintf)(
      /* translators: %s: theme name. */
      (0,external_wp_i18n_namespaceObject.__)('Visit site of %s theme', 'amp'), data.name));
      const themeActions = element.querySelector('.theme-actions');

      if (themeActions) {
        themeActions.textContent = ''; // Remove children.

        themeActions.append(siteLinkButton);
      }

      const moreDetail = element.querySelector('.more-details');

      if (moreDetail) {
        moreDetail.textContent = ''; // Remove children.

        moreDetail.append((0,external_wp_i18n_namespaceObject.__)('Visit Site', 'amp'), externalLinkIcon.cloneNode(true));
      }
    }
  },

  /**
   * Prevent the preview of none WordPress org theme and redirect to theme site.
   *
   * @param {...any} args Preview arguments.
   */
  preview() {
    const data = this.model.toJSON();

    if (this.isWPORGTheme(data.slug)) {
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }

      wpThemeView.prototype.preview.apply(this, args);
    } else if (data !== null && data !== void 0 && data.preview_url) {
      window.open(data.preview_url, '_blank', 'noopener,noreferrer');
    }
  },

  /**
   * Check if a theme is AMP compatible or not.
   *
   * @param {string} slug Theme slug.
   * @return {boolean} True if theme is AMP compatible, Otherwise False.
   */
  isAmpTheme(slug) {
    return external_ampThemes_namespaceObject.AMP_THEMES.includes(slug);
  },

  /**
   * Check if a theme is from WordPress org or not.
   *
   * @param {string} slug Theme slug.
   * @return {boolean} True if theme is listed in WordPress org, Otherwise False.
   */
  isWPORGTheme(slug) {
    return !external_ampThemes_namespaceObject.NONE_WPORG_THEMES.includes(slug);
  }

}));
;// CONCATENATED MODULE: ./assets/src/admin/amp-theme-install.js
/**
 * External dependencies
 */
 // From WP inline script.

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */


const ampThemeInstall = {
  /**
   * Init function.
   */
  init() {
    this.addTab();
    this.overrideViews();
  },

  /**
   * Add a new tab for AMP-compatible themes on theme install page.
   */
  addTab() {
    const filterLinks = document.querySelector('.filter-links');

    if (!filterLinks) {
      return;
    }

    const listItem = document.createElement('li');
    const anchorElement = document.createElement('a');
    anchorElement.setAttribute('href', '#');
    anchorElement.setAttribute('data-sort', external_ampThemes_namespaceObject.AMP_COMPATIBLE);
    anchorElement.append((0,external_wp_i18n_namespaceObject.__)('AMP Compatible', 'amp'));
    listItem.appendChild(anchorElement);
    filterLinks.appendChild(listItem);
  },

  /**
   * Override theme view.
   */
  overrideViews() {
    wp.themes.view.Theme = theme;
  }

};
external_wp_domReady_default()(() => {
  ampThemeInstall.init();
});
/******/ })()
;