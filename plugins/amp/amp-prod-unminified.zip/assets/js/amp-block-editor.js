/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 55:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./amp-brid-player/index.js": 499,
	"./amp-ima-video/index.js": 692,
	"./amp-jwplayer/index.js": 122,
	"./amp-mathml/index.js": 167,
	"./amp-o2-player/index.js": 192,
	"./amp-ooyala-player/index.js": 326,
	"./amp-reach-player/index.js": 120,
	"./amp-springboard-player/index.js": 884,
	"./amp-timeago/index.js": 415
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 55;

/***/ }),

/***/ 72:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./post-status-info.js": 806,
	"./pre-publish-panel.js": 492,
	"./wrapped-amp-preview-button.js": 121
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 72;

/***/ }),

/***/ 499:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_brid_player_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-brid-player/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    autoPlay,
    dataPartner,
    dataPlayer,
    dataVideo,
    dataPlaylist,
    dataOutstream
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: (0,external_wp_i18n_.__)('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fill',
    label: (0,external_wp_i18n_.__)('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: (0,external_wp_i18n_.__)('Flex-item', 'amp')
  }, {
    value: 'nodisplay',
    label: (0,external_wp_i18n_.__)('No Display', 'amp')
  }];
  let url = false;

  if (dataPartner && dataPlayer && (dataVideo || dataPlaylist || dataOutstream)) {
    url = `http://cdn.brid.tv/live/partners/${dataPartner}`;
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('Brid Player Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Partner ID (required)', 'amp'),
    value: dataPartner,
    onChange: value => setAttributes({
      dataPartner: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Player ID (required)', 'amp'),
    value: dataPlayer,
    onChange: value => setAttributes({
      dataPlayer: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Video ID (one of video / playlist / outstream ID is required)', 'amp'),
    value: dataVideo,
    onChange: value => setAttributes({
      dataVideo: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Outstream unit ID (one of video / playlist / outstream ID is required)', 'amp'),
    value: dataOutstream,
    onChange: value => setAttributes({
      dataOutstream: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Playlist ID (one of video / playlist / outstream ID is required)', 'amp'),
    value: dataPlaylist,
    onChange: value => setAttributes({
      dataPlaylist: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.ToggleControl, {
    label: (0,external_wp_i18n_.__)('Autoplay', 'amp'),
    checked: autoPlay,
    onChange: () => setAttributes({
      autoPlay: !autoPlay
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('Brid Player', 'amp'),
    url: url
  }), !url && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('Brid Player', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add required data to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-brid-player/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    dataPlayer,
    dataOutstream,
    dataPartner,
    ampLayout,
    width,
    height,
    dataVideo,
    autoPlay,
    dataPlaylist
  } = attributes;
  const bridProps = {
    layout: ampLayout,
    height,
    'data-player': dataPlayer,
    'data-partner': dataPartner
  };

  if ('fixed-height' !== ampLayout && width) {
    bridProps.width = width;
  }

  if (dataPlaylist) {
    bridProps['data-playlist'] = dataPlaylist;
  }

  if (dataVideo) {
    bridProps['data-video'] = dataVideo;
  }

  if (dataOutstream) {
    bridProps['data-outstream'] = dataOutstream;
  }

  if (autoPlay) {
    bridProps.autoplay = autoPlay;
  }

  return (0,external_wp_element_.createElement)("amp-brid-player", bridProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-brid-player/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_brid_player_name = 'amp/amp-brid-player';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP Brid Player', 'amp'),
  description: (0,external_wp_i18n_.__)('Displays the Brid Player used in Brid.tv Video Platform.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp')],
  attributes: {
    autoPlay: {
      type: 'boolean'
    },
    dataPartner: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-partner'
    },
    dataPlayer: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-player'
    },
    dataVideo: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-video'
    },
    dataPlaylist: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-playlist'
    },
    dataOutstream: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-outstream'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'layout'
    },
    width: {
      type: 'number',
      default: 600
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 692:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_ima_video_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-ima-video/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    dataDelayAdRequest,
    dataTag,
    dataSrc,
    dataPoster
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }];
  let dataSet = false;

  if (dataTag && dataSrc) {
    dataSet = true;
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('IMA Video Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('HTTPS URL for your VAST ad document (required)', 'amp'),
    value: dataTag,
    onChange: value => setAttributes({
      dataTag: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('HTTPS URL of your video content (required)', 'amp'),
    value: dataSrc,
    onChange: value => setAttributes({
      dataSrc: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('HTTPS URL to preview image', 'amp'),
    value: dataPoster,
    onChange: value => setAttributes({
      dataPoster: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.ToggleControl, {
    label: (0,external_wp_i18n_.__)('Delay Ad Request', 'amp'),
    checked: dataDelayAdRequest,
    onChange: () => setAttributes({
      dataDelayAdRequest: !dataDelayAdRequest
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), dataSet && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('IMA Video', 'amp'),
    url: dataSrc
  }), !dataSet && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('IMA Video', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add required data to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-ima-video/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    width,
    dataSrc,
    ampLayout,
    dataTag,
    dataDelayAdRequest,
    height,
    dataPoster
  } = attributes;
  const imaProps = {
    layout: ampLayout,
    height,
    width,
    'data-tag': dataTag,
    'data-src': dataSrc
  };

  if (dataPoster) {
    imaProps['data-poster'] = dataPoster;
  }

  if (dataDelayAdRequest) {
    imaProps['data-delay-ad-request'] = dataDelayAdRequest;
  }

  return (0,external_wp_element_.createElement)("amp-ima-video", imaProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-ima-video/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_ima_video_name = 'amp/amp-ima-video';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP IMA Video', 'amp'),
  description: (0,external_wp_i18n_.__)('Embeds a video player for instream video ads that are integrated with the IMA SDK', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp')],
  // @todo Perhaps later add subtitles option and additional source options?
  attributes: {
    dataDelayAdRequest: {
      default: false,
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-delay-ad-request'
    },
    dataTag: {
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-tag'
    },
    dataSrc: {
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-src'
    },
    dataPoster: {
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-poster'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 122:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_jwplayer_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-jwplayer/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    dataPlayerId,
    dataMediaId,
    dataPlaylistId
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: (0,external_wp_i18n_.__)('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fill',
    label: (0,external_wp_i18n_.__)('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: (0,external_wp_i18n_.__)('Flex-item', 'amp')
  }, {
    value: 'nodisplay',
    label: (0,external_wp_i18n_.__)('No Display', 'amp')
  }];
  let url = false;

  if (dataPlayerId && (dataMediaId || dataPlaylistId)) {
    if (dataPlaylistId) {
      url = `https://content.jwplatform.com/players/${dataPlaylistId}-${dataPlayerId}`;
    } else {
      url = `https://content.jwplatform.com/players/${dataMediaId}-${dataPlayerId}`;
    }
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('JW Player Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Player ID (required)', 'amp'),
    value: dataPlayerId,
    onChange: value => setAttributes({
      dataPlayerId: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Media ID (required if playlist ID not set)', 'amp'),
    value: dataMediaId,
    onChange: value => setAttributes({
      dataMediaId: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Playlist ID (required if media ID not set)', 'amp'),
    value: dataPlaylistId,
    onChange: value => setAttributes({
      dataPlaylistId: value
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('JW Player', 'amp'),
    url: url
  }), !url && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('JW Player', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add required data to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-jwplayer/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    width,
    height,
    ampLayout,
    dataPlaylistId,
    dataPlayerId,
    dataMediaId
  } = attributes;
  const jwProps = {
    layout: ampLayout,
    height,
    'data-player-id': dataPlayerId
  };

  if ('fixed-height' !== ampLayout && width) {
    jwProps.width = width;
  }

  if (dataPlaylistId) {
    jwProps['data-playlist-id'] = dataPlaylistId;
  }

  if (dataMediaId) {
    jwProps['data-media-id'] = dataMediaId;
  }

  return (0,external_wp_element_.createElement)("amp-jwplayer", jwProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-jwplayer/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_jwplayer_name = 'amp/amp-jwplayer';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP JW Player', 'amp'),
  description: (0,external_wp_i18n_.__)('Displays a cloud-hosted JW Player.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp')],
  attributes: {
    dataPlayerId: {
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'data-player-id'
    },
    dataMediaId: {
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'data-media-id'
    },
    dataPlaylistId: {
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'data-playlist-id'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 167:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_mathml_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-mathml/edit.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




const BlockEdit = _ref => {
  let {
    attributes,
    setAttributes
  } = _ref;
  const {
    dataFormula
  } = attributes;
  return (0,external_wp_element_.createElement)(external_wp_blockEditor_.PlainText, {
    value: dataFormula,
    placeholder: (0,external_wp_i18n_.__)('Insert formula', 'amp'),
    onChange: value => setAttributes({
      dataFormula: value
    })
  });
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-mathml/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    dataFormula
  } = attributes;
  const mathmlProps = {
    'data-formula': dataFormula,
    layout: 'container'
  };
  return (0,external_wp_element_.createElement)("amp-mathml", mathmlProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-mathml/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_mathml_name = 'amp/amp-mathml';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP MathML', 'amp'),
  category: 'common',
  icon: 'welcome-learn-more',
  keywords: [(0,external_wp_i18n_.__)('Mathematical formula', 'amp'), (0,external_wp_i18n_.__)('Scientific content ', 'amp')],
  attributes: {
    dataFormula: {
      source: 'attribute',
      selector: 'amp-mathml',
      attribute: 'data-formula'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 192:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_o2_player_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-o2-player/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    autoPlay,
    dataPid,
    dataVid,
    dataBcid,
    dataBid
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: (0,external_wp_i18n_.__)('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fill',
    label: (0,external_wp_i18n_.__)('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: (0,external_wp_i18n_.__)('Flex-item', 'amp')
  }, {
    value: 'nodisplay',
    label: (0,external_wp_i18n_.__)('No Display', 'amp')
  }];
  let url = false;

  if (dataPid && (dataBcid || dataVid)) {
    url = `https://delivery.vidible.tv/htmlembed/pid=${dataPid}/`;
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('O2 Player Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Player ID (required)', 'amp'),
    value: dataPid,
    onChange: value => setAttributes({
      dataPid: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Buyer Company ID (either buyer or video ID is required)', 'amp'),
    value: dataBcid,
    onChange: value => setAttributes({
      dataBcid: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Video ID (either buyer or video ID is required)', 'amp'),
    value: dataVid,
    onChange: value => setAttributes({
      dataVid: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Playlist ID', 'amp'),
    value: dataBid,
    onChange: value => setAttributes({
      dataBid: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.ToggleControl, {
    label: (0,external_wp_i18n_.__)('Autoplay', 'amp'),
    checked: autoPlay,
    onChange: () => setAttributes({
      autoPlay: !autoPlay
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('O2 Player', 'amp'),
    url: url
  }), !url && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('O2 Player', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add required data to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-o2-player/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    dataPid,
    width,
    height,
    ampLayout,
    dataBid,
    autoPlay,
    dataBcid,
    dataVid
  } = attributes;
  const o2Props = {
    layout: ampLayout,
    height,
    'data-pid': dataPid
  };

  if ('fixed-height' !== ampLayout && width) {
    o2Props.width = width;
  }

  if (!autoPlay) {
    o2Props['data-macros'] = 'm.playback=click';
  }

  if (dataVid) {
    o2Props['data-vid'] = dataVid;
  } else if (dataBcid) {
    o2Props['data-bcid'] = dataBcid;
  }

  if (dataBid) {
    o2Props['data-bid'] = dataBid;
  }

  return (0,external_wp_element_.createElement)("amp-o2-player", o2Props);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-o2-player/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_o2_player_name = 'amp/amp-o2-player';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP O2 Player', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp'), (0,external_wp_i18n_.__)('AOL O2Player', 'amp')],
  // @todo Add other useful macro toggles, e.g. showing relevant content.
  attributes: {
    dataPid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-pid'
    },
    dataVid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-vid'
    },
    dataBcid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-bcid'
    },
    dataBid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-bid'
    },
    autoPlay: {
      default: false
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 326:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_ooyala_player_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-ooyala-player/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    dataEmbedCode,
    dataPlayerId,
    dataPcode,
    dataPlayerVersion
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fill',
    label: (0,external_wp_i18n_.__)('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: (0,external_wp_i18n_.__)('Flex-item', 'amp')
  }];
  let url = false;

  if (dataEmbedCode && dataPlayerId && dataPcode) {
    url = `http://cf.c.ooyala.com/${dataEmbedCode}`;
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('Ooyala Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Video embed code (required)', 'amp'),
    value: dataEmbedCode,
    onChange: value => setAttributes({
      dataEmbedCode: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Player ID (required)', 'amp'),
    value: dataPlayerId,
    onChange: value => setAttributes({
      dataPlayerId: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Provider code for the account (required)', 'amp'),
    value: dataPcode,
    onChange: value => setAttributes({
      dataPcode: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.SelectControl, {
    label: (0,external_wp_i18n_.__)('Player version', 'amp'),
    value: dataPlayerVersion,
    options: [{
      value: 'v3',
      label: (0,external_wp_i18n_.__)('V3', 'amp')
    }, {
      value: 'v4',
      label: (0,external_wp_i18n_.__)('V4', 'amp')
    }],
    onChange: value => setAttributes({
      dataPlayerVersion: value
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('Ooyala Player', 'amp'),
    url: url
  }), !url && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('Ooyala Player', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add required data to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-ooyala-player/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    dataEmbedCode,
    dataPlayerId,
    dataPcode,
    dataPlayerVersion,
    ampLayout,
    height,
    width
  } = attributes;
  const ooyalaProps = {
    layout: ampLayout,
    height,
    'data-embedcode': dataEmbedCode,
    'data-playerid': dataPlayerId,
    'data-pcode': dataPcode,
    'data-playerversion': dataPlayerVersion
  };

  if ('fixed-height' !== ampLayout && width) {
    ooyalaProps.width = width;
  }

  return (0,external_wp_element_.createElement)("amp-ooyala-player", ooyalaProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-ooyala-player/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_ooyala_player_name = 'amp/amp-ooyala-player';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP Ooyala Player', 'amp'),
  description: (0,external_wp_i18n_.__)('Displays an Ooyala video.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp'), (0,external_wp_i18n_.__)('Ooyala video', 'amp')],
  // @todo Add data-config attribute?
  attributes: {
    dataEmbedCode: {
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-embedcode'
    },
    dataPlayerId: {
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-playerid'
    },
    dataPcode: {
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-pcode'
    },
    dataPlayerVersion: {
      default: 'v3',
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-playerversion'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 120:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_reach_player_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-reach-player/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    dataEmbedId
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: (0,external_wp_i18n_.__)('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fill',
    label: (0,external_wp_i18n_.__)('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: (0,external_wp_i18n_.__)('Flex-item', 'amp')
  }];
  let url = false;

  if (dataEmbedId) {
    url = 'https://media-cdn.beachfrontreach.com/acct_1/video/';
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('Reach Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Embed ID (required)', 'amp'),
    value: dataEmbedId,
    onChange: value => setAttributes({
      dataEmbedId: value
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('Reach Player', 'amp'),
    url: url
  }), !url && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('Reach Player', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add Reach player embed ID to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-reach-player/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    dataEmbedId,
    ampLayout,
    height,
    width
  } = attributes;
  const reachProps = {
    layout: ampLayout,
    height,
    'data-embed-id': dataEmbedId
  };

  if ('fixed-height' !== ampLayout && width) {
    reachProps.width = width;
  }

  return (0,external_wp_element_.createElement)("amp-reach-player", reachProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-reach-player/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_reach_player_name = 'amp/amp-reach-player';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP Reach Player', 'amp'),
  description: (0,external_wp_i18n_.__)('Displays the Reach Player configured in the Beachfront Reach platform.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp'), (0,external_wp_i18n_.__)('Beachfront Reach video', 'amp')],
  attributes: {
    dataEmbedId: {
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'data-embed-id'
    },
    ampLayout: {
      default: 'fixed-height',
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 884:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_springboard_player_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-springboard-player/edit.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    dataSiteId,
    dataPlayerId,
    dataContentId,
    dataDomain,
    dataMode,
    dataItems
  } = attributes;
  const ampLayoutOptions = [{
    value: 'responsive',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fill',
    label: (0,external_wp_i18n_.__)('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: (0,external_wp_i18n_.__)('Flex-item', 'amp')
  }];
  let url = false;

  if (dataSiteId && dataContentId && dataDomain && dataMode && dataItems) {
    url = 'https://cms.springboardplatform.com/embed_iframe/';
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('Springboard Player Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Site ID (required)', 'amp'),
    value: dataSiteId,
    onChange: value => setAttributes({
      dataSiteId: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Content ID (required)', 'amp'),
    value: dataContentId,
    onChange: value => setAttributes({
      dataContentId: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Player ID', 'amp'),
    value: dataPlayerId,
    onChange: value => setAttributes({
      dataPlayerId: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    label: (0,external_wp_i18n_.__)('Springboard partner domain', 'amp'),
    value: dataDomain,
    onChange: value => setAttributes({
      dataDomain: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.SelectControl, {
    label: (0,external_wp_i18n_.__)('Mode (required)', 'amp'),
    value: dataMode,
    options: [{
      value: 'video',
      label: (0,external_wp_i18n_.__)('Video', 'amp')
    }, {
      value: 'playlist',
      label: (0,external_wp_i18n_.__)('Playlist', 'amp')
    }],
    onChange: value => setAttributes({
      dataMode: value
    })
  }), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    type: "number",
    label: (0,external_wp_i18n_.__)('Number of video is playlist (required)', 'amp'),
    value: dataItems,
    onChange: value => setAttributes({
      dataItems: value
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && (0,external_wp_element_.createElement)(components/* MediaPlaceholder */.om, {
    name: (0,external_wp_i18n_.__)('Springboard Player', 'amp'),
    url: url
  }), !url && (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: (0,external_wp_i18n_.__)('Springboard Player', 'amp')
  }, (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Add required data to use the block.', 'amp'))));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-springboard-player/save.js


/**
 * External dependencies
 */


const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    dataSiteId,
    dataPlayerId,
    dataContentId,
    dataDomain,
    dataMode,
    dataItems,
    ampLayout,
    height,
    width
  } = attributes;
  const springboardProps = {
    layout: ampLayout,
    height,
    'data-site-id': dataSiteId,
    'data-mode': dataMode,
    'data-content-id': dataContentId,
    'data-player-id': dataPlayerId,
    'data-domain': dataDomain,
    'data-items': dataItems
  };

  if ('fixed-height' !== ampLayout && width) {
    springboardProps.width = attributes.width;
  }

  return (0,external_wp_element_.createElement)("amp-springboard-player", springboardProps);
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-springboard-player/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_springboard_player_name = 'amp/amp-springboard-player';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP Springboard Player', 'amp'),
  description: (0,external_wp_i18n_.__)('Displays the Springboard Player used in the Springboard Video Platform', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [(0,external_wp_i18n_.__)('Embed', 'amp')],
  attributes: {
    dataSiteId: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-site-id'
    },
    dataContentId: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-content-id'
    },
    dataPlayerId: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-player-id'
    },
    dataDomain: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-domain'
    },
    dataMode: {
      default: 'video',
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-mode'
    },
    dataItems: {
      default: 1,
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-items'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'height'
    }
  },
  edit: edit,
  save: save
};

/***/ }),

/***/ 415:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ amp_timeago_name; },
  "settings": function() { return /* binding */ settings; }
});

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
;// CONCATENATED MODULE: external "moment"
var external_moment_namespaceObject = window["moment"];
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_namespaceObject);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var components = __webpack_require__(503);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-timeago/edit.js



/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



const BlockEdit = props => {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    align,
    cutoff,
    dateTime
  } = attributes;
  let timeAgo;

  if (dateTime) {
    if (cutoff && parseInt(cutoff) < Math.abs(external_moment_default()(dateTime).diff(external_moment_default()(), 'seconds'))) {
      timeAgo = external_moment_default()(dateTime).format('dddd D MMMM HH:mm');
    } else {
      timeAgo = external_moment_default()(dateTime).fromNow();
    }
  } else {
    timeAgo = external_moment_default()(Date.now()).fromNow();
    setAttributes({
      dateTime: external_moment_default()(external_moment_default()(), (external_moment_default()).ISO_8601, true).format()
    });
  }

  const ampLayoutOptions = [{
    value: '',
    label: (0,external_wp_i18n_.__)('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: (0,external_wp_i18n_.__)('Fixed', 'amp')
  }, {
    value: 'fixed-height',
    label: (0,external_wp_i18n_.__)('Fixed Height', 'amp')
  }];
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('AMP Timeago Settings', 'amp')
  }, (0,external_wp_element_.createElement)(external_wp_components_.DateTimePicker, {
    locale: "en",
    currentDate: dateTime || external_moment_default()(),
    onChange: value => setAttributes({
      dateTime: external_moment_default()(value, (external_moment_default()).ISO_8601, true).format()
    })
  }), (0,external_wp_element_.createElement)(components/* LayoutControls */.CR, (0,esm_extends/* default */.Z)({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    type: "number",
    className: "blocks-amp-timeout__cutoff",
    label: (0,external_wp_i18n_.__)('Cutoff (seconds)', 'amp'),
    value: cutoff !== undefined ? cutoff : '',
    onChange: value => setAttributes({
      cutoff: value
    })
  }))), (0,external_wp_element_.createElement)(external_wp_blockEditor_.BlockControls, null, (0,external_wp_element_.createElement)(external_wp_blockEditor_.BlockAlignmentToolbar, {
    value: align,
    onChange: nextAlign => {
      setAttributes({
        align: nextAlign
      });
    },
    controls: ['left', 'center', 'right']
  })), (0,external_wp_element_.createElement)("time", {
    dateTime: dateTime
  }, timeAgo));
};

/* harmony default export */ var edit = (BlockEdit);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-timeago/save.js


/**
 * External dependencies
 */



const BlockSave = _ref => {
  let {
    attributes
  } = _ref;
  const {
    ampLayout,
    width,
    height,
    align,
    cutoff,
    dateTime
  } = attributes;
  const timeagoProps = {
    layout: 'responsive',
    className: 'align' + (align || 'none'),
    datetime: dateTime,
    locale: 'en'
  };

  if (cutoff) {
    timeagoProps.cutoff = cutoff;
  }

  if (ampLayout) {
    switch (ampLayout) {
      case 'fixed-height':
        if (height) {
          timeagoProps.height = height;
          timeagoProps.layout = ampLayout;
        }

        break;

      case 'fixed':
        if (height && width) {
          timeagoProps.height = height;
          timeagoProps.width = width;
          timeagoProps.layout = ampLayout;
        }

        break;

      default:
        break;
    }
  }

  return (0,external_wp_element_.createElement)("amp-timeago", timeagoProps, external_moment_default()(attributes.dateTime).format('dddd D MMMM HH:mm'));
};

/* harmony default export */ var save = (BlockSave);
;// CONCATENATED MODULE: ./assets/src/block-editor/blocks/amp-timeago/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



const amp_timeago_name = 'amp/amp-timeago';
const settings = {
  title: (0,external_wp_i18n_.__)('AMP Timeago', 'amp'),
  category: 'common',
  icon: 'backup',
  keywords: [(0,external_wp_i18n_.__)('Time difference', 'amp'), (0,external_wp_i18n_.__)('Time ago', 'amp'), (0,external_wp_i18n_.__)('Date', 'amp')],
  attributes: {
    align: {
      type: 'string'
    },
    cutoff: {
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'cutoff'
    },
    dateTime: {
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'datetime'
    },
    ampLayout: {
      default: 'fixed-height',
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'layout'
    },
    width: {
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'width'
    },
    height: {
      default: 20,
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'height'
    }
  },

  getEditWrapperProps(attributes) {
    const {
      align
    } = attributes;

    if ('left' === align || 'right' === align || 'center' === align) {
      return {
        'data-align': align
      };
    }

    return undefined;
  },

  edit: edit,
  save: save
};

/***/ }),

/***/ 503:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "CR": function() { return /* reexport */ layout_controls; },
  "om": function() { return /* reexport */ media_placeholder; },
  "kY": function() { return /* reexport */ with_media_library_notice; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
;// CONCATENATED MODULE: ./assets/src/block-editor/components/media-placeholder.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



/**
 * Display media placeholder.
 *
 * @param {Object} props      Component props.
 * @param {string} props.name Block's name.
 * @param {string} props.url  URL.
 * @return {JSX.Element} Placeholder.
 */

const MediaPlaceholder = _ref => {
  let {
    name,
    url
  } = _ref;
  return (0,external_wp_element_.createElement)(external_wp_components_.Placeholder, {
    label: name
  }, (0,external_wp_element_.createElement)("p", {
    className: "components-placeholder__error"
  }, url), (0,external_wp_element_.createElement)("p", {
    className: "components-placeholder__error"
  }, (0,external_wp_i18n_.__)('Previews for this are unavailable in the editor, sorry!', 'amp')));
};

/* harmony default export */ var media_placeholder = (MediaPlaceholder);
;// CONCATENATED MODULE: ./assets/src/block-editor/components/layout-controls.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



/**
 * Layout controls for AMP blocks' attributes: layout, width, height.
 *
 * @param {Object}   props                  Component props.
 * @param {Object}   props.attributes       Block attributes.
 * @param {Function} props.setAttributes    Callback to update block attributes.
 * @param {Array}    props.ampLayoutOptions Layout options.
 * @return {JSX.Element} Controls.
 */

const LayoutControls = _ref => {
  let {
    attributes,
    setAttributes,
    ampLayoutOptions
  } = _ref;
  const {
    ampLayout,
    height,
    width
  } = attributes;
  const showHeightNotice = !height && ('fixed' === ampLayout || 'fixed-height' === ampLayout);
  const showWidthNotice = !width && 'fixed' === ampLayout;
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.SelectControl, {
    label: (0,external_wp_i18n_.__)('Layout', 'amp'),
    value: ampLayout,
    options: ampLayoutOptions,
    onChange: value => setAttributes({
      ampLayout: value
    })
  }), showWidthNotice && (0,external_wp_element_.createElement)(external_wp_components_.Notice, {
    status: "error",
    isDismissible: false
  }, (0,external_wp_i18n_.sprintf)(
  /* translators: %s is the layout name */
  (0,external_wp_i18n_.__)('Width is required for %s layout', 'amp'), ampLayout)), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    type: "number",
    label: (0,external_wp_i18n_.__)('Width (px)', 'amp'),
    value: width !== undefined ? width : '',
    onChange: value => setAttributes({
      width: value
    })
  }), showHeightNotice && (0,external_wp_element_.createElement)(external_wp_components_.Notice, {
    status: "error",
    isDismissible: false
  }, (0,external_wp_i18n_.sprintf)(
  /* translators: %s is the layout name */
  (0,external_wp_i18n_.__)('Height is required for %s layout', 'amp'), ampLayout)), (0,external_wp_element_.createElement)(external_wp_components_.TextControl, {
    type: "number",
    label: (0,external_wp_i18n_.__)('Height (px)', 'amp'),
    value: height,
    onChange: value => setAttributes({
      height: value
    })
  }));
};

/* harmony default export */ var layout_controls = (LayoutControls);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(819);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
// EXTERNAL MODULE: ./assets/src/common/components/select-media-frame.js
var select_media_frame = __webpack_require__(800);
// EXTERNAL MODULE: ./assets/src/common/helpers/index.js + 1 modules
var helpers = __webpack_require__(761);
;// CONCATENATED MODULE: ./assets/src/block-editor/components/with-media-library-notice.js
/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */



const {
  wp
} = window;
/**
 * Gets a wrapped version of MediaUpload to display a notice for small images.
 *
 * Only applies to the MediaUpload in the Featured Image component, PostFeaturedImage.
 *
 * @param {Function} InitialMediaUpload The MediaUpload component, passed from the filter.
 * @param {Object}   minImageDimensions Minimum required image dimensions.
 * @return {Function} The wrapped component.
 */

/* harmony default export */ var with_media_library_notice = ((InitialMediaUpload, minImageDimensions) => {
  if (!(0,external_lodash_.isFunction)(InitialMediaUpload)) {
    return InitialMediaUpload;
  }

  const {
    width: EXPECTED_WIDTH,
    height: EXPECTED_HEIGHT
  } = minImageDimensions;
  /**
   * Mostly copied from customize-controls.js, with slight changes.
   *
   * @see https://github.com/WordPress/wordpress-develop/blob/c80325658f85d24ff82295dd2d55bfdf789f4163/src/js/_enqueues/wp/customize/controls.js#L4695
   * @see wp.media.HeaderControl
   */

  return class FeaturedImageMediaUpload extends InitialMediaUpload {
    /**
     * Constructs the class.
     *
     * @param {*} args Constructor arguments.
     */
    constructor() {
      super(...arguments); // @todo This should be a different event.
      // This class should only be present in the MediaUpload for the Featured Image.

      if ('editor-post-featured-image__media-modal' === this.props.modalClass) {
        this.initFeaturedImage = this.initFeaturedImage.bind(this);
        this.initFeaturedImage();
      } else {
        // Restore the original`onOpen` callback as it will be overridden by the parent class.
        this.frame.off('open', this.onOpen);
        this.frame.on('open', super.onOpen.bind(this));
      }
    }
    /**
     * Initialize.
     *
     * Mainly copied from customize-controls.js, like most of this class.
     *
     * Overwrites the Media Library frame, this.frame.
     * Adds a suggested width and height.
     */


    initFeaturedImage() {
      const FeaturedImageSelectMediaFrame = (0,select_media_frame/* getSelectMediaFrame */.mD)(select_media_frame/* FeaturedImageToolbarSelect */.tb);
      const FeaturedImageLibrary = wp.media.controller.FeaturedImage.extend({
        defaults: { ...wp.media.controller.FeaturedImage.prototype.defaults,
          date: false,
          filterable: false,
          // Note: These suggestions are shown in the media library image browser.
          suggestedWidth: EXPECTED_WIDTH,
          suggestedHeight: EXPECTED_HEIGHT
        }
      });
      this.frame = new FeaturedImageSelectMediaFrame({
        allowedTypes: this.props.allowedTypes,
        state: 'featured-image',
        states: [new FeaturedImageLibrary(), new wp.media.controller.EditImage()]
      });
      this.frame.on('toolbar:create:featured-image', function (toolbar) {
        /**
         * @this wp.media.view.MediaFrame.Select
         */
        this.createSelectToolbar(toolbar, {
          text: wp.media.view.l10n.setFeaturedImage,
          state: this.options.state
        });
      }, this.frame);
      this.frame.on('open', this.onOpen);
      this.frame.state('featured-image').on('select', this.onSelectImage, this); // See wp.media() for this.

      wp.media.frame = this.frame;
    }
    /**
     * Ensure the selected image is the first item in the collection.
     *
     * @see https://github.com/WordPress/gutenberg/blob/c58b32266f8c950c5b9927d286608343078aee02/packages/media-utils/src/components/media-upload/index.js#L401-L417
     */


    onOpen() {
      const frameContent = this.frame.content.get();

      if (frameContent && frameContent.collection) {
        const collection = frameContent.collection; // Clean all attachments we have in memory.

        collection.toArray().forEach(model => model.trigger('destroy', model)); // Reset has more flag, if library had small amount of items all items may have been loaded before.

        collection.mirroring._hasMore = true; // Request items.

        collection.more();
      }
    }
    /**
     * Handles image selection.
     */


    onSelectImage() {
      const attachment = this.frame.state('featured-image').get('selection').first().toJSON();

      const dispatchImage = attachmentId => {
        (0,external_wp_data_.dispatch)('core/editor').editPost({
          featured_media: attachmentId
        });
      };

      const {
        onSelect
      } = this.props;
      const {
        url,
        id,
        width,
        height
      } = attachment;
      (0,helpers/* setImageFromURL */.kX)({
        url,
        id,
        width,
        height,
        onSelect,
        dispatchImage
      });

      if (!wp.media.view.settings.post.featuredImageId) {
        return;
      }

      wp.media.featuredImage.set(attachment ? attachment.id : -1);
    }

  };
});
;// CONCATENATED MODULE: ./assets/src/block-editor/components/index.js




/***/ }),

/***/ 80:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "lm": function() { return /* binding */ addAMPAttributes; },
  "XI": function() { return /* binding */ filterBlocksEdit; },
  "pb": function() { return /* binding */ isAMPEnabled; },
  "qM": function() { return /* binding */ removeAmpFitTextFromBlocks; },
  "VB": function() { return /* binding */ removeClassFromAmpFitTextBlocks; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(819);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
;// CONCATENATED MODULE: ./assets/src/block-editor/constants.js
const TEXT_BLOCKS = ['core/paragraph', 'core/heading', 'core/code', 'core/quote', 'core/subhead'];
// EXTERNAL MODULE: ./assets/src/common/constants.js
var constants = __webpack_require__(669);
;// CONCATENATED MODULE: ./assets/src/block-editor/helpers/index.js


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */






/**
 * Internal dependencies
 */



/**
 * Add AMP attributes to every core block.
 *
 * @param {Object} settings Block settings.
 * @param {string} name     Block name.
 * @return {Object} Modified block settings.
 */

const addAMPAttributes = (settings, name) => {
  if (!(0,external_lodash_.isObject)(settings) || !(0,external_lodash_.isString)(name)) {
    return settings;
  } // AMP Carousel and AMP Lightbox settings.


  if ('core/gallery' === name) {
    var _select2;

    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampCarousel = {
      type: 'boolean',
      default: !((_select2 = (0,external_wp_data_.select)('amp/block-editor')) !== null && _select2 !== void 0 && _select2.hasThemeSupport()) // @todo We could just default this to false now even in Reader mode since block styles are loaded.

    };
    settings.attributes.ampLightbox = {
      type: 'boolean',
      default: false
    };
  } // Add AMP Lightbox settings.


  if ('core/image' === name) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampLightbox = {
      type: 'boolean',
      default: false
    };
  }

  return settings;
};
/**
 * Removes `amp-fit-text` related attributes on blocks via block deprecation.
 *
 * @param {Object} settings Block settings.
 * @param {string} name     Block name.
 * @return {Object} Modified block settings.
 */

const removeAmpFitTextFromBlocks = (settings, name) => {
  if (!(0,external_lodash_.isObject)(settings) || !(0,external_lodash_.isString)(name)) {
    return settings;
  }

  if (TEXT_BLOCKS.includes(name)) {
    if (!settings.deprecated) {
      settings.deprecated = [];
    } // Prevent adding deprecation a second time.


    for (const deprecated of settings.deprecated) {
      if (deprecated.attributes && deprecated.attributes.ampFitText) {
        return settings;
      }
    }

    settings.deprecated.push({
      supports: settings.supports,
      attributes: { ...(settings.attributes || {}),
        ampFitText: {
          type: 'boolean',
          default: false
        },
        minFont: {
          default: constants/* MIN_FONT_SIZE */.CP,
          source: 'attribute',
          selector: 'amp-fit-text',
          attribute: 'min-font-size'
        },
        maxFont: {
          default: constants/* MAX_FONT_SIZE */.uK,
          source: 'attribute',
          selector: 'amp-fit-text',
          attribute: 'max-font-size'
        },
        height: {
          // Needs to be higher than the maximum font size, which defaults to MAX_FONT_SIZE
          default: 'core/image' === name ? 200 : Math.ceil(constants/* MAX_FONT_SIZE */.uK / 10) * 10,
          source: 'attribute',
          selector: 'amp-fit-text',
          attribute: 'height'
        }
      },

      save(props) {
        /* eslint-disable react/prop-types */
        const {
          attributes
        } = props;
        const fitTextProps = {
          layout: 'fixed-height'
        };

        if (attributes.minFont) {
          fitTextProps['min-font-size'] = attributes.minFont;
        }

        if (attributes.maxFont) {
          fitTextProps['max-font-size'] = attributes.maxFont;
        }

        if (attributes.height) {
          fitTextProps.height = attributes.height;
        }
        /* eslint-enable react/prop-types */


        fitTextProps.children = settings.save(props);
        return (0,external_wp_element_.createElement)("amp-fit-text", fitTextProps);
      },

      isEligible(_ref) {
        let {
          ampFitText
        } = _ref;
        return undefined !== ampFitText;
      },

      migrate(attributes) {
        const deprecatedAttrs = ['ampFitText', 'minFont', 'maxFont', 'height'];
        deprecatedAttrs.forEach(attr => delete attributes[attr]);
        return attributes;
      }

    });
  }

  return settings;
};
/**
 * Remove the `class` attribute from `amp-fit-text` elements so that it can be deprecated successfully.
 *
 * The `class` attribute is added by the `core/generated-class-name/save-props` block editor filter; it is unwanted and
 * interferes with successful deprecation of the block. By filtering the saved element the `class` attribute can be
 * removed and the deprecation of the block and proceed without error.
 *
 * @see removeAmpFitTextFromBlocks
 * @param {JSX.Element} element Block save result.
 * @return {JSX.Element} Modified block if it is of `amp-fit-text` type, otherwise the  original element is returned.
 */

const removeClassFromAmpFitTextBlocks = element => {
  if ((0,external_wp_element_.isValidElement)(element) && 'amp-fit-text' === element.type && undefined !== element.props.className) {
    const {
      className,
      ...props
    } = element.props;
    props.className = null;
    element = (0,external_wp_element_.cloneElement)(element, props);
  }

  return element;
};
/**
 * Filters blocks edit function of all blocks.
 *
 * @param {Function} BlockEdit function.
 * @return {Function} Edit function.
 */

const filterBlocksEdit = BlockEdit => {
  if (!(0,external_lodash_.isFunction)(BlockEdit)) {
    return BlockEdit;
  }

  const EnhancedBlockEdit = props => {
    const {
      isSelected,
      name
    } = props;

    if (isSelected && 'core/image' === name) {
      return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(BlockEdit, props), (0,external_wp_element_.createElement)(ImageBlockLayoutAttributes, props));
    }

    if (isSelected && 'core/gallery' === name) {
      return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(BlockEdit, props), (0,external_wp_element_.createElement)(GalleryBlockLayoutAttributes, props));
    }

    return (0,external_wp_element_.createElement)(BlockEdit, props);
  };

  return EnhancedBlockEdit;
};
/**
 * Get AMP Lightbox toggle control.
 *
 * @param {Object} props Props.
 * @return {JSX.Element} Element.
 */

const AmpLightboxToggle = props => {
  const {
    attributes: {
      ampLightbox,
      linkTo
    },
    setAttributes
  } = props;
  return (0,external_wp_element_.createElement)(external_wp_components_.ToggleControl, {
    label: (0,external_wp_i18n_.__)('Add lightbox effect', 'amp'),
    checked: ampLightbox,
    onChange: nextValue => {
      setAttributes({
        ampLightbox: !ampLightbox
      }); // In case of lightbox set linking images to 'none'.

      if (nextValue && linkTo && 'none' !== linkTo) {
        setAttributes({
          linkTo: 'none'
        });
      }
    }
  });
};

/**
 * Get AMP Carousel toggle control.
 *
 * @param {Object}   props                        Props.
 * @param {Object}   props.attributes             Block attributes.
 * @param {Object}   props.attributes.ampCarousel AMP Carousel toggle value.
 * @param {Function} props.setAttributes          Callback to update attributes.
 * @return {Object} Element.
 */
const AmpCarouselToggle = props => {
  const {
    attributes: {
      ampCarousel
    },
    setAttributes
  } = props;
  return (0,external_wp_element_.createElement)(external_wp_components_.ToggleControl, {
    label: (0,external_wp_i18n_.__)('Display as carousel', 'amp'),
    checked: ampCarousel,
    onChange: () => setAttributes({
      ampCarousel: !ampCarousel
    })
  });
};

/**
 * Inspector controls for Image block.
 *
 * @param {Object} props          Props.
 * @param {string} props.clientId Block client ID.
 * @return {Object} Inspector Controls.
 */
const ImageBlockLayoutAttributes = props => {
  const {
    clientId
  } = props;
  const isGalleryBlockChild = (0,external_wp_data_.useSelect)(_select => {
    return _select('core/block-editor').getBlockParentsByBlockName(clientId, 'core/gallery').length > 0;
  }, [clientId]);

  if (isGalleryBlockChild) {
    return null;
  }

  return (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    title: (0,external_wp_i18n_.__)('AMP Settings', 'amp')
  }, (0,external_wp_element_.createElement)(AmpLightboxToggle, props)));
};

/**
 * Inspector controls for Gallery block.
 *
 * @param {Object} props Props.
 * @return {Object} Inspector Controls.
 */
const GalleryBlockLayoutAttributes = props => (0,external_wp_element_.createElement)(external_wp_blockEditor_.InspectorControls, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
  title: (0,external_wp_i18n_.__)('AMP Settings', 'amp')
}, (0,external_wp_element_.createElement)(AmpLightboxToggle, props), (0,external_wp_element_.createElement)(AmpCarouselToggle, props)));
/**
 * Determines whether AMP is enabled for the current post or not.
 *
 * For regular posts, this is based on the AMP toggle control and also
 * the default status based on the template mode.
 *
 * @return {boolean} Whether AMP is enabled.
 */


const isAMPEnabled = () => {
  const {
    getEditedPostAttribute
  } = (0,external_wp_data_.select)('core/editor');
  return getEditedPostAttribute('amp_enabled') || false;
};

/***/ }),

/***/ 806:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ post_status_info_name; },
  "render": function() { return /* binding */ render; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: external ["wp","editPost"]
var external_wp_editPost_ = __webpack_require__(67);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
;// CONCATENATED MODULE: ./assets/src/block-validation/hooks/use-amp-document-toggle.js
/**
 * WordPress dependencies
 */

/**
 * Custom hook providing an easy way to toggle AMP and check if it is enabled.
 */

function useAMPDocumentToggle() {
  const isAMPEnabled = (0,external_wp_data_.useSelect)(select => select('core/editor').getEditedPostAttribute('amp_enabled') || false, []);
  const {
    editPost
  } = (0,external_wp_data_.useDispatch)('core/editor');

  const toggleAMP = () => editPost({
    amp_enabled: !isAMPEnabled
  });

  return {
    isAMPEnabled,
    toggleAMP
  };
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/amp-toggle/index.js


/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */


/**
 * AMP toggle component.
 */

function AMPToggle() {
  const {
    isAMPEnabled,
    toggleAMP
  } = useAMPDocumentToggle();
  /**
   * Use a random ID for the HTML input since the AMP toggle may be used
   * more than once on the same page.
   */

  const htmlId = (0,external_wp_element_.useRef)(`amp-toggle-${Math.random().toString(32).substr(-4)}`);
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)("label", {
    htmlFor: htmlId.current
  }, (0,external_wp_i18n_.__)('Enable AMP', 'amp')), (0,external_wp_element_.createElement)(external_wp_components_.FormToggle, {
    checked: isAMPEnabled,
    onChange: toggleAMP,
    id: htmlId.current
  }));
}
;// CONCATENATED MODULE: ./assets/src/block-editor/plugins/post-status-info.js


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


const post_status_info_name = 'amp-post-status-info';
/**
 * A wrapped AMP toggle component that is rendered for users with disabled Dev Tools.
 */

function WrappedAMPToggle() {
  const isDevToolsEnabled = (0,external_wp_data_.useSelect)(select => select('amp/block-editor').isDevToolsEnabled(), []);
  /**
   * When Dev Tools are enabled the `block-validation` shows the entire AMP
   * sidebar and a notifications area.
   */

  if (isDevToolsEnabled) {
    return null;
  }

  return (0,external_wp_element_.createElement)(external_wp_editPost_.PluginPostStatusInfo, null, (0,external_wp_element_.createElement)(AMPToggle, null));
}

const render = WrappedAMPToggle;

/***/ }),

/***/ 492:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "name": function() { return /* binding */ name; },
/* harmony export */   "render": function() { return /* binding */ render; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(307);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(847);


/**
 * Internal dependencies
 */

const name = 'amp-post-featured-image-pre-publish-panel'; // Add the featured image selection component as a pre-publish check.

const render = () => {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_common_components__WEBPACK_IMPORTED_MODULE_1__/* .PrePublishPanel */ .qI, null);
};

/***/ }),

/***/ 121:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "name": function() { return /* binding */ wrapped_amp_preview_button_name; },
  "onlyPaired": function() { return /* binding */ onlyPaired; },
  "render": function() { return /* binding */ render; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
;// CONCATENATED MODULE: external "React"
var external_React_namespaceObject = window["React"];
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: external ["wp","compose"]
var external_wp_compose_ = __webpack_require__(333);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./assets/src/block-editor/helpers/index.js + 1 modules
var helpers = __webpack_require__(80);
;// CONCATENATED MODULE: ./assets/src/block-editor/components/amp-preview-button.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */






/**
 * Internal dependencies
 */



var ampFilledIcon = function ampFilledIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    d: "M41.629 28.161 28.624 49.804h-2.356l2.33-14.102-7.214.009-.1.002c-.65 0-1.176-.526-1.176-1.176 0-.279.259-.751.259-.751L33.329 12.17l2.395.01-2.388 14.123 7.251-.009h.115c.65 0 1.176.525 1.176 1.175 0 .264-.103.495-.25.691v.001ZM31 0C13.879 0 0 13.88 0 31c0 17.121 13.879 31 31 31 17.12 0 31-13.879 31-31C62 13.88 48.12 0 31 0Z",
    fill: "#82878c"
  }));
};

ampFilledIcon.defaultProps = {
  width: "62",
  height: "62",
  xmlns: "http://www.w3.org/2000/svg"
};

var ampBlackIcon = function ampBlackIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    className: "outer",
    d: "M48 12c19.9 0 36 16.1 36 36S67.9 84 48 84 12 67.9 12 48s16.1-36 36-36",
    fill: "none"
  }), (0,external_wp_element_.createElement)("path", {
    className: "inner",
    d: "M48 33c8.285 0 15 6.716 15 15 0 8.284-6.715 15-15 15-8.284 0-15-6.716-15-15 0-8.284 6.716-15 15-15Zm-1.15 24.098 6.293-10.472a.555.555 0 0 0 .12-.335.569.569 0 0 0-.624-.568l-3.508.004 1.155-6.834-1.159-.005-6.272 10.46s-.125.228-.125.363a.57.57 0 0 0 .617.569l3.49-.005-1.126 6.823h1.14Z",
    fill: "none"
  }));
};

ampBlackIcon.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg"
};
/**
 * Writes the message and graphic in the new preview window that was opened.
 *
 * Forked from the Core component <PostPreviewButton>.
 *
 * @see https://github.com/WordPress/gutenberg/blob/95e769df1f82f6b0ef587d81af65dd2f48cd1c38/packages/editor/src/components/post-preview-button/index.js#L17-L93
 * @param {Document} targetDocument The target document.
 */

function writeInterstitialMessage(targetDocument) {
  let markup = (0,external_wp_element_.renderToString)((0,external_wp_element_.createElement)("div", {
    className: "editor-post-preview-button__interstitial-message"
  }, (0,external_wp_element_.createElement)(external_wp_components_.Icon, {
    icon: ampBlackIcon({
      viewBox: '0 0 98 98'
    })
  }), (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('Generating AMP preview…', 'amp'))));
  markup += `
		<style>
			body {
				margin: 0;
			}
			.editor-post-preview-button__interstitial-message {
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				height: 100vh;
				width: 100vw;
			}
			@-webkit-keyframes paint {
				0% {
					stroke-dashoffset: 0;
				}
			}
			@-moz-keyframes paint {
				0% {
					stroke-dashoffset: 0;
				}
			}
			@-o-keyframes paint {
				0% {
					stroke-dashoffset: 0;
				}
			}
			@keyframes paint {
				0% {
					stroke-dashoffset: 0;
				}
			}
			.editor-post-preview-button__interstitial-message svg {
				width: 198px;
				height: 198px;
				stroke: #555d66;
				stroke-width: 0.75;
			}
			.editor-post-preview-button__interstitial-message svg .outer,
			.editor-post-preview-button__interstitial-message svg .inner {
				stroke-dasharray: 280;
				stroke-dashoffset: 280;
				-webkit-animation: paint 1.5s ease infinite alternate;
				-moz-animation: paint 1.5s ease infinite alternate;
				-o-animation: paint 1.5s ease infinite alternate;
				animation: paint 1.5s ease infinite alternate;
			}
			p {
				text-align: center;
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
			}
		</style>
	`;
  targetDocument.write(markup);
  targetDocument.title = (0,external_wp_i18n_.__)('Generating AMP preview…', 'amp');
  targetDocument.close();
}
/**
 * A 'Preview AMP' button, forked from the Core 'Preview' button: <PostPreviewButton>.
 *
 * @see https://github.com/WordPress/gutenberg/blob/95e769df1f82f6b0ef587d81af65dd2f48cd1c38/packages/editor/src/components/post-preview-button/index.js#L95-L200
 */


class AmpPreviewButton extends external_wp_element_.Component {
  /**
   * Constructs the class.
   *
   * @param {*} args Constructor arguments.
   */
  constructor() {
    super(...arguments);
    this.buttonRef = (0,external_wp_element_.createRef)();
    this.openPreviewWindow = this.openPreviewWindow.bind(this);
  }
  /**
   * Called after the component is updated.
   *
   * @param {Object} prevProps The previous props.
   */


  componentDidUpdate(prevProps) {
    const {
      previewLink
    } = this.props; // This relies on the window being responsible to unset itself when
    // navigation occurs or a new preview window is opened, to avoid
    // unintentional forceful redirects.

    if (previewLink && !prevProps.previewLink) {
      this.setPreviewWindowLink(previewLink);
    }
  }
  /**
   * Sets the preview window's location to the given URL, if a preview window
   * exists and is not closed.
   *
   * @param {string} url URL to assign as preview window location.
   */


  setPreviewWindowLink(url) {
    const {
      previewWindow
    } = this;

    if (previewWindow && !previewWindow.closed) {
      previewWindow.location = url;

      if (this.buttonRef.current) {
        this.buttonRef.current.focus();
      }
    }
  }
  /**
   * Gets the window target.
   */


  getWindowTarget() {
    const {
      postId
    } = this.props;
    return `amp-preview-${postId}`;
  }
  /**
   * Opens the preview window.
   *
   * @param {Event} event The DOM event.
   */


  openPreviewWindow(event) {
    // Our Preview button has its 'href' and 'target' set correctly for a11y
    // purposes. Unfortunately, though, we can't rely on the default 'click'
    // handler since sometimes it incorrectly opens a new tab instead of reusing
    // the existing one.
    // https://github.com/WordPress/gutenberg/pull/8330
    event.preventDefault();
    /** @type {HTMLAnchorElement} target */

    const {
      target
    } = event; // Open up a Preview tab if needed. This is where we'll show the preview.

    if (!this.previewWindow || this.previewWindow.closed) {
      this.previewWindow = window.open('', this.getWindowTarget());
    } // Focus the Preview tab. This might not do anything, depending on the browser's
    // and user's preferences.
    // https://html.spec.whatwg.org/multipage/interaction.html#dom-window-focus


    this.previewWindow.focus(); // If we don't need to autosave the post before previewing, then we simply
    // load the Preview URL in the Preview tab.

    if (!this.props.isAutosaveable) {
      this.setPreviewWindowLink(target.href);
      return;
    } // Request an autosave. This happens asynchronously and causes the component
    // to update when finished.


    if (this.props.isDraft) {
      this.props.savePost({
        isPreview: true
      });
    } else {
      this.props.autosave({
        isPreview: true
      });
    } // Display a 'Generating preview' message in the Preview tab while we wait for the
    // autosave to finish.


    writeInterstitialMessage(this.previewWindow.document);
  }
  /**
   * Renders the component.
   */


  render() {
    const {
      previewLink,
      currentPostLink,
      errorMessages,
      isEnabled,
      isSaveable,
      isStandardMode
    } = this.props; // Link to the `?preview=true` URL if we have it, since this lets us see
    // changes that were autosaved since the post was last published. Otherwise,
    // just link to the post's URL.

    const href = previewLink || currentPostLink;
    return isEnabled && !errorMessages.length && !isStandardMode && (0,external_wp_element_.createElement)(external_wp_components_.Button, {
      className: "amp-editor-post-preview",
      href: href,
      title: (0,external_wp_i18n_.__)('Preview AMP', 'amp'),
      isSecondary: true,
      disabled: !isSaveable,
      onClick: this.openPreviewWindow,
      ref: this.buttonRef
    }, ampFilledIcon({
      viewBox: '0 0 62 62',
      width: 18,
      height: 18
    }), (0,external_wp_element_.createElement)(external_wp_components_.VisuallyHidden, {
      as: "span"
    },
    /* translators: accessibility text */
    (0,external_wp_i18n_.__)('(opens in a new tab)', 'amp')));
  }

}

/* harmony default export */ var amp_preview_button = ((0,external_wp_compose_.compose)([(0,external_wp_data_.withSelect)((select, _ref) => {
  let {
    forcePreviewLink,
    forceIsAutosaveable
  } = _ref;
  const {
    getCurrentPostId,
    getEditedPostAttribute,
    isEditedPostSaveable,
    isEditedPostAutosaveable,
    getEditedPostPreviewLink
  } = select('core/editor');
  const {
    getAmpUrl,
    getAmpPreviewLink,
    getErrorMessages,
    isStandardMode
  } = select('amp/block-editor');

  const copyQueryArgs = (source, destination) => {
    const sourceUrl = new URL(source);
    const destinationUrl = new URL(destination);

    for (const [key, value] of sourceUrl.searchParams.entries()) {
      destinationUrl.searchParams.set(key, value);
    }

    return destinationUrl.href;
  };

  const initialPreviewLink = getEditedPostPreviewLink();
  const previewLink = initialPreviewLink ? copyQueryArgs(initialPreviewLink, getAmpPreviewLink()) : undefined;
  return {
    postId: getCurrentPostId(),
    currentPostLink: getAmpUrl(),
    previewLink: forcePreviewLink !== undefined ? forcePreviewLink : previewLink,
    isSaveable: isEditedPostSaveable(),
    isAutosaveable: forceIsAutosaveable || isEditedPostAutosaveable(),
    isDraft: ['draft', 'auto-draft'].indexOf(getEditedPostAttribute('status')) !== -1,
    isEnabled: (0,helpers/* isAMPEnabled */.pb)(),
    errorMessages: getErrorMessages(),
    isStandardMode: isStandardMode()
  };
}), (0,external_wp_data_.withDispatch)(dispatch => ({
  autosave: dispatch('core/editor').autosave,
  savePost: dispatch('core/editor').savePost
}))])(AmpPreviewButton));
;// CONCATENATED MODULE: ./assets/src/block-editor/plugins/wrapped-amp-preview-button.js


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * A wrapper for the AMP preview button that renders it immediately after the 'Post' preview button, when present.
 */

function WrappedAmpPreviewButton() {
  const root = (0,external_wp_element_.useRef)(null);
  const referenceNode = (0,external_wp_element_.useRef)(null);
  const isViewable = (0,external_wp_data_.useSelect)(select => {
    var _select$getPostType;

    return (_select$getPostType = select('core').getPostType(select('core/editor').getEditedPostAttribute('type'))) === null || _select$getPostType === void 0 ? void 0 : _select$getPostType.viewable;
  }, []);
  (0,external_wp_element_.useEffect)(() => {
    if (!root.current && !referenceNode.current) {
      var _document$querySelect;

      // At first, we try finding the post preview button that is visible only on small screens.
      // If found, we will use its next sibling so that `insertBefore` gets us to the exact location
      // we are looking for.
      referenceNode.current = (_document$querySelect = document.querySelector('.editor-post-preview')) === null || _document$querySelect === void 0 ? void 0 : _document$querySelect.nextSibling; // Since the mobile post preview button is rendered with a delay, we are using the post publish/update
      // button as a fallback. Because it is rendered early, our AMP preview button will be visible immediately.

      if (!referenceNode.current) {
        referenceNode.current = document.querySelector('.editor-post-publish-button');
      }

      if (referenceNode.current) {
        root.current = document.createElement('div');
        root.current.className = 'amp-wrapper-post-preview';
        referenceNode.current.parentNode.insertBefore(root.current, referenceNode.current);
      }
    }

    return () => {
      if (referenceNode.current && root.current) {
        referenceNode.current.parentNode.removeChild(root.current);
        root.current = null;
        referenceNode.current = null;
      }
    }; // We use `isViewable` as a dependency in order to reposition the preview button once the block editor is fully loaded.
  }, [isViewable]); // It is unlikely that AMP would be enabled for a non-viewable post type. This is why the Preview button will
  // always be displayed initially (when `isViewable` is undefined), preventing horizontal layout shift.
  // Once the `isViewable` value is defined (which is after the initial block editor load) and it is `false`,
  // the Preview button will be hidden causing a minor layout shift.

  if (!root.current || isViewable === false) {
    return null;
  }

  return (0,external_wp_element_.createPortal)((0,external_wp_element_.createElement)(amp_preview_button, null), root.current);
}

const wrapped_amp_preview_button_name = 'amp-preview-button-wrapper';
const onlyPaired = true;
const render = WrappedAmpPreviewButton;

/***/ }),

/***/ 847:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "qI": function() { return /* reexport */ pre_publish_panel; },
  "eA": function() { return /* reexport */ with_featured_image_notice; }
});

// UNUSED EXPORTS: withEnforcedFileType

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
;// CONCATENATED MODULE: external ["wp","editor"]
var external_wp_editor_namespaceObject = window["wp"]["editor"];
// EXTERNAL MODULE: external ["wp","editPost"]
var external_wp_editPost_ = __webpack_require__(67);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
;// CONCATENATED MODULE: ./assets/src/common/components/pre-publish-panel.js


/**
 * WordPress dependencies
 */



/**
 * Adds a pre-publish panel containing the featured image selection component.
 *
 * Note: The `PostFeaturedImage` component would have already been filtered to include
 * any notices for the featured image so there is no need to recreate them here.
 *
 * @return {Function} A pre-publish panel containing the featured image selection component.
 */

const PrePublishPanel = () => {
  return (0,external_wp_element_.createElement)(external_wp_editPost_.PluginPrePublishPanel, {
    title: (0,external_wp_i18n_.__)('Featured Image', 'amp'),
    initialOpen: "true"
  }, (0,external_wp_element_.createElement)(external_wp_editor_namespaceObject.PostFeaturedImage, null));
};

/* harmony default export */ var pre_publish_panel = (PrePublishPanel);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(462);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(819);
// EXTERNAL MODULE: external ["wp","compose"]
var external_wp_compose_ = __webpack_require__(333);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/common/helpers/index.js + 1 modules
var helpers = __webpack_require__(761);
;// CONCATENATED MODULE: ./assets/src/common/components/higher-order/with-featured-image-notice.js



/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */


/**
 * Create notice UI for featured image component.
 *
 * @param {string[]} messages Notices.
 * @param {string}   status   Status type of notice.
 * @return {JSX.Element} Notice component.
 */

const createNoticeUI = (messages, status) => {
  return (0,external_wp_element_.createElement)(external_wp_components_.Notice, {
    status: status,
    isDismissible: false
  }, messages.map((message, index) => {
    return (0,external_wp_element_.createElement)("p", {
      key: `message-${index}`
    }, message);
  }));
};
/**
 * Higher-order component that is used for filtering the PostFeaturedImage component.
 *
 * Used to display notices in case the image does not meet minimum requirements.
 *
 * @return {Function} Higher-order component.
 */


/* harmony default export */ var with_featured_image_notice = ((0,external_wp_compose_.createHigherOrderComponent)(PostFeaturedImage => {
  if (!(0,external_lodash_.isFunction)(PostFeaturedImage)) {
    return PostFeaturedImage;
  }

  const withFeaturedImageNotice = props => {
    const {
      media
    } = props;
    let noticeUI;

    if (!media) {
      const message = (0,external_wp_i18n_.__)('Selecting a featured image is recommended for an optimal user experience.', 'amp');

      noticeUI = createNoticeUI([message], 'notice');
    } else {
      const errorMessages = (0,helpers/* validateFeaturedImage */.oV)(media, (0,helpers/* getMinimumFeaturedImageDimensions */.$2)());
      noticeUI = errorMessages ? createNoticeUI(errorMessages, 'warning') : null;
    }

    return (0,external_wp_element_.createElement)(PostFeaturedImage, (0,esm_extends/* default */.Z)({}, props, {
      noticeUI: noticeUI
    }));
  };

  return withFeaturedImageNotice;
}, 'withFeaturedImageNotice'));
// EXTERNAL MODULE: ./assets/src/common/components/select-media-frame.js
var select_media_frame = __webpack_require__(800);
;// CONCATENATED MODULE: ./assets/src/common/components/with-enforced-file-type.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


const {
  wp
} = window;
/**
 * Gets a wrapped version of MediaUpload, to enforce that it has the correct file type.
 *
 * Only intended for the MediaUpload in the Core Video block.
 * Though this will also apply to any other MediaUpload with allowedTypes of [ 'video' ].
 * Partly copied from customize-controls.js.
 *
 * @param {Function} InitialMediaUpload The MediaUpload component, passed from the filter.
 * @return {Function} The wrapped component.
 */

/* harmony default export */ var with_enforced_file_type = (InitialMediaUpload => {
  /**
   * Partly copied from customize-controls.js.
   *
   * @see wp.media.HeaderControl
   */
  return class EnforcedFileTypeMediaUpload extends InitialMediaUpload {
    /**
     * Constructs the class.
     *
     * @param {*} args Constructor arguments.
     */
    constructor() {
      super(...arguments); // This class should only be present when only 'video' types are allowed, like in the Core Video block.

      _defineProperty(this, "initFileTypeMedia", () => {
        const SelectMediaFrame = getSelectMediaFrame(EnforcedFileToolbarSelect);
        const previousOnSelect = this.onSelect;
        const isVideo = isEqual(['video'], this.props.allowedTypes);
        const queryType = isVideo ? 'video/mp4' : this.props.allowedTypes; // For the Video block, only display .mp4 files.

        this.frame = new SelectMediaFrame({
          allowedTypes: this.props.allowedTypes,
          button: {
            text: __('Select', 'amp'),
            close: false
          },
          states: [new wp.media.controller.Library({
            title: __('Select or Upload Media', 'amp'),
            library: wp.media.query({
              type: queryType
            }),
            multiple: false,
            date: false,
            priority: 20
          })]
        });
        wp.media.frame = this.frame;
        this.frame.on('close', () => {
          this.initFileTypeMedia();
        }, this);
        this.frame.on('select', () => {
          if (previousOnSelect) {
            previousOnSelect();
          }

          this.frame.close();
        }, this);
      });

      if (isEqual(['video/mp4'], this.props.allowedTypes)) {
        this.initFileTypeMedia();
      }
    }
    /**
     * Initialize.
     *
     * Mainly copied from customize-controls.js.
     * Overwrites the Media Library frame, this.frame.
     * And checks that the file type is correct.
     *
     * @see wp.media.CroppedImageControl.initFrame
     */


  };
});
;// CONCATENATED MODULE: ./assets/src/common/components/index.js




/***/ }),

/***/ 800:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tb": function() { return /* binding */ FeaturedImageToolbarSelect; },
/* harmony export */   "mD": function() { return /* binding */ getSelectMediaFrame; }
/* harmony export */ });
/* unused harmony exports SelectionFileTypeError, SelectionFileSizeError, EnforcedFileToolbarSelect */
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(819);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(736);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(761);
/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


const {
  wp
} = window;
const NOTICE_CLASSNAME = 'notice notice-warning notice-alt inline';
/**
 * FeaturedImageSelectionError
 *
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

const FeaturedImageSelectionError = wp.media.View.extend({
  className: NOTICE_CLASSNAME,
  template: (() => {
    let message = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.sprintf)(
    /* translators: 1: image width in pixels. 2: image height in pixels. */
    (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('The selected image is too small (%1$s by %2$s pixels).', 'amp'), '{{width}}', '{{height}}');
    message += ' <# if ( minWidth && minHeight ) { #>';
    message += (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.sprintf)(
    /* translators: 1: required minimum width in pixels. 2: required minimum height in pixels. */
    (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('It should have a size of at least %1$s by %2$s pixels.', 'amp'), '{{minWidth}}', '{{minHeight}}');
    message += '<# } else if ( minWidth ) { #>';
    message += (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.sprintf)(
    /* translators: placeholder is required minimum width in pixels. */
    (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('It should have a width of at least %s pixels.', 'amp'), '{{minWidth}}');
    message += '<# } else if ( minHeight ) { #>';
    message += (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.sprintf)(
    /* translators: placeholder is required minimum height in pixels. */
    (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('It should have a height of at least %s pixels.', 'amp'), '{{minHeight}}');
    message += '<# } #>';
    return (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .getNoticeTemplate */ .kM)(message);
  })()
});
/**
 * SelectionFileTypeError
 *
 * Applies if the featured image has the wrong file type, like .mov or .txt.
 * Very similar to the FeaturedImageSelectionError class.
 *
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

const SelectionFileTypeError = wp.media.View.extend({
  className: 'notice notice-warning notice-alt inline',
  template: (() => {
    const message = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.sprintf)(
    /* translators: 1: the selected file type. */
    (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('The selected file mime type, %1$s, is not allowed.', 'amp'), '{{mimeType}}');
    return (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .getNoticeTemplate */ .kM)(message);
  })()
});
/**
 * SelectionFileSizeError
 *
 * Applies when the video size is more than a certain amount of MB per second.
 * Very similar to the FeaturedImageSelectionError class.
 *
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

const SelectionFileSizeError = wp.media.View.extend({
  className: NOTICE_CLASSNAME,
  template: (() => {
    const message = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.sprintf)(
    /* translators: 1: the recommended max MB per second for videos. 2: the actual MB per second of the video. */
    (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('A video size of less than %1$s MB per second is recommended. The selected video is %2$s MB per second.', 'amp'), '{{maxVideoMegabytesPerSecond}}', '{{actualVideoMegabytesPerSecond}}');
    return (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .getNoticeTemplate */ .kM)(message);
  })()
});
/**
 * FeaturedImageToolbarSelect
 *
 * Prevent selection of an image that does not meet the minimum requirements.
 * Also enforces the file type, ensuring that it was in the allowedTypes prop.
 *
 * @augments wp.media.view.Toolbar.Select
 * @augments wp.media.view.Toolbar
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

const FeaturedImageToolbarSelect = wp.media.view.Toolbar.Select.extend({
  /**
   * Refresh the view.
   */
  refresh() {
    wp.media.view.Toolbar.Select.prototype.refresh.call(this);
    const state = this.controller.state();
    const selection = state.get('selection');
    const attachment = selection.models[0];
    const minWidth = state.collection.get('featured-image').get('suggestedWidth');
    const minHeight = state.collection.get('featured-image').get('suggestedHeight');

    if (!attachment || 'image' !== attachment.get('type') || !attachment.get('width') || (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hasMinimumDimensions */ .HG)({
      width: attachment.get('width'),
      height: attachment.get('height')
    }, {
      width: minWidth,
      height: minHeight
    })) {
      this.secondary.unset('select-error');
    } else {
      this.secondary.set('select-error', new FeaturedImageSelectionError({
        minWidth,
        minHeight,
        width: attachment.get('width'),
        height: attachment.get('height')
      }));
    }

    _helpers__WEBPACK_IMPORTED_MODULE_2__/* .enforceFileType.call */ .kC.call(this, attachment, SelectionFileTypeError);
  }

});
/**
 * EnforcedFileToolbarSelect
 *
 * Prevents selecting an attachment that has the wrong file type, like .mov or .txt.
 *
 * @augments wp.media.view.Toolbar.Select
 * @augments wp.media.view.Toolbar
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

const EnforcedFileToolbarSelect = wp.media.view.Toolbar.Select.extend({
  /**
   * Refresh the view.
   */
  refresh() {
    wp.media.view.Toolbar.Select.prototype.refresh.call(this);
    const state = this.controller.state();
    const selection = state.get('selection');
    const attachment = selection.models[0];
    _helpers__WEBPACK_IMPORTED_MODULE_2__/* .enforceFileType.call */ .kC.call(this, attachment, SelectionFileTypeError);
  }

});
/**
 * Gets the select media frame, which displays in the bottom of the Media Library.
 *
 * @param {Object} ToolbarSelect The select toolbar that display at the bottom of the Media Library.
 * @return {Object} ToolbarSelect A wp.media Class that creates a Media Library toolbar.
 */

const getSelectMediaFrame = ToolbarSelect => {
  /**
   * Selects a featured image from the media library.
   *
   * @augments wp.media.view.MediaFrame.Select
   * @augments wp.media.view.MediaFrame
   * @augments wp.media.view.Frame
   * @augments wp.media.View
   * @augments wp.Backbone.View
   * @augments Backbone.View
   * @mixes wp.media.controller.StateMachine
   */
  return wp.media.view.MediaFrame.Select.extend({
    /**
     * Create select toolbar.
     *
     * The only reason for this method is to override the select toolbar view class.
     *
     * @param {Object} toolbar
     * @param {Object} [options={}]
     * @this wp.media.controller.Region
     */
    createSelectToolbar(toolbar, options) {
      options = options || this.options.button || {};
      options.controller = this;
      options = { ...options,
        allowedTypes: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.get)(this, ['options', 'allowedTypes'], null)
      };
      toolbar.view = new ToolbarSelect(options);
    }

  });
};

/***/ }),

/***/ 669:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CP": function() { return /* binding */ MIN_FONT_SIZE; },
/* harmony export */   "uK": function() { return /* binding */ MAX_FONT_SIZE; },
/* harmony export */   "TQ": function() { return /* binding */ FILE_TYPE_ERROR_VIEW; }
/* harmony export */ });
/* unused harmony exports READER, STANDARD, TRANSITIONAL, DEFAULT_MOBILE_BREAKPOINT */
// See https://github.com/ampproject/amphtml/blob/e7a1b3ff97645ec0ec482192205134bd0735943c/extensions/amp-fit-text/0.1/amp-fit-text.js#L81-L85
const MIN_FONT_SIZE = 6;
const MAX_FONT_SIZE = 72;
const FILE_TYPE_ERROR_VIEW = 'select-file-type-error';
const READER = 'reader';
const STANDARD = 'standard';
const TRANSITIONAL = 'transitional';
const DEFAULT_MOBILE_BREAKPOINT = 783;

/***/ }),

/***/ 761:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "kC": function() { return /* binding */ enforceFileType; },
  "$2": function() { return /* binding */ getMinimumFeaturedImageDimensions; },
  "kM": function() { return /* binding */ getNoticeTemplate; },
  "HG": function() { return /* binding */ hasMinimumDimensions; },
  "kX": function() { return /* binding */ setImageFromURL; },
  "oV": function() { return /* binding */ validateFeaturedImage; }
});

// UNUSED EXPORTS: isFileTypeAllowed

// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(819);
;// CONCATENATED MODULE: external "ampBlockEditor"
var external_ampBlockEditor_namespaceObject = ampBlockEditor;
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: ./assets/src/common/constants.js
var constants = __webpack_require__(669);
;// CONCATENATED MODULE: ./assets/src/common/helpers/index.js
/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Determines whether whether the image has the minimum required dimensions.
 *
 * The image should have a width of at least 1200 pixels to satisfy the requirements of Google Search for Schema.org metadata.
 *
 * @param {Object} media             A media object with width and height values.
 * @param {number} media.width       Media width in pixels.
 * @param {number} media.height      Media height in pixels.
 * @param {Object} dimensions        An object with minimum required width and height values.
 * @param {number} dimensions.width  Required media width in pixels.
 * @param {number} dimensions.height Required media height in pixels.
 * @return {boolean} Whether the media has the minimum dimensions.
 */

const hasMinimumDimensions = (media, dimensions) => {
  if (!media || !media.width || !media.height) {
    return false;
  }

  const {
    width,
    height
  } = dimensions;
  return (!width || media.width >= width) && (!height || media.height >= height);
};
/**
 * Get minimum dimensions for a featured image.
 *
 * "Images should be at least 1200 pixels wide.
 * For best results, provide multiple high-resolution images (minimum of 800,000 pixels when multiplying width and height)
 * with the following aspect ratios: 16x9, 4x3, and 1x1."
 *
 * Given this requirement, this function ensures the right aspect ratio.
 * The 16/9 aspect ratio is chosen because it has the smallest height for the given width.
 *
 * @see https://developers.google.com/search/docs/data-types/article#article_types
 * @return {Object} Minimum dimensions including width and height.
 */

const getMinimumFeaturedImageDimensions = () => {
  return {
    width: external_ampBlockEditor_namespaceObject.featuredImageMinimumWidth,
    height: external_ampBlockEditor_namespaceObject.featuredImageMinimumHeight
  };
};
/**
 * Validates the an image based on requirements.
 *
 * @param {Object|null} media                      A media object.
 * @param {string}      media.mime_type            The media item's mime type.
 * @param {Object}      media.media_details        A media details object with width and height values.
 * @param {number}      media.media_details.width  Media width in pixels.
 * @param {number}      media.media_details.height Media height in pixels.
 * @param {Object}      dimensions                 An object with minimum required width and height values.
 * @param {number}      dimensions.width           Minimum required width value.
 * @param {number}      dimensions.height          Minimum required height value.
 * @return {string[]|null} Validation errors, or null if there were no errors.
 */

const validateFeaturedImage = (media, dimensions) => {
  if (!media) {
    return [(0,external_wp_i18n_.__)('Selecting a featured image is required.', 'amp')];
  }

  const errors = [];

  if (!['image/png', 'image/gif', 'image/jpeg', 'image/webp', 'image/svg+xml'].includes(media.mime_type)) {
    errors.push(
    /* translators: List of image formats */
    (0,external_wp_i18n_.sprintf)((0,external_wp_i18n_.__)('The featured image must be of either %1$s, %2$s, %3$s, %4$s, or %5$s format.', 'amp'), 'JPEG', 'PNG', 'GIF', 'WebP', 'SVG'));
  }

  if (!hasMinimumDimensions(media.media_details, dimensions)) {
    const {
      width,
      height
    } = dimensions;

    if (width && height) {
      errors.push(
      /* translators: 1: minimum width, 2: minimum height. */
      (0,external_wp_i18n_.sprintf)((0,external_wp_i18n_.__)('The featured image should have a size of at least %1$s by %2$s pixels.', 'amp'), Math.ceil(width), Math.ceil(height)));
    } else if (dimensions.width) {
      errors.push(
      /* translators: placeholder is minimum width. */
      (0,external_wp_i18n_.sprintf)((0,external_wp_i18n_.__)('The featured image should have a width of at least %s pixels.', 'amp'), Math.ceil(width)));
    } else if (dimensions.height) {
      errors.push(
      /* translators: placeholder is minimum height. */
      (0,external_wp_i18n_.sprintf)((0,external_wp_i18n_.__)('The featured image should have a height of at least %s pixels.', 'amp'), Math.ceil(height)));
    }
  }

  return 0 === errors.length ? null : errors;
};
/**
 * Gets the compiled template for a given notice message.
 *
 * @param {string} message The message to display in the template.
 * @return {Function} compiledTemplate A function accepting the data, which creates a compiled template.
 */

const getNoticeTemplate = message => {
  const errorTemplate = (0,external_lodash_.template)(`<p>${message}</p>`, {
    evaluate: /<#([\s\S]+?)#>/g,
    interpolate: /\{\{\{([\s\S]+?)\}\}\}/g,
    escape: /\{\{([^\}]+?)\}\}(?!\})/g
  });
  return data => {
    return errorTemplate(data);
  };
};
/**
 * Gets whether the file type is allowed.
 *
 * For videos, only supported mime types as defined by the editor settings should be allowed.
 * But the allowedTypes property only has 'video', and it can accidentally allow mime types that are not supported.
 * So this returns false for videos with mime types other than the ones in the editor settings.
 *
 * @param {Object} attachment   The file to evaluate.
 * @param {Array}  allowedTypes The allowed file types.
 * @return {boolean} Whether the file type is allowed.
 */

const isFileTypeAllowed = (attachment, allowedTypes) => {
  const fileType = attachment.get('type');
  const mimeType = attachment.get('mime');

  if (!allowedTypes.includes(fileType) && !allowedTypes.includes(mimeType)) {
    return false;
  }

  return 'video' !== fileType;
};
/**
 * If the attachment has the wrong file type, this displays a notice in the Media Library and disables the 'Select' button.
 *
 * This is not an arrow function so that it can be called with enforceFileType.call( this, foo, bar ).
 *
 * @param {Object} attachment     The selected attachment.
 * @param {Object} SelectionError The error to display.
 */

const enforceFileType = function (attachment, SelectionError) {
  if (!attachment) {
    return;
  }

  const allowedTypes = (0,external_lodash_.get)(this, ['options', 'allowedTypes'], null);
  const selectButton = this.get('select'); // If the file type isn't allowed, display a notice and disable the 'Select' button.

  if (allowedTypes && attachment.get('type') && !isFileTypeAllowed(attachment, allowedTypes)) {
    this.secondary.set(constants/* FILE_TYPE_ERROR_VIEW */.TQ, new SelectionError({
      mimeType: attachment.get('mime')
    }));

    if (selectButton && selectButton.model) {
      selectButton.model.set('disabled', true); // Disable the button to select the file.
    }
  } else {
    this.secondary.unset(constants/* FILE_TYPE_ERROR_VIEW */.TQ);

    if (selectButton && selectButton.model) {
      selectButton.model.set('disabled', false); // Enable the button to select the file.
    }
  }
};
/**
 * Sets the featured image, on selecting it in the Media Library.
 *
 * @param {Object}   args               Arguments.
 * @param {string}   args.url           Image URL.
 * @param {number}   args.id            Attachment ID.
 * @param {number}   args.width         Image width.
 * @param {number}   args.height        Image height.
 * @param {Function} args.onSelect      A function in the MediaUpload component called on selecting the image.
 * @param {Function} args.dispatchImage A function to dispatch the change in image to the store.
 */

const setImageFromURL = _ref => {
  let {
    url,
    id,
    width,
    height,
    onSelect,
    dispatchImage
  } = _ref;
  const data = {};
  data.url = url;
  data.thumbnail_url = url;
  data.timestamp = (0,external_lodash_.now)();

  if (id) {
    data.attachment_id = id;
  }

  if (width) {
    data.width = width;
  }

  if (height) {
    data.height = height;
  }

  onSelect(data); // @todo Does this do anything?

  dispatchImage(id);
};

/***/ }),

/***/ 703:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = __webpack_require__(414);

function emptyFunction() {}
function emptyFunctionWithReset() {}
emptyFunctionWithReset.resetWarningCache = emptyFunction;

module.exports = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      // It is still safe when called from React.
      return;
    }
    var err = new Error(
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
    err.name = 'Invariant Violation';
    throw err;
  };
  shim.isRequired = shim;
  function getShim() {
    return shim;
  };
  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,

    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };

  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ 697:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (false) { var throwOnDirectAccess, ReactIs; } else {
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = __webpack_require__(703)();
}


/***/ }),

/***/ 414:
/***/ (function(module) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ 819:
/***/ (function(module) {

"use strict";
module.exports = window["lodash"];

/***/ }),

/***/ 175:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["blockEditor"];

/***/ }),

/***/ 609:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["components"];

/***/ }),

/***/ 333:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["compose"];

/***/ }),

/***/ 818:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["data"];

/***/ }),

/***/ 67:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["editPost"];

/***/ }),

/***/ 307:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["element"];

/***/ }),

/***/ 736:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["i18n"];

/***/ }),

/***/ 462:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ _extends; }
/* harmony export */ });
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
!function() {
"use strict";

// NAMESPACE OBJECT: ./assets/src/block-editor/store/selectors.js
var selectors_namespaceObject = {};
__webpack_require__.r(selectors_namespaceObject);
__webpack_require__.d(selectors_namespaceObject, {
  "getAmpBlocksInUse": function() { return getAmpBlocksInUse; },
  "getAmpPreviewLink": function() { return getAmpPreviewLink; },
  "getAmpUrl": function() { return getAmpUrl; },
  "getErrorMessages": function() { return getErrorMessages; },
  "hasThemeSupport": function() { return hasThemeSupport; },
  "isDevToolsEnabled": function() { return isDevToolsEnabled; },
  "isStandardMode": function() { return isStandardMode; }
});

;// CONCATENATED MODULE: external ["wp","hooks"]
var external_wp_hooks_namespaceObject = window["wp"]["hooks"];
;// CONCATENATED MODULE: external ["wp","plugins"]
var external_wp_plugins_namespaceObject = window["wp"]["plugins"];
;// CONCATENATED MODULE: external ["wp","blocks"]
var external_wp_blocks_namespaceObject = window["wp"]["blocks"];
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
// EXTERNAL MODULE: ./assets/src/common/components/index.js + 4 modules
var components = __webpack_require__(847);
// EXTERNAL MODULE: ./assets/src/common/helpers/index.js + 1 modules
var helpers = __webpack_require__(761);
// EXTERNAL MODULE: ./assets/src/block-editor/components/index.js + 3 modules
var block_editor_components = __webpack_require__(503);
// EXTERNAL MODULE: ./assets/src/block-editor/helpers/index.js + 1 modules
var block_editor_helpers = __webpack_require__(80);
;// CONCATENATED MODULE: ./assets/src/block-editor/store/selectors.js
/**
 * Returns whether the current theme has AMP support.
 *
 * @param {Object} state Editor state.
 * @return {boolean} Whether the current theme has AMP support.
 */
function hasThemeSupport(state) {
  return Boolean(state.hasThemeSupport);
}
/**
 * Returns whether the current user has the AMP DevTools enabled.
 *
 * @param {Object} state The editor state.
 * @return {boolean} Whether the DevTools are enabled.
 */

function isDevToolsEnabled(state) {
  return state.isDevToolsEnabled;
}
/**
 * Returns whether the current site is in Standard mode (AMP-first) as opposed to Transitional (paired).
 *
 * @param {Object} state Editor state.
 * @return {boolean} Whether the current site is AMP-first.
 */

function isStandardMode(state) {
  return Boolean(state.isStandardMode);
}
/**
 * Returns the AMP validation error messages.
 *
 * @param {Object} state The editor state.
 * @return {string[]} The validation error messages.
 */

function getErrorMessages(state) {
  return state.errorMessages;
}
/**
 * Returns the AMP preview link (URL).
 *
 * @param {Object} state The editor state.
 * @return {string} The AMP preview link URL.
 */

function getAmpPreviewLink(state) {
  return state.ampPreviewLink;
}
/**
 * Returns the AMP URL.
 *
 * @param {Object} state The editor state.
 * @return {string} The AMP URL.
 */

function getAmpUrl(state) {
  return state.ampUrl;
}
/**
 * Returns the list of AMP blocks found in the post.
 *
 * @param {Object} state The editor state.
 * @return {string[]} The list of AMP blocks in post.
 */

function getAmpBlocksInUse(state) {
  return state.ampBlocksInUse;
}
;// CONCATENATED MODULE: ./assets/src/block-editor/store/index.js
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */


/**
 * Module Constants
 */

const MODULE_KEY = 'amp/block-editor';
/* harmony default export */ var store = ((0,external_wp_data_.registerStore)(MODULE_KEY, {
  reducer: state => state,
  selectors: selectors_namespaceObject,
  initialState: { ...window.ampBlockEditor
  }
}));
;// CONCATENATED MODULE: ./assets/src/block-editor/index.js
/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */






const {
  isStandardMode: block_editor_isStandardMode,
  getAmpBlocksInUse: block_editor_getAmpBlocksInUse
} = (0,external_wp_data_.select)('amp/block-editor');

const plugins = __webpack_require__(72);

plugins.keys().forEach(modulePath => {
  const {
    name,
    render,
    icon,
    onlyPaired = false
  } = plugins(modulePath);

  if (onlyPaired && block_editor_isStandardMode()) {
    return;
  }

  (0,external_wp_plugins_namespaceObject.registerPlugin)(name, {
    icon,
    render
  });
});
(0,external_wp_hooks_namespaceObject.addFilter)('blocks.registerBlockType', 'ampEditorBlocks/addAttributes', block_editor_helpers/* addAMPAttributes */.lm);
(0,external_wp_hooks_namespaceObject.addFilter)('blocks.registerBlockType', 'ampEditorBlocks/deprecateAmpFitText', block_editor_helpers/* removeAmpFitTextFromBlocks */.qM);
(0,external_wp_hooks_namespaceObject.addFilter)('blocks.getSaveElement', 'ampEditorBlocks/deprecateAmpFitText/removeMiscAttrs', block_editor_helpers/* removeClassFromAmpFitTextBlocks */.VB);
(0,external_wp_hooks_namespaceObject.addFilter)('editor.BlockEdit', 'ampEditorBlocks/filterEdit', block_editor_helpers/* filterBlocksEdit */.XI, 20);
(0,external_wp_hooks_namespaceObject.addFilter)('editor.PostFeaturedImage', 'ampEditorBlocks/withFeaturedImageNotice', components/* withFeaturedImageNotice */.eA);
(0,external_wp_hooks_namespaceObject.addFilter)('editor.MediaUpload', 'ampEditorBlocks/withMediaLibraryNotice', InitialMediaUpload => (0,block_editor_components/* withMediaLibraryNotice */.kY)(InitialMediaUpload, (0,helpers/* getMinimumFeaturedImageDimensions */.$2)()));
const ampBlocksInUse = block_editor_getAmpBlocksInUse();

const blocks = __webpack_require__(55);

blocks.keys().forEach(modulePath => {
  const {
    name,
    settings
  } = blocks(modulePath);
  const shouldRegister = block_editor_isStandardMode() && ampBlocksInUse.includes(name);

  if (shouldRegister) {
    (0,external_wp_blocks_namespaceObject.registerBlockType)(name, settings);
  }
});
}();
/******/ })()
;