/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 11:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./amp-block-validation.js": 93,
	"./amp-document-setting-panel.js": 877,
	"./amp-pre-publish-panel.js": 327
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 11;

/***/ }),

/***/ 44:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ AMPDocumentStatusNotification; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: external "React"
var external_React_ = __webpack_require__(196);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
// EXTERNAL MODULE: ./assets/src/block-validation/store/index.js
var store = __webpack_require__(883);
// EXTERNAL MODULE: ./assets/src/block-validation/components/icon/index.js
var icon = __webpack_require__(201);
// EXTERNAL MODULE: ./assets/src/block-validation/components/sidebar-notification/index.js + 1 modules
var sidebar_notification = __webpack_require__(361);
// EXTERNAL MODULE: ./assets/src/block-validation/hooks/use-amp-document-toggle.js
var use_amp_document_toggle = __webpack_require__(504);
// EXTERNAL MODULE: ./assets/src/block-validation/hooks/use-errors-fetching-state-changes.js
var use_errors_fetching_state_changes = __webpack_require__(590);
// EXTERNAL MODULE: ./assets/src/block-validation/plugins/amp-block-validation.js + 15 modules
var amp_block_validation = __webpack_require__(93);
;// CONCATENATED MODULE: ./assets/src/block-validation/components/amp-toggle/index.js


/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */


/**
 * AMP toggle component.
 */

function AMPToggle() {
  const {
    isAMPEnabled,
    toggleAMP
  } = (0,use_amp_document_toggle/* useAMPDocumentToggle */.c)();
  /**
   * Use a random ID for the HTML input since the AMP toggle may be used
   * more than once on the same page.
   */

  const htmlId = (0,external_wp_element_.useRef)(`amp-toggle-${Math.random().toString(32).substr(-4)}`);
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)("label", {
    htmlFor: htmlId.current
  }, (0,external_wp_i18n_.__)('Enable AMP', 'amp')), (0,external_wp_element_.createElement)(external_wp_components_.FormToggle, {
    checked: isAMPEnabled,
    onChange: toggleAMP,
    id: htmlId.current
  }));
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/amp-document-status/index.js



/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */

var AMPValidationErrorsKeptIcon = function AMPValidationErrorsKeptIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("g", {
    clipPath: "url(#clip-amp-validation-errors-kept)",
    fill: "#BB522E"
  }, (0,external_wp_element_.createElement)("path", {
    d: "M10.762 2.541c4.4 0 8 3.6 8 8 0 1.6-.5 3-1.2 4.2l1.4 1.5c1.1-1.6 1.8-3.6 1.8-5.7 0-5.5-4.5-10-10-10-2 0-3.9.6-5.5 1.7l1.4 1.5c1.2-.8 2.6-1.2 4.1-1.2ZM.762 10.541c0 5.5 4.5 10 10 10 2.7 0 5.1-1.1 6.9-2.8l-14-14.2c-1.8 1.8-2.9 4.3-2.9 7Zm10 8c-4.4 0-8-3.6-8-8 0-1.5.4-2.8 1.1-4l10.9 10.9c-1.2.7-2.5 1.1-4 1.1Z"
  }), (0,external_wp_element_.createElement)("path", {
    d: "M14.262 9.74c.1 0 .1-.1.1-.2 0-.2-.2-.4-.4-.4h-2l1.6 1.6.7-1ZM12.461 4.541h-.8l-1.6 2.6 1.7 1.7.7-4.3ZM7.462 11.541s-.1.1-.1.2c0 .2.2.4.4.4h2.3l-.8 4.5h.7l2.6-4.1-3.5-3.6-1.6 2.6Z"
  })), (0,external_wp_element_.createElement)("defs", null, (0,external_wp_element_.createElement)("clipPath", {
    id: "clip-amp-validation-errors-kept"
  }, (0,external_wp_element_.createElement)("path", {
    fill: "#fff",
    transform: "translate(.762 .541)",
    d: "M0 0h20v20H0z"
  }))));
};

AMPValidationErrorsKeptIcon.defaultProps = {
  width: "21",
  height: "21",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var BellIcon = function BellIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    fill: "#707070",
    d: "M8 20c1.1 0 2-.9 2-2H6c0 1.1.9 2 2 2zm6-6V9c0-3.07-1.63-5.64-4.5-6.32V2C9.5 1.17 8.83.5 8 .5S6.5 1.17 6.5 2v.68C3.64 3.36 2 5.92 2 9v5l-2 2v1h16v-1l-2-2zm-2 1H4V9c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5v6z"
  }));
};

BellIcon.defaultProps = {
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 16 20"
};







/**
 * AMP document status notification component.
 */

function AMPDocumentStatusNotification() {
  const {
    isAMPEnabled
  } = (0,use_amp_document_toggle/* useAMPDocumentToggle */.c)();
  const {
    isFetchingErrors,
    fetchingErrorsMessage
  } = (0,use_errors_fetching_state_changes/* useErrorsFetchingStateChanges */.P)();
  const {
    openGeneralSidebar,
    closePublishSidebar
  } = (0,external_wp_data_.useDispatch)('core/edit-post');
  const {
    isPostDirty,
    maybeIsPostDirty,
    keptMarkupValidationErrorCount,
    reviewedValidationErrorCount,
    unreviewedValidationErrorCount
  } = (0,external_wp_data_.useSelect)(select => ({
    isPostDirty: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getIsPostDirty(),
    maybeIsPostDirty: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getMaybeIsPostDirty(),
    keptMarkupValidationErrorCount: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getKeptMarkupValidationErrors().length,
    reviewedValidationErrorCount: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getReviewedValidationErrors().length,
    unreviewedValidationErrorCount: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getUnreviewedValidationErrors().length
  }), []);

  if (!isAMPEnabled) {
    return (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(AMPToggle, null));
  }

  if (isFetchingErrors) {
    return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(AMPToggle, null)), (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      message: fetchingErrorsMessage,
      isLoading: true,
      isSmall: true
    }));
  }

  const openBlockValidationSidebar = () => {
    closePublishSidebar();
    openGeneralSidebar(`${amp_block_validation.PLUGIN_NAME}/${amp_block_validation.SIDEBAR_NAME}`);
  };

  if (isPostDirty || maybeIsPostDirty) {
    return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(AMPToggle, null)), (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(BellIcon, null),
      message: maybeIsPostDirty ? (0,external_wp_i18n_.__)('Content may have changed. Trigger validation in the AMP Validation sidebar.', 'amp') : (0,external_wp_i18n_.__)('Content has changed. Trigger validation in the AMP Validation sidebar.', 'amp'),
      isSmall: true
    }), (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(external_wp_components_.Button, {
      onClick: openBlockValidationSidebar,
      isSecondary: true,
      isSmall: true
    }, (0,external_wp_i18n_.__)('Open AMP Validation', 'amp'))));
  }

  if (keptMarkupValidationErrorCount > 0) {
    return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(AMPToggle, null)), (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(AMPValidationErrorsKeptIcon, null),
      message: (0,external_wp_i18n_.sprintf)(
      /* translators: %d is count of validation errors whose invalid markup is kept */
      (0,external_wp_i18n_._n)('AMP is blocked due to %d validation issue marked as kept.', 'AMP is blocked due to %d validation issues marked as kept.', keptMarkupValidationErrorCount, 'amp'), keptMarkupValidationErrorCount),
      isSmall: true
    }), (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(external_wp_components_.Button, {
      onClick: openBlockValidationSidebar,
      isSecondary: true,
      isSmall: true
    }, (0,external_wp_i18n_._n)('Review issue', 'Review issues', keptMarkupValidationErrorCount, 'amp'))));
  }

  if (unreviewedValidationErrorCount > 0) {
    return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(AMPToggle, null)), (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(icon/* StatusIcon */.Jj, {
        broken: true
      }),
      message: // @todo De-duplicate with what is in AMPValidationStatusNotification.
      (0,external_wp_i18n_.sprintf)(
      /* translators: %d is count of unreviewed validation error */
      (0,external_wp_i18n_._n)('AMP is valid, but %d issue needs review.', 'AMP is valid, but %d issues need review.', unreviewedValidationErrorCount, 'amp'), unreviewedValidationErrorCount),
      isSmall: true
    }), (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(external_wp_components_.Button, {
      onClick: openBlockValidationSidebar,
      isSecondary: true,
      isSmall: true
    }, (0,external_wp_i18n_._n)('Review issue', 'Review issues', unreviewedValidationErrorCount, 'amp'))));
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(AMPToggle, null)), (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
    icon: (0,external_wp_element_.createElement)(icon/* StatusIcon */.Jj, null),
    message: // @todo De-duplicate with what is in AMPValidationStatusNotification.
    reviewedValidationErrorCount > 0 ? (0,external_wp_i18n_.sprintf)(
    /* translators: %d is count of unreviewed validation error */
    (0,external_wp_i18n_._n)('AMP is valid. %d issue was reviewed.', 'AMP is valid. %d issues were reviewed.', reviewedValidationErrorCount, 'amp'), reviewedValidationErrorCount) : (0,external_wp_i18n_.__)('No AMP validation issues detected.', 'amp'),
    isSmall: true
  }), reviewedValidationErrorCount > 0 && (0,external_wp_element_.createElement)(external_wp_components_.PanelRow, null, (0,external_wp_element_.createElement)(external_wp_components_.Button, {
    onClick: openBlockValidationSidebar,
    isSecondary: true,
    isSmall: true
  }, (0,external_wp_i18n_.__)('Open AMP Validation', 'amp'))));
}

/***/ }),

/***/ 201:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_4": function() { return /* binding */ ToolbarIcon; },
/* harmony export */   "mE": function() { return /* binding */ MoreMenuIcon; },
/* harmony export */   "Jj": function() { return /* binding */ StatusIcon; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(307);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(697);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);



/**
 * External dependencies
 */

/**
 * Internal dependencies
 */



var AMPLogoIcon = function AMPLogoIcon(props) {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("svg", props, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    fill: "#0075C2",
    d: "m13.3 9.1-4 6.6h-.8l.7-4.3H7c-.2 0-.4-.2-.4-.4 0-.1.1-.2.1-.2l4-6.6h.7l-.7 4.3h2.2c.2 0 .4.2.4.4.1.1 0 .2 0 .2zM10 .5C4.7.5.4 4.8.4 10c0 5.3 4.3 9.5 9.6 9.5s9.6-4.3 9.6-9.5c0-5.3-4.3-9.5-9.6-9.5z"
  }));
};

AMPLogoIcon.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 20 20"
};

var AMPToolbarIcon = function AMPToolbarIcon(props) {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("svg", props, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    d: "M9.863 16.815h-.7l.8-4.5h-2.3c-.2 0-.4-.2-.4-.4 0-.1.1-.2.1-.2l4.2-7h.8l-.8 4.6h2.3c.2 0 .4.2.4.4 0 .1 0 .2-.1.2l-4.3 6.9Zm.8-16.1c-5.5 0-10 4.5-10 10s4.5 10 10 10 10-4.5 10-10-4.5-10-10-10Z"
  }));
};

AMPToolbarIcon.defaultProps = {
  width: "21",
  height: "21",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var AMPToolbarIconBroken = function AMPToolbarIconBroken(props) {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("svg", props, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M.913 10.283c0 5.5 4.5 10 10 10s10-4.5 10-10-4.5-10-10-10-10 4.5-10 10Z",
    fill: "#fff"
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    d: "M10.113 16.383h-.7l.8-4.5h-2.3c-.2 0-.4-.2-.4-.4 0-.1.1-.2.1-.2l4.2-7h.8l-.8 4.6h2.3c.2 0 .4.2.4.4 0 .1 0 .2-.1.2l-4.3 6.9Zm.8-16.1c-5.5 0-10 4.5-10 10s4.5 10 10 10 10-4.5 10-10-4.5-10-10-10Z",
    fill: "#37414B"
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("circle", {
    cx: "10.913",
    cy: "10.283",
    r: "9",
    stroke: "#BB522E",
    strokeWidth: "2"
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    stroke: "#BB522E",
    strokeWidth: "2",
    d: "M16.518 17.346 3.791 4.618"
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    stroke: "#fff",
    strokeWidth: "2",
    d: "M19.805 18.118 3.282 1.249"
  }));
};

AMPToolbarIconBroken.defaultProps = {
  width: "21",
  height: "21",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};
/**
 * Plugin icon.
 *
 * @param {Object}  props
 * @param {boolean} props.hasBadge Whether the icon is showing a number.
 */

function IconSVG(_ref) {
  let {
    hasBadge
  } = _ref;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    className: `amp-toolbar-icon components-menu-items__item-icon${hasBadge ? ' amp-toolbar-icon--has-badge' : ''}`
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(AMPToolbarIcon, null));
}

/**
 * Plugin icon when AMP is broken at the URL.
 *
 * @param {Object}  props
 * @param {boolean} props.hasBadge Whether the icon is showing a number.
 */
function BrokenIconSVG(_ref2) {
  let {
    hasBadge
  } = _ref2;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    className: `amp-toolbar-broken-icon${hasBadge ? ' amp-toolbar-broken-icon--has-badge' : ''}`
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(AMPToolbarIconBroken, null));
}

/**
 * The icon to display in the editor toolbar to toggle the editor sidebar.
 *
 * @param {Object}  props
 * @param {boolean} props.broken Whether AMP is broken at the URL.
 * @param {number}  props.count  The number of new errors at the URL.
 */
function ToolbarIcon(_ref3) {
  let {
    broken = false,
    count
  } = _ref3;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: `amp-plugin-icon ${broken ? 'amp-plugin-icon--broken' : ''}`
  }, broken ? (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(BrokenIconSVG, {
    hasBadge: Boolean(count)
  }) : (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(IconSVG, {
    hasBadge: Boolean(count)
  }), 0 < count && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "amp-error-count-badge"
  }, count));
}

/**
 * The icon to display in the editor more menu.
 */
function MoreMenuIcon() {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(IconSVG, {
    hasBadge: false
  });
}
/**
 * The status icon to display in the editor sidebar area.
 *
 * @param {Object}  props
 * @param {boolean} props.broken Whether AMP is broken at the URL.
 */

function StatusIcon(_ref4) {
  let {
    broken = false
  } = _ref4;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: `amp-status-icon ${broken ? 'amp-status-icon--broken' : ''}`
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(AMPLogoIcon, null));
}

/***/ }),

/***/ 361:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": function() { return /* binding */ SidebarNotification; },
  "Z": function() { return /* binding */ SidebarNotificationsContainer; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/classnames/index.js
var classnames = __webpack_require__(184);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
;// CONCATENATED MODULE: ./assets/src/components/loading/index.js


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Loading indicator.
 *
 * @param {Object}  props        Component props.
 * @param {boolean} props.inline Display indicator as an inline element.
 */
// @todo WIP: Updated design needed.

function Loading(_ref) {
  let {
    inline = false
  } = _ref;
  const Tag = inline ? 'span' : 'div';
  return (0,external_wp_element_.createElement)(Tag, {
    className: classnames_default()('amp-spinner-container', {
      'amp-spinner-container--inline': inline
    })
  }, (0,external_wp_element_.createElement)(external_wp_components_.Spinner, null));
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/sidebar-notification/index.js


/**
 * External dependencies
 */


/**
 * Internal dependencies
 */



/**
 * Notification component used in the block editor sidebar.
 *
 * @param {Object}      props
 * @param {JSX.Element} props.action    Call to action element.
 * @param {JSX.Element} props.icon      Status icon element.
 * @param {boolean}     props.isLoading Flag indicating if it's a loading message.
 * @param {boolean}     props.isSmall   Flag indicating if the notification is small.
 * @param {string}      props.message   Message text.
 */

function SidebarNotification(_ref) {
  let {
    action,
    icon,
    isLoading = false,
    isSmall = false,
    message
  } = _ref;
  const iconElement = isLoading ? (0,external_wp_element_.createElement)(Loading, null) : icon;
  return (0,external_wp_element_.createElement)("div", {
    className: classnames_default()('sidebar-notification', {
      'is-loading': isLoading,
      'is-small': isSmall
    })
  }, iconElement && (0,external_wp_element_.createElement)("div", {
    className: "sidebar-notification__icon"
  }, iconElement), (0,external_wp_element_.createElement)("div", {
    className: "sidebar-notification__content"
  }, (0,external_wp_element_.createElement)("p", null, message), action && (0,external_wp_element_.createElement)("div", {
    className: "sidebar-notification__action"
  }, action)));
}

/**
 * Sidebar notifications container component.
 *
 * @param {Object}  props
 * @param {Object}  props.children Component children.
 * @param {boolean} props.isShady  Flag indicating if the component should have a background.
 */
function SidebarNotificationsContainer(_ref2) {
  let {
    children,
    isShady
  } = _ref2;
  return (0,external_wp_element_.createElement)("div", {
    className: classnames_default()('sidebar-notifications-container', {
      'is-shady': isShady
    })
  }, children);
}

/***/ }),

/***/ 504:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": function() { return /* binding */ useAMPDocumentToggle; }
/* harmony export */ });
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(818);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_0__);
/**
 * WordPress dependencies
 */

/**
 * Custom hook providing an easy way to toggle AMP and check if it is enabled.
 */

function useAMPDocumentToggle() {
  const isAMPEnabled = (0,_wordpress_data__WEBPACK_IMPORTED_MODULE_0__.useSelect)(select => select('core/editor').getEditedPostAttribute('amp_enabled') || false, []);
  const {
    editPost
  } = (0,_wordpress_data__WEBPACK_IMPORTED_MODULE_0__.useDispatch)('core/editor');

  const toggleAMP = () => editPost({
    amp_enabled: !isAMPEnabled
  });

  return {
    isAMPEnabled,
    toggleAMP
  };
}

/***/ }),

/***/ 590:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": function() { return /* binding */ useErrorsFetchingStateChanges; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(307);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(818);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(333);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(736);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(883);
/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */


/**
 * Custom hook providing loading message when validation errors are fetched.
 */

function useErrorsFetchingStateChanges() {
  const [didFetchErrors, setDidFetchErrors] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [fetchingErrorsMessage, setFetchingErrorsMessage] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    isEditedPostNew,
    isFetchingErrors
  } = (0,_wordpress_data__WEBPACK_IMPORTED_MODULE_1__.useSelect)(select => ({
    isEditedPostNew: select('core/editor').isEditedPostNew(),
    isFetchingErrors: select(_store__WEBPACK_IMPORTED_MODULE_4__/* .BLOCK_VALIDATION_STORE_KEY */ .jd).getIsFetchingErrors()
  }), []);
  const wasEditedPostNew = (0,_wordpress_compose__WEBPACK_IMPORTED_MODULE_2__.usePrevious)(isEditedPostNew);
  const wasFetchingErrors = (0,_wordpress_compose__WEBPACK_IMPORTED_MODULE_2__.usePrevious)(isFetchingErrors);
  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (didFetchErrors) {
      return;
    } // Set up the state right after errors fetching has finished.


    if (!isFetchingErrors && wasFetchingErrors) {
      setDidFetchErrors(true);
    }
  }, [didFetchErrors, isFetchingErrors, wasFetchingErrors]);
  /**
   * Display best-suited loading message depending if the post has been
   * already validated or not, or the editor has just been opened.
   */

  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (didFetchErrors) {
      setFetchingErrorsMessage((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Re-validating content.', 'amp'));
    } else if (isEditedPostNew || wasEditedPostNew) {
      setFetchingErrorsMessage((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Validating content.', 'amp'));
    } else if (isFetchingErrors) {
      setFetchingErrorsMessage((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Loading…', 'amp'));
    } else {
      setFetchingErrorsMessage('');
    }
  }, [didFetchErrors, isEditedPostNew, isFetchingErrors, wasEditedPostNew]);
  return {
    isFetchingErrors,
    fetchingErrorsMessage
  };
}

/***/ }),

/***/ 93:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "PLUGIN_ICON": function() { return /* binding */ PLUGIN_ICON; },
  "PLUGIN_NAME": function() { return /* binding */ PLUGIN_NAME; },
  "PLUGIN_TITLE": function() { return /* binding */ PLUGIN_TITLE; },
  "SIDEBAR_NAME": function() { return /* binding */ SIDEBAR_NAME; },
  "default": function() { return /* binding */ AMPBlockValidation; }
});

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(736);
// EXTERNAL MODULE: external ["wp","editPost"]
var external_wp_editPost_ = __webpack_require__(67);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
// EXTERNAL MODULE: ./assets/src/block-validation/store/index.js
var store = __webpack_require__(883);
// EXTERNAL MODULE: ./assets/src/block-validation/components/icon/index.js
var icon = __webpack_require__(201);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-validation/components/sidebar-notification/index.js + 1 modules
var sidebar_notification = __webpack_require__(361);
// EXTERNAL MODULE: external "React"
var external_React_ = __webpack_require__(196);
// EXTERNAL MODULE: ./assets/src/block-validation/hooks/use-errors-fetching-state-changes.js
var use_errors_fetching_state_changes = __webpack_require__(590);
;// CONCATENATED MODULE: ./assets/src/block-validation/components/amp-validation-status/revalidate-notification.js



/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */



var BellIcon = function BellIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    fill: "#707070",
    d: "M8 20c1.1 0 2-.9 2-2H6c0 1.1.9 2 2 2zm6-6V9c0-3.07-1.63-5.64-4.5-6.32V2C9.5 1.17 8.83.5 8 .5S6.5 1.17 6.5 2v.68C3.64 3.36 2 5.92 2 9v5l-2 2v1h16v-1l-2-2zm-2 1H4V9c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5v6z"
  }));
};

BellIcon.defaultProps = {
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 16 20"
};


/**
 * AMP re-validate status message.
 */

function AMPRevalidateNotification() {
  const {
    autosave,
    savePost
  } = (0,external_wp_data_.useDispatch)('core/editor');
  const {
    isFetchingErrors,
    fetchingErrorsMessage
  } = (0,use_errors_fetching_state_changes/* useErrorsFetchingStateChanges */.P)();
  const {
    isDraft,
    isPostDirty,
    maybeIsPostDirty
  } = (0,external_wp_data_.useSelect)(select => ({
    isDraft: ['draft', 'auto-draft'].indexOf(select('core/editor').getEditedPostAttribute('status')) !== -1,
    isPostDirty: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getIsPostDirty(),
    maybeIsPostDirty: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getMaybeIsPostDirty()
  }), []);

  if (isFetchingErrors) {
    return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      message: fetchingErrorsMessage,
      isLoading: true
    });
  }

  if (!isPostDirty && !maybeIsPostDirty) {
    return null;
  }

  return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
    icon: (0,external_wp_element_.createElement)(BellIcon, null),
    message: maybeIsPostDirty ? (0,external_wp_i18n_.__)('Content may have changed.', 'amp') : (0,external_wp_i18n_.__)('Content has changed.', 'amp'),
    action: isDraft ? (0,external_wp_element_.createElement)(external_wp_components_.Button, {
      isLink: true,
      onClick: () => savePost({
        isPreview: true
      })
    }, (0,external_wp_i18n_.__)('Save draft and validate', 'amp')) : (0,external_wp_element_.createElement)(external_wp_components_.Button, {
      isLink: true,
      onClick: () => autosave({
        isPreview: true
      })
    }, (0,external_wp_i18n_.__)('Re-validate', 'amp'))
  });
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/amp-validation-status/status-notification.js



/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */

var AMPValidationErrorsKeptIcon = function AMPValidationErrorsKeptIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("g", {
    clipPath: "url(#clip-amp-validation-errors-kept)",
    fill: "#BB522E"
  }, (0,external_wp_element_.createElement)("path", {
    d: "M10.762 2.541c4.4 0 8 3.6 8 8 0 1.6-.5 3-1.2 4.2l1.4 1.5c1.1-1.6 1.8-3.6 1.8-5.7 0-5.5-4.5-10-10-10-2 0-3.9.6-5.5 1.7l1.4 1.5c1.2-.8 2.6-1.2 4.1-1.2ZM.762 10.541c0 5.5 4.5 10 10 10 2.7 0 5.1-1.1 6.9-2.8l-14-14.2c-1.8 1.8-2.9 4.3-2.9 7Zm10 8c-4.4 0-8-3.6-8-8 0-1.5.4-2.8 1.1-4l10.9 10.9c-1.2.7-2.5 1.1-4 1.1Z"
  }), (0,external_wp_element_.createElement)("path", {
    d: "M14.262 9.74c.1 0 .1-.1.1-.2 0-.2-.2-.4-.4-.4h-2l1.6 1.6.7-1ZM12.461 4.541h-.8l-1.6 2.6 1.7 1.7.7-4.3ZM7.462 11.541s-.1.1-.1.2c0 .2.2.4.4.4h2.3l-.8 4.5h.7l2.6-4.1-3.5-3.6-1.6 2.6Z"
  })), (0,external_wp_element_.createElement)("defs", null, (0,external_wp_element_.createElement)("clipPath", {
    id: "clip-amp-validation-errors-kept"
  }, (0,external_wp_element_.createElement)("path", {
    fill: "#fff",
    transform: "translate(.762 .541)",
    d: "M0 0h20v20H0z"
  }))));
};

AMPValidationErrorsKeptIcon.defaultProps = {
  width: "21",
  height: "21",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




/**
 * AMP validation status notification component.
 */

function AMPValidationStatusNotification() {
  const {
    autosave,
    savePost
  } = (0,external_wp_data_.useDispatch)('core/editor');
  const {
    isFetchingErrors
  } = (0,use_errors_fetching_state_changes/* useErrorsFetchingStateChanges */.P)();
  const {
    fetchingErrorsRequestErrorMessage,
    isDraft,
    isEditedPostNew,
    keptMarkupValidationErrorCount,
    reviewLink,
    supportLink,
    unreviewedValidationErrorCount,
    validationErrorCount
  } = (0,external_wp_data_.useSelect)(select => ({
    fetchingErrorsRequestErrorMessage: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getFetchingErrorsRequestErrorMessage(),
    isDraft: ['draft', 'auto-draft'].indexOf(select('core/editor').getEditedPostAttribute('status')) !== -1,
    isEditedPostNew: select('core/editor').isEditedPostNew(),
    keptMarkupValidationErrorCount: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getKeptMarkupValidationErrors().length,
    reviewLink: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getReviewLink(),
    supportLink: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getSupportLink(),
    unreviewedValidationErrorCount: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getUnreviewedValidationErrors().length,
    validationErrorCount: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getValidationErrors().length
  }), []);

  if (isFetchingErrors) {
    return null;
  }

  if (isEditedPostNew) {
    return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(icon/* StatusIcon */.Jj, null),
      message: (0,external_wp_i18n_.__)('Validation will be checked upon saving.', 'amp')
    });
  }

  const sidebarNotificationAction = reviewLink && (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_components_.ExternalLink, {
    href: reviewLink
  }, (0,external_wp_i18n_.__)('View technical details', 'amp')), (0,external_wp_element_.createElement)("br", null), supportLink && (0,external_wp_element_.createElement)(external_wp_components_.ExternalLink, {
    href: supportLink
  }, (0,external_wp_i18n_.__)('Get Support', 'amp')));

  if (fetchingErrorsRequestErrorMessage) {
    return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(AMPValidationErrorsKeptIcon, null),
      message: fetchingErrorsRequestErrorMessage,
      action: (0,external_wp_element_.createElement)(external_wp_components_.Button, {
        isLink: true,
        onClick: isDraft ? () => savePost({
          isPreview: true
        }) : () => autosave({
          isPreview: true
        })
      }, (0,external_wp_i18n_.__)('Try again', 'amp'))
    });
  }

  if (keptMarkupValidationErrorCount > 0) {
    return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(AMPValidationErrorsKeptIcon, null),
      message: (0,external_wp_i18n_.sprintf)(
      /* translators: %d is count of validation errors whose invalid markup is kept */
      (0,external_wp_i18n_._n)('AMP is disabled due to invalid markup being kept for %d issue.', 'AMP is disabled due to invalid markup being kept for %d issues.', keptMarkupValidationErrorCount, 'amp'), keptMarkupValidationErrorCount),
      action: sidebarNotificationAction
    });
  }

  if (unreviewedValidationErrorCount > 0) {
    return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(icon/* StatusIcon */.Jj, {
        broken: true
      }),
      message: // @todo De-duplicate with what is in AMPDocumentStatusNotification.
      (0,external_wp_i18n_.sprintf)(
      /* translators: %d is count of unreviewed validation error */
      (0,external_wp_i18n_._n)('AMP is valid, but %d issue needs review.', 'AMP is valid, but %d issues need review.', unreviewedValidationErrorCount, 'amp'), unreviewedValidationErrorCount),
      action: sidebarNotificationAction
    });
  }

  if (validationErrorCount > 0) {
    return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
      icon: (0,external_wp_element_.createElement)(icon/* StatusIcon */.Jj, null),
      message: // @todo De-duplicate with what is in AMPDocumentStatusNotification.
      (0,external_wp_i18n_.sprintf)(
      /* translators: %d is count of unreviewed validation error */
      (0,external_wp_i18n_._n)('AMP is valid. %d issue was reviewed.', 'AMP is valid. %d issues were reviewed.', validationErrorCount, 'amp'), validationErrorCount),
      action: sidebarNotificationAction
    });
  } // @todo De-duplicate with what is in AMPDocumentStatusNotification.


  return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotification */.H, {
    icon: (0,external_wp_element_.createElement)(icon/* StatusIcon */.Jj, null),
    message: (0,external_wp_i18n_.__)('No AMP validation issues detected.', 'amp')
  });
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/amp-validation-status/index.js


/**
 * Internal dependencies
 */



function AMPValidationStatus() {
  return (0,external_wp_element_.createElement)(sidebar_notification/* SidebarNotificationsContainer */.Z, {
    isShady: true
  }, (0,external_wp_element_.createElement)(AMPRevalidateNotification, null), (0,external_wp_element_.createElement)(AMPValidationStatusNotification, null));
}
// EXTERNAL MODULE: ./node_modules/classnames/index.js
var classnames = __webpack_require__(184);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external "ampBlockValidation"
var external_ampBlockValidation_ = __webpack_require__(422);
;// CONCATENATED MODULE: ./assets/src/block-validation/components/error/error-type-icon.js



/**
 * External dependencies
 */


/**
 * Internal dependencies
 */

var HTMLErrorIcon = function HTMLErrorIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    d: "m2.45 3.068 3.34 1.178v1.64L.743 3.749V2.365L5.79.227v1.64L2.45 3.068Zm8.19-.017L7.237 1.86V.232l5.104 2.14v1.376L7.236 5.893V4.258l3.405-1.207Z",
    fill: "#fff"
  }));
};

HTMLErrorIcon.defaultProps = {
  width: "13",
  height: "6",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var JSErrorIcon = function JSErrorIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    d: "M3.675.959h1.5v4.9c0 .5-.1.9-.3 1.2-.2.3-.5.6-.8.8-.4.2-.8.3-1.2.3-.8 0-1.3-.2-1.8-.6-.4-.4-.6-.9-.6-1.6h1.5c0 .3.1.6.2.8.1.2.4.2.7.2.3 0 .5-.1.7-.3.2-.2.2-.5.2-.8v-4.9h-.1ZM10.075 6.26c0-.3-.1-.5-.3-.6-.2-.1-.5-.3-1.1-.5-.5-.2-.9-.3-1.2-.5-.8-.4-1.2-1-1.2-1.8 0-.4.1-.7.3-1 .2-.3.5-.5.9-.7.5-.2 1-.3 1.5-.3s1 .1 1.4.3c.4.2.7.4.9.8.2.3.3.7.3 1.1h-1.5c0-.3-.1-.6-.3-.8-.2-.2-.5-.3-.9-.3s-.6.1-.8.2c-.2.2-.3.3-.3.6 0 .2.1.4.3.6.2.2.6.3 1 .4.8.3 1.4.6 1.8.9.4.3.6.8.6 1.4 0 .6-.2 1.1-.7 1.4-.5.4-1.1.5-1.9.5-.5 0-1-.1-1.5-.3-.4-.2-.8-.5-1-.8-.2-.3-.4-.8-.4-1.2h1.5c0 .8.5 1.2 1.4 1.2.3 0 .6-.1.8-.2.3 0 .4-.2.4-.4Z",
    fill: "#fff"
  }));
};

JSErrorIcon.defaultProps = {
  width: "12",
  height: "9",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var CSSErrorIcon = function CSSErrorIcon(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    d: "M4.13 6.46h-1.2l-.4 2.4h-1.1l.4-2.4H.53v-1h1.5l.3-1.7h-1.3v-1h1.5l.4-2.4h1.1l-.4 2.4h1.1l.4-2.4h1.1l-.4 2.4h1.3v1h-1.5l-.3 1.7h1.3v1h-1.5l-.4 2.4h-1.1l.5-2.4Zm-1-1h1.1l.3-1.7h-1.1l-.3 1.7Z",
    fill: "#fff"
  }));
};

CSSErrorIcon.defaultProps = {
  width: "8",
  height: "9",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};
/**
 * Component rendering an icon representing JS, CSS, or HTML.
 *
 * @param {Object} props
 * @param {string} props.type The error type.
 */

function ErrorTypeIcon(_ref) {
  let {
    type
  } = _ref;

  switch (type) {
    case external_ampBlockValidation_.HTML_ATTRIBUTE_ERROR_TYPE:
    case external_ampBlockValidation_.HTML_ELEMENT_ERROR_TYPE:
      return (0,external_wp_element_.createElement)(HTMLErrorIcon, null);

    case external_ampBlockValidation_.JS_ERROR_TYPE:
      return (0,external_wp_element_.createElement)(JSErrorIcon, null);

    case external_ampBlockValidation_.CSS_ERROR_TYPE:
      return (0,external_wp_element_.createElement)(CSSErrorIcon, null);

    default:
      return null;
  }
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/error/error-panel-title.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Panel title component for an individual error.
 *
 * @param {Object}  props            Component props.
 * @param {boolean} props.kept
 * @param {string}  props.title      Title string from error data.
 * @param {Object}  props.error      Error details.
 * @param {string}  props.error.type Error type.
 */

function ErrorPanelTitle(_ref) {
  let {
    kept,
    title,
    error: {
      type
    }
  } = _ref;
  return (0,external_wp_element_.createElement)("div", {
    className: "amp-error__panel-title",
    title: kept ? (0,external_wp_i18n_.__)('This error has been kept, making this URL not AMP-compatible.', 'amp') : ''
  }, (0,external_wp_element_.createElement)("div", {
    className: "amp-error__icons"
  }, type && (0,external_wp_element_.createElement)("div", {
    className: `amp-error__error-type-icon amp-error__error-type-icon--${type === null || type === void 0 ? void 0 : type.replace(/_/g, '-')}`
  }, (0,external_wp_element_.createElement)(ErrorTypeIcon, {
    type: type
  }))), (0,external_wp_element_.createElement)("div", {
    className: "amp-error__title",
    dangerouslySetInnerHTML: {
      /* dangerouslySetInnerHTML reason: WordPress sometimes sends back HTML in error messages. */
      __html: title
    }
  }));
}
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
;// CONCATENATED MODULE: ./assets/src/block-validation/components/error/get-error-source-title.js
/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Retrieve sources keyed by type.
 *
 * @param {Object[]} sources Error source details from the PHP backtrace.
 * @return {{core: *[], plugin: *[], 'mu-plugin': *[], blocks: *[], theme: *[], embed: *[]}} Keyed sources.
 */

function getKeyedSources(sources) {
  const keyedSources = {
    theme: [],
    plugin: [],
    'mu-plugin': [],
    embed: [],
    core: [],
    blocks: []
  };

  if (!(sources !== null && sources !== void 0 && sources.length)) {
    return keyedSources;
  }

  for (const source of sources) {
    if (source.type && source.type in keyedSources) {
      keyedSources[source.type].push(source);
    } else if ('block_name' in source) {
      keyedSources.blocks.push(source);
    }
  }

  return keyedSources;
}
/**
 * Attempts to get the title of the plugin or theme responsible for an error.
 *
 * Adapted from AMP_Validated_URL_Post_Type::render_sources_column PHP method.
 *
 * @param {Object[]} sources Error source details from the PHP backtrace.
 */


function getErrorSourceTitle() {
  let sources = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  const keyedSources = getKeyedSources(sources);
  const output = [];
  const uniquePluginNames = new Set(keyedSources.plugin.map(_ref => {
    let {
      name
    } = _ref;
    return name;
  }));
  const muPluginNames = new Set(keyedSources['mu-plugin'].map(_ref2 => {
    let {
      name
    } = _ref2;
    return name;
  }));
  let combinedPluginNames = [...uniquePluginNames, ...muPluginNames];

  if (combinedPluginNames.length > 1) {
    combinedPluginNames = combinedPluginNames.filter(slug => slug !== 'gutenberg');
  }

  if (1 === combinedPluginNames.length) {
    output.push(external_ampBlockValidation_.pluginNames[combinedPluginNames[0]] || combinedPluginNames[0]);
  } else {
    const pluginCount = uniquePluginNames.size;
    const muPluginCount = muPluginNames.size;

    if (0 < pluginCount) {
      output.push((0,external_wp_i18n_.sprintf)('%1$s (%2$d)', (0,external_wp_i18n_.__)('Plugins', 'amp'), pluginCount));
    }

    if (0 < muPluginCount) {
      output.push((0,external_wp_i18n_.sprintf)('%1$s (%2$d)', (0,external_wp_i18n_.__)('Must-use plugins', 'amp'), muPluginCount));
    }
  }

  if (0 === keyedSources.embed.length) {
    const activeThemeSources = keyedSources.theme.filter(_ref3 => {
      let {
        name
      } = _ref3;
      return external_ampBlockValidation_.themeSlug === name;
    });
    const inactiveThemeSources = keyedSources.theme.filter(_ref4 => {
      let {
        name
      } = _ref4;
      return external_ampBlockValidation_.themeSlug !== name;
    });

    if (0 < activeThemeSources.length) {
      output.push(external_ampBlockValidation_.themeName);
    }

    if (0 < inactiveThemeSources.length) {
      /* translators: placeholder is the slug of an inactive WordPress theme. */
      output.push((0,external_wp_i18n_.__)('Inactive theme(s)', 'amp'));
    }
  }

  if (0 === output.length && 0 < keyedSources.blocks.length) {
    output.push(keyedSources.blocks[0].block_name);
  }

  if (0 === output.length && 0 < keyedSources.embed.length) {
    output.push((0,external_wp_i18n_.__)('Embed', 'amp'));
  }

  if (0 === output.length && 0 < keyedSources.core.length) {
    output.push((0,external_wp_i18n_.__)('Core', 'amp'));
  }

  if (!output.length && sources !== null && sources !== void 0 && sources.length) {
    output.push((0,external_wp_i18n_.__)('Unknown', 'amp'));
  }

  return output.join(', ');
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/error/error-content.js



/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */

var AMPAlert = function AMPAlert(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    d: "m10.075 4.055 6.275 10.842H3.8l6.275-10.842Zm0-3.325L.908 16.564h18.333L10.075.73Zm.833 11.667H9.242v1.667h1.666v-1.667Zm0-5H9.242v3.333h1.666V7.397Z",
    fill: "#BE2C23"
  }));
};

AMPAlert.defaultProps = {
  width: "20",
  height: "17",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var AMPDelete = function AMPDelete(props) {
  return (0,external_wp_element_.createElement)("svg", props, (0,external_wp_element_.createElement)("path", {
    d: "M12.258 9.043 10.49 10.81 8.716 9.043l-1.175 1.175 1.775 1.767-1.767 1.767 1.175 1.175 1.767-1.767 1.767 1.767 1.175-1.175-1.767-1.767 1.767-1.767-1.175-1.175Zm1.15-5.391-.834-.834H8.408l-.834.834H4.658v1.666h11.666V3.652h-2.916Zm-7.917 12.5c0 .916.75 1.666 1.667 1.666h6.666c.917 0 1.667-.75 1.667-1.666v-10h-10v10Zm1.667-8.334h6.666v8.334H7.158V7.818Z",
    fill: "#479696"
  }));
};

AMPDelete.defaultProps = {
  width: "21",
  height: "21",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

/**
 * Display error source title.
 *
 * Error title not directly related to the post content are determined by the `getErrorSourceTitle` helper function.
 * For errors that are generated by blocks in the post content (`clientId` is defined), use the `blockSources` object.
 * The exception is `core/shortcode` block that may be mistakenly attributed to WordPress core while in fact it is
 * generated by a plugin or theme.
 *
 * @param {Object}   props
 * @param {string}   props.clientId      Error client ID.
 * @param {string}   props.blockTypeName Block type name.
 * @param {Object[]} props.sources       List of source objects from the PHP backtrace.
 */

function ErrorSource(_ref) {
  let {
    clientId,
    blockTypeName,
    sources
  } = _ref;
  let source;
  const blockSource = external_ampBlockValidation_.blockSources === null || external_ampBlockValidation_.blockSources === void 0 ? void 0 : external_ampBlockValidation_.blockSources[blockTypeName];

  if (clientId && 'core/shortcode' !== blockTypeName) {
    switch (blockSource === null || blockSource === void 0 ? void 0 : blockSource.type) {
      case 'plugin':
        source = (0,external_wp_i18n_.sprintf)(
        /* translators: %s: plugin name. */
        (0,external_wp_i18n_.__)(`%s (plugin)`, 'amp'), blockSource.title);
        break;

      case 'mu-plugin':
        source = (0,external_wp_i18n_.sprintf)(
        /* translators: %s: plugin name. */
        (0,external_wp_i18n_.__)(`%s (must-use plugin)`, 'amp'), blockSource.title);
        break;

      case 'theme':
        source = (0,external_wp_i18n_.sprintf)(
        /* translators: %s: theme name. */
        (0,external_wp_i18n_.__)(`%s (theme)`, 'amp'), blockSource.title);
        break;

      default:
        source = blockSource === null || blockSource === void 0 ? void 0 : blockSource.title;
        break;
    }
  }

  if (!source) {
    source = getErrorSourceTitle(sources);
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)("dt", null, (0,external_wp_i18n_.__)('Source', 'amp')), (0,external_wp_element_.createElement)("dd", null, source));
}

/**
 * @param {Object} props
 * @param {number} props.status Error status.
 */
function MarkupStatus(_ref2) {
  let {
    status
  } = _ref2;
  let keptRemoved;

  if ([external_ampBlockValidation_.VALIDATION_ERROR_NEW_ACCEPTED_STATUS, external_ampBlockValidation_.VALIDATION_ERROR_ACK_ACCEPTED_STATUS].includes(status)) {
    keptRemoved = (0,external_wp_element_.createElement)("span", {
      className: "amp-error__kept-removed amp-error__kept-removed--removed"
    }, (0,external_wp_i18n_.__)('Removed', 'amp'), (0,external_wp_element_.createElement)("span", null, (0,external_wp_element_.createElement)(AMPDelete, null)));
  } else {
    keptRemoved = (0,external_wp_element_.createElement)("span", {
      className: "amp-error__kept-removed amp-error__kept-removed--kept"
    }, (0,external_wp_i18n_.__)('Kept', 'amp'), (0,external_wp_element_.createElement)("span", null, (0,external_wp_element_.createElement)(AMPAlert, null)));
  }

  let reviewed;

  if ([external_ampBlockValidation_.VALIDATION_ERROR_ACK_ACCEPTED_STATUS, external_ampBlockValidation_.VALIDATION_ERROR_ACK_REJECTED_STATUS].includes(status)) {
    reviewed = (0,external_wp_i18n_.__)('Yes', 'amp');
  } else {
    reviewed = (0,external_wp_i18n_.__)('No', 'amp');
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)("dt", null, (0,external_wp_i18n_.__)('Markup status', 'amp')), (0,external_wp_element_.createElement)("dd", null, keptRemoved), (0,external_wp_element_.createElement)("dt", null, (0,external_wp_i18n_.__)('Reviewed', 'amp')), (0,external_wp_element_.createElement)("dd", null, reviewed));
}

/**
 * @param {Object} props
 * @param {Object} props.blockTypeIcon  Block type icon.
 * @param {string} props.blockTypeTitle Title of the block type.
 */
function BlockType(_ref3) {
  let {
    blockTypeIcon,
    blockTypeTitle
  } = _ref3;
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)("dt", null, (0,external_wp_i18n_.__)('Block type', 'amp')), (0,external_wp_element_.createElement)("dd", null, (0,external_wp_element_.createElement)("span", {
    className: "amp-error__block-type-description"
  }, blockTypeTitle || (0,external_wp_i18n_.__)('unknown', 'amp'), blockTypeIcon && (0,external_wp_element_.createElement)("span", {
    className: "amp-error__block-type-icon"
  }, (0,external_wp_element_.createElement)(external_wp_blockEditor_.BlockIcon, {
    icon: blockTypeIcon
  })))));
}

/**
 * Content inside an error panel.
 *
 * @param {Object}   props               Component props.
 * @param {Object}   props.blockType     Block type details.
 * @param {boolean}  props.isExternal    Flag indicating if the error comes from outside of post content.
 * @param {boolean}  props.removed       Flag indicating if the block has been removed.
 * @param {string}   props.clientId      Block client ID
 * @param {number}   props.status        Number indicating the error status.
 * @param {Object}   props.error         Error details.
 * @param {Object[]} props.error.sources Sources from the PHP backtrace for the error.
 */
function ErrorContent(_ref4) {
  let {
    blockType,
    clientId,
    error: {
      sources
    },
    isExternal,
    removed,
    status
  } = _ref4;
  const blockTypeTitle = blockType === null || blockType === void 0 ? void 0 : blockType.title;
  const blockTypeName = blockType === null || blockType === void 0 ? void 0 : blockType.name;
  const blockTypeIcon = blockType === null || blockType === void 0 ? void 0 : blockType.icon;
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, removed && (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('This error is no longer detected, either because the block was removed or the editor mode was switched.', 'amp')), isExternal && (0,external_wp_element_.createElement)("p", null, (0,external_wp_i18n_.__)('This error comes from outside the content (e.g. header or footer).', 'amp')), (0,external_wp_element_.createElement)("dl", {
    className: "amp-error__details"
  }, !(removed || isExternal) && (0,external_wp_element_.createElement)(BlockType, {
    blockTypeIcon: blockTypeIcon,
    blockTypeTitle: blockTypeTitle
  }), (0,external_wp_element_.createElement)(ErrorSource, {
    blockTypeName: blockTypeName,
    clientId: clientId,
    sources: sources
  }), (0,external_wp_element_.createElement)(MarkupStatus, {
    status: status
  })));
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/error/index.js


/**
 * External dependencies
 */



/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */





/**
 * Component rendering an individual error. Parent component is a <ul>.
 *
 * @param {Object} args          Component props.
 * @param {string} args.clientId
 * @param {number} args.error
 * @param {number} args.status
 * @param {number} args.term_id
 * @param {number} args.title
 */

function Error(_ref) {
  let {
    clientId,
    error,
    status,
    term_id: termId,
    title
  } = _ref;
  const {
    selectBlock
  } = (0,external_wp_data_.useDispatch)('core/block-editor');
  const reviewLink = (0,external_wp_data_.useSelect)(select => select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getReviewLink(), []);
  const reviewed = status === external_ampBlockValidation_.VALIDATION_ERROR_ACK_ACCEPTED_STATUS || status === external_ampBlockValidation_.VALIDATION_ERROR_ACK_REJECTED_STATUS;
  const kept = status === external_ampBlockValidation_.VALIDATION_ERROR_ACK_REJECTED_STATUS || status === external_ampBlockValidation_.VALIDATION_ERROR_NEW_REJECTED_STATUS;
  const isExternal = !Boolean(clientId);
  const {
    blockType,
    removed
  } = (0,external_wp_data_.useSelect)(select => {
    const blockName = select('core/block-editor').getBlockName(clientId);
    return {
      removed: clientId && !blockName,
      blockType: select('core/blocks').getBlockType(blockName)
    };
  }, [clientId]);
  let detailsUrl = null;

  if (reviewLink) {
    detailsUrl = new URL(reviewLink);
    detailsUrl.hash = `#tag-${termId}`;
  }

  const panelClassNames = classnames_default()('amp-error', {
    'amp-error--reviewed': reviewed,
    'amp-error--new': !reviewed,
    'amp-error--removed': removed,
    'amp-error--kept': kept,
    [`error-${clientId}`]: clientId
  });
  return (0,external_wp_element_.createElement)(external_wp_components_.PanelBody, {
    className: panelClassNames,
    title: (0,external_wp_element_.createElement)(ErrorPanelTitle, {
      error: error,
      kept: kept,
      title: title
    }),
    initialOpen: false
  }, (0,external_wp_element_.createElement)(ErrorContent, {
    blockType: blockType,
    clientId: clientId,
    error: error,
    isExternal: isExternal,
    removed: removed,
    status: status
  }), (0,external_wp_element_.createElement)("div", {
    className: "amp-error__actions"
  }, !(removed || isExternal) && (0,external_wp_element_.createElement)(external_wp_components_.Button, {
    className: "amp-error__select-block",
    isSecondary: true,
    onClick: () => {
      selectBlock(clientId);
    }
  }, (0,external_wp_i18n_.__)('Select block', 'amp')), detailsUrl && (0,external_wp_element_.createElement)(external_wp_components_.ExternalLink, {
    href: detailsUrl.href,
    className: "amp-error__details-link"
  }, (0,external_wp_i18n_.__)('View details', 'amp'))));
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/sidebar/index.js


/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */





/**
 * Editor sidebar.
 */

function Sidebar() {
  const {
    setIsShowingReviewed
  } = (0,external_wp_data_.useDispatch)(store/* BLOCK_VALIDATION_STORE_KEY */.jd);
  const {
    displayedErrors,
    hasReviewedValidationErrors,
    isShowingReviewed
  } = (0,external_wp_data_.useSelect)(select => {
    var _select$getReviewedVa;

    const _isShowingReviewed = select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getIsShowingReviewed();

    return {
      displayedErrors: _isShowingReviewed ? select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getValidationErrors() : select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getUnreviewedValidationErrors(),
      hasReviewedValidationErrors: ((_select$getReviewedVa = select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getReviewedValidationErrors()) === null || _select$getReviewedVa === void 0 ? void 0 : _select$getReviewedVa.length) > 0,
      isShowingReviewed: _isShowingReviewed
    };
  }, []);
  /**
   * Focus the first focusable element when the sidebar opens.
   */

  (0,external_wp_element_.useEffect)(() => {
    const element = document.querySelector('.amp-sidebar a, .amp-sidebar button, .amp-sidebar input');

    if (element) {
      element.focus();
    }
  }, []);
  return (0,external_wp_element_.createElement)("div", {
    className: "amp-sidebar"
  }, (0,external_wp_element_.createElement)(AMPValidationStatus, null), 0 < displayedErrors.length && (0,external_wp_element_.createElement)("ul", {
    className: "amp-sidebar__errors-list"
  }, displayedErrors.map((validationError, index) => (0,external_wp_element_.createElement)("li", {
    // Add `index` to key since not all errors have `clientId`.
    key: `${validationError.clientId}${index}`,
    className: "amp-sidebar__errors-list-item"
  }, (0,external_wp_element_.createElement)(Error, validationError)))), hasReviewedValidationErrors && (0,external_wp_element_.createElement)("div", {
    className: "amp-sidebar__options"
  }, (0,external_wp_element_.createElement)(external_wp_components_.Button, {
    isLink: true,
    onClick: () => setIsShowingReviewed(!isShowingReviewed)
  }, isShowingReviewed ? (0,external_wp_i18n_.__)('Hide reviewed issues', 'amp') : (0,external_wp_i18n_.__)('Show reviewed issues', 'amp'))));
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/invalid-block-outline/index.js


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Adds a style rule for all blocks with validation errors.
 */

function InvalidBlockOutline() {
  const validationErrors = (0,external_wp_data_.useSelect)(select => select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getUnreviewedValidationErrors(), []);
  const selectors = (0,external_wp_element_.useMemo)(() => {
    const clientIds = validationErrors.map(_ref => {
      let {
        clientId
      } = _ref;
      return clientId;
    }).filter(clientId => clientId);
    return clientIds.map(clientId => `#block-${clientId}::before`);
  }, [validationErrors]);
  return (0,external_wp_element_.createElement)("style", null, `${selectors.join(',')} {
					border-radius: 9px;
					bottom: -3px;
					box-shadow: 0 0 0 2px #bb522e;
					content: '';
					left: -3px;
					pointer-events: none;
					position: absolute;
					right: -3px;
					top: -3px;
				}`);
}
// EXTERNAL MODULE: external ["wp","compose"]
var external_wp_compose_ = __webpack_require__(333);
;// CONCATENATED MODULE: ./assets/src/block-validation/hooks/use-post-dirty-state-changes.js
/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */


const DELAY_MS = 500;
function usePostDirtyStateChanges() {
  const [content, setContent] = (0,external_wp_element_.useState)(null);
  const [updatedContent, setUpdatedContent] = (0,external_wp_element_.useState)();
  const subscription = (0,external_wp_element_.useRef)(null);
  const {
    setIsPostDirty,
    setMaybeIsPostDirty
  } = (0,external_wp_data_.useDispatch)(store/* BLOCK_VALIDATION_STORE_KEY */.jd);
  const {
    getEditedPostContent,
    hasErrorsFromRemovedBlocks,
    hasActiveMetaboxes,
    isPostDirty,
    isSavingOrPreviewingPost
  } = (0,external_wp_data_.useSelect)(select => ({
    getEditedPostContent: select('core/editor').getEditedPostContent,
    hasErrorsFromRemovedBlocks: Boolean(select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getValidationErrors().find(_ref => {
      let {
        clientId
      } = _ref;
      return clientId && !select('core/block-editor').getBlockName(clientId);
    })),
    hasActiveMetaboxes: select('core/edit-post').hasMetaBoxes(),
    isPostDirty: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getIsPostDirty(),
    isSavingOrPreviewingPost: select('core/editor').isSavingPost() && !select('core/editor').isAutosavingPost() || select('core/editor').isPreviewingPost()
  }), []);
  /**
   * Remove subscription when component is unmounted.
   */

  (0,external_wp_element_.useEffect)(() => () => {
    if (subscription.current) {
      subscription.current();
    }
  }, []);
  /**
   * Post is no longer in a dirty state after save.
   *
   * We're using a separate effect for resetting the flag since the listener
   * gets unsubscribed from the store changes whenever post gets into a dirty
   * state.
   */

  (0,external_wp_element_.useEffect)(() => {
    if (isPostDirty && isSavingOrPreviewingPost) {
      setIsPostDirty(false);
      setContent(null);
    }
  }, [isPostDirty, isSavingOrPreviewingPost, setIsPostDirty]);
  /**
   * Whenever a fresh post content differs from the one that is stored in the
   * state, it's safe to assume that the post is in a dirty state.
   *
   * When the content is null, we're resetting both the `content` and the
   * `updatedContent`.
   */

  (0,external_wp_element_.useEffect)(() => {
    if (content === null) {
      const initialContent = getEditedPostContent();
      setContent(initialContent);
      setUpdatedContent(initialContent);
      return;
    }

    if (updatedContent !== content) {
      setIsPostDirty(true);
    }
  }, [content, getEditedPostContent, setIsPostDirty, updatedContent]);
  /**
   * Post may have changed.
   *
   * In some cases it's hard to tell if a post content has changed or not.
   * Examples are meta box content changes or presence of validation errors
   * which used to be in the content but are no longer found, potentially
   * due to switching from the visual editor to the code editor.
   */

  (0,external_wp_element_.useEffect)(() => {
    setMaybeIsPostDirty(!isPostDirty && (hasActiveMetaboxes || hasErrorsFromRemovedBlocks));
  }, [hasActiveMetaboxes, hasErrorsFromRemovedBlocks, isPostDirty, setMaybeIsPostDirty]);
  /**
   * Keep internal content state in sync with editor state.
   */

  const listener = (0,external_wp_element_.useCallback)(() => {
    setUpdatedContent(getEditedPostContent());
  }, [getEditedPostContent]);
  /**
   * Debounce calls to the store listener for performance reasons.
   */

  const debouncedListener = (0,external_wp_compose_.useDebounce)(listener, DELAY_MS);
  /**
   * Only subscribe to the store changes if the post is not in a dirty state.
   */

  (0,external_wp_element_.useEffect)(() => {
    if (isPostDirty && subscription.current) {
      subscription.current();
      subscription.current = null;
    } else if (!isSavingOrPreviewingPost && !isPostDirty && !subscription.current) {
      subscription.current = (0,external_wp_data_.subscribe)(debouncedListener);
    }
  }, [debouncedListener, isPostDirty, isSavingOrPreviewingPost]);
}
;// CONCATENATED MODULE: external "lodash"
var external_lodash_namespaceObject = window["lodash"];
;// CONCATENATED MODULE: external ["wp","apiFetch"]
var external_wp_apiFetch_namespaceObject = window["wp"]["apiFetch"];
var external_wp_apiFetch_default = /*#__PURE__*/__webpack_require__.n(external_wp_apiFetch_namespaceObject);
;// CONCATENATED MODULE: external ["wp","url"]
var external_wp_url_namespaceObject = window["wp"]["url"];
;// CONCATENATED MODULE: ./assets/src/block-validation/hooks/use-validation-error-state-updates.js
/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */







/**
 * Internal dependencies
 */


/**
 * Attempts to associate a validation error with a block current in the editor.
 *
 * @param {Object}   args
 * @param {Object}   args.validationError Validation error object.
 * @param {Object}   args.source          A single validation error source.
 * @param {number}   args.currentPostId   The ID of the current post.
 * @param {string[]} args.blockOrder      Block client IDs in order.
 * @param {Function} args.getBlock        Store selector to get a block in the current editor by client ID.
 */

function maybeAddClientIdToValidationError(_ref) {
  let {
    validationError,
    source,
    currentPostId,
    blockOrder,
    getBlock
  } = _ref;

  if (!source.block_name || undefined === source.block_content_index) {
    return;
  }

  if (currentPostId !== source.post_id) {
    return;
  } // Look up the block ID by index, assuming the blocks of content in the editor are the same as blocks rendered on frontend.


  const clientId = blockOrder[source.block_content_index];

  if (!clientId) {
    return;
  } // Sanity check that block exists for clientId.


  const block = getBlock(clientId);

  if (!block) {
    return;
  } // Check the block type in case a block is dynamically added/removed via the_content filter to cause alignment error.


  if (block.name !== source.block_name) {
    return;
  }

  validationError.clientId = clientId;
}
/**
 * Custom hook managing state updates through effect hooks.
 *
 * Handling state through a context provider might be preferable in other
 * circumstances, but in this case using a store is necessary because React
 * context is not passed down over slotfills, and we need multiple components
 * within multiple slotfills to have access to the same state.
 */

function useValidationErrorStateUpdates() {
  const [blockOrderBeforeSave, setBlockOrderBeforeSave] = (0,external_wp_element_.useState)([]);
  const [hasRequestedPreview, setHasRequestedPreview] = (0,external_wp_element_.useState)(false);
  const [previousValidationErrors, setPreviousValidationErrors] = (0,external_wp_element_.useState)([]);
  const [shouldValidate, setShouldValidate] = (0,external_wp_element_.useState)(false);
  const {
    setIsFetchingErrors,
    setFetchingErrorsRequestErrorMessage,
    setReviewLink,
    setSupportLink,
    setValidationErrors
  } = (0,external_wp_data_.useDispatch)(store/* BLOCK_VALIDATION_STORE_KEY */.jd);
  const {
    currentPostId,
    getBlock,
    getClientIdsWithDescendants,
    isAutosavingPost,
    isEditedPostNew,
    isPreviewingPost,
    isSavingPost,
    previewLink,
    validationErrors
  } = (0,external_wp_data_.useSelect)(select => ({
    currentPostId: select('core/editor').getCurrentPostId(),
    getBlock: select('core/block-editor').getBlock,
    getClientIdsWithDescendants: select('core/block-editor').getClientIdsWithDescendants,
    isAutosavingPost: select('core/editor').isAutosavingPost(),
    isEditedPostNew: select('core/editor').isEditedPostNew(),
    isPreviewingPost: select('core/editor').isPreviewingPost(),
    isSavingPost: select('core/editor').isSavingPost(),
    previewLink: select('core/editor').getEditedPostPreviewLink(),
    validationErrors: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getValidationErrors()
  }), []);
  const wasEditedPostNew = (0,external_wp_compose_.usePrevious)(isEditedPostNew);
  /**
   * Trigger validation whens editor loads only for existing posts.
   */

  (0,external_wp_element_.useEffect)(() => {
    if (!isEditedPostNew && !wasEditedPostNew) {
      setShouldValidate(true);
    }
  }, [isEditedPostNew, wasEditedPostNew]);
  /**
   * Set flags when a post is being saved.
   *
   * Validation should not be triggered on autosaves with an exception of an
   * autosave initiated by a post preview request (note that "Re-validate now"
   * button in the sidebar issues a post preview request).
   */

  (0,external_wp_element_.useEffect)(() => {
    if (!isSavingPost) {
      return;
    }

    if (isPreviewingPost) {
      setShouldValidate(true);
      setHasRequestedPreview(true);
      return;
    }

    if (isAutosavingPost) {
      return;
    }

    setShouldValidate(true);
  }, [isAutosavingPost, isPreviewingPost, isSavingPost]);
  /**
   * Fetches validation errors for the current post's URL after the editor has
   * loaded and following subsequent saves.
   */

  (0,external_wp_element_.useEffect)(() => {
    if (!shouldValidate) {
      return;
    } // Indicate loading state as soon as post is started to be saved.


    if (isSavingPost) {
      setIsFetchingErrors(true);
      return;
    } // A preview link may not be available right after saving a post.


    if (hasRequestedPreview && !(0,external_wp_url_namespaceObject.isURL)(previewLink)) {
      return;
    }

    const data = {
      id: currentPostId
    };

    if (hasRequestedPreview) {
      data.preview_nonce = (0,external_wp_url_namespaceObject.getQueryArg)(previewLink, 'preview_nonce');
    } // The initial render is not related to `isSavingPost` flag change.
    // Still, we're fetching the errors, so the `isFetchingErrors`
    // flag should be set.


    setIsFetchingErrors(true);
    setShouldValidate(false);
    setHasRequestedPreview(false);
    setFetchingErrorsRequestErrorMessage('');
    setBlockOrderBeforeSave(getClientIdsWithDescendants());
    external_wp_apiFetch_default()({
      path: '/amp/v1/validate-post-url/',
      method: 'POST',
      data
    }).then(newValidation => {
      setValidationErrors(newValidation.results);
      setReviewLink(newValidation.review_link);
      setSupportLink(newValidation.support_link);
    }).catch(error => {
      setFetchingErrorsRequestErrorMessage((error === null || error === void 0 ? void 0 : error.message) || (0,external_wp_i18n_.__)('Whoops! Something went wrong.', 'amp'));
    }).finally(() => {
      setIsFetchingErrors(false);
    });
  }, [currentPostId, getClientIdsWithDescendants, hasRequestedPreview, isSavingPost, previewLink, setFetchingErrorsRequestErrorMessage, setIsFetchingErrors, setReviewLink, setSupportLink, setValidationErrors, shouldValidate]);
  /**
   * Runs an equality check when validation errors are received before running
   * the heavier effect.
   */

  (0,external_wp_element_.useEffect)(() => {
    if (validationErrors && !(0,external_lodash_namespaceObject.isEqual)(previousValidationErrors, validationErrors)) {
      setPreviousValidationErrors(validationErrors);
    }
  }, [previousValidationErrors, validationErrors]);
  /**
   * Adds clientIds to the validation errors that are associated with blocks.
   */

  (0,external_wp_element_.useEffect)(() => {
    const newValidationErrors = previousValidationErrors.map(validationError => {
      var _validationError$erro;

      if (!((_validationError$erro = validationError.error.sources) !== null && _validationError$erro !== void 0 && _validationError$erro.length)) {
        return validationError;
      }

      for (const source of validationError.error.sources) {
        /**
         * The loop can finish if the validation error (which is passed
         * by reference below) has obtained a clientId.
         */
        if ('clientId' in validationError) {
          break;
        }

        maybeAddClientIdToValidationError({
          validationError,
          source,
          getBlock,
          blockOrder: 0 < blockOrderBeforeSave.length ? blockOrderBeforeSave : getClientIdsWithDescendants(),
          // blockOrderBeforeSave may be empty on initial load.
          currentPostId
        });
      }

      return validationError;
    });
    setValidationErrors(newValidationErrors);
  }, [blockOrderBeforeSave, currentPostId, getBlock, getClientIdsWithDescendants, setValidationErrors, previousValidationErrors]);
}
// EXTERNAL MODULE: ./assets/src/block-validation/hooks/use-amp-document-toggle.js
var use_amp_document_toggle = __webpack_require__(504);
;// CONCATENATED MODULE: ./assets/src/block-validation/plugins/amp-block-validation.js


/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */








const PLUGIN_NAME = 'amp-block-validation';
const SIDEBAR_NAME = 'amp-editor-sidebar';
const PLUGIN_TITLE = (0,external_wp_i18n_.__)('AMP Validation', 'amp');
const PLUGIN_ICON = icon/* MoreMenuIcon */.mE;
/**
 * Provides a dedicated sidebar for the plugin, with toggle buttons in the editor toolbar and more menu.
 */

function AMPBlockValidation() {
  const {
    broken,
    errorCount
  } = (0,external_wp_data_.useSelect)(select => {
    var _select$getUnreviewed;

    return {
      broken: select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getAMPCompatibilityBroken(),
      errorCount: ((_select$getUnreviewed = select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getUnreviewedValidationErrors()) === null || _select$getUnreviewed === void 0 ? void 0 : _select$getUnreviewed.length) || 0
    };
  }, []);
  const {
    isAMPEnabled
  } = (0,use_amp_document_toggle/* useAMPDocumentToggle */.c)();
  useValidationErrorStateUpdates();
  usePostDirtyStateChanges();

  if (!isAMPEnabled) {
    return null;
  }

  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, (0,external_wp_element_.createElement)(external_wp_editPost_.PluginSidebarMoreMenuItem, {
    icon: (0,external_wp_element_.createElement)(PLUGIN_ICON, null),
    target: SIDEBAR_NAME
  }, PLUGIN_TITLE), (0,external_wp_element_.createElement)(external_wp_editPost_.PluginSidebar, {
    className: `${PLUGIN_NAME}-sidebar`,
    icon: (0,external_wp_element_.createElement)(icon/* ToolbarIcon */._4, {
      count: errorCount,
      broken: broken
    }),
    name: SIDEBAR_NAME,
    title: PLUGIN_TITLE
  }, (0,external_wp_element_.createElement)(Sidebar, null), (0,external_wp_element_.createElement)(InvalidBlockOutline, null)));
}

/***/ }),

/***/ 877:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PLUGIN_NAME": function() { return /* binding */ PLUGIN_NAME; },
/* harmony export */   "PLUGIN_ICON": function() { return /* binding */ PLUGIN_ICON; },
/* harmony export */   "default": function() { return /* binding */ AMPDocumentSettingPanel; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(307);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(736);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67);
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_amp_document_status__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(44);


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


const PLUGIN_NAME = 'amp-block-validation-document-setting-panel';
const PLUGIN_ICON = '';
/**
 * AMP block validation document settings panel.
 */

function AMPDocumentSettingPanel() {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2__.PluginDocumentSettingPanel, {
    name: PLUGIN_NAME,
    title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('AMP', 'amp'),
    initialOpen: true
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_components_amp_document_status__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, null));
}

/***/ }),

/***/ 327:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PLUGIN_NAME": function() { return /* binding */ PLUGIN_NAME; },
/* harmony export */   "PLUGIN_ICON": function() { return /* binding */ PLUGIN_ICON; },
/* harmony export */   "default": function() { return /* binding */ AMPPrePublishPanel; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(307);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(736);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67);
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_amp_document_status__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(44);


/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


const PLUGIN_NAME = 'amp-block-validation-pre-publish-panel';
const PLUGIN_ICON = '';
/**
 * AMP block validation pre-publish panel.
 */

function AMPPrePublishPanel() {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_2__.PluginPrePublishPanel, {
    title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('AMP', 'amp'),
    initialOpen: true
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_components_amp_document_status__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, null));
}

/***/ }),

/***/ 883:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jd": function() { return /* binding */ BLOCK_VALIDATION_STORE_KEY; },
/* harmony export */   "Y6": function() { return /* binding */ INITIAL_STATE; },
/* harmony export */   "MT": function() { return /* binding */ createStore; }
/* harmony export */ });
/* unused harmony export getStore */
/* harmony import */ var amp_block_validation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(422);
/* harmony import */ var amp_block_validation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(amp_block_validation__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(818);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);
/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


const BLOCK_VALIDATION_STORE_KEY = 'amp/block-validation';
const SET_FETCHING_ERRORS_REQUEST_ERROR_MESSAGE = 'SET_FETCHING_ERRORS_REQUEST_ERROR_MESSAGE';
const SET_IS_FETCHING_ERRORS = 'SET_IS_FETCHING_ERRORS';
const SET_IS_POST_DIRTY = 'SET_IS_POST_DIRTY';
const SET_IS_SHOWING_REVIEWED = 'SET_IS_SHOWING_REVIEWED';
const SET_MAYBE_IS_POST_DIRTY = 'SET_MAYBE_IS_POST_DIRTY';
const SET_REVIEW_LINK = 'SET_REVIEW_LINK';
const SET_SUPPORT_LINK = 'SET_SUPPORT_LINK';
const SET_VALIDATION_ERRORS = 'SET_VALIDATION_ERRORS';
const INITIAL_STATE = {
  ampCompatibilityBroken: false,
  fetchingErrorsRequestErrorMessage: '',
  isPostDirty: false,
  isFetchingErrors: false,
  isShowingReviewed: false,
  keptMarkupValidationErrors: [],
  maybeIsPostDirty: false,
  rawValidationErrors: [],
  reviewLink: null,
  supportLink: null,
  reviewedValidationErrors: [],
  unreviewedValidationErrors: [],
  validationErrors: []
};
function getStore(initialState) {
  return {
    reducer: function () {
      var _action$validationErr;

      let state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
      let action = arguments.length > 1 ? arguments[1] : undefined;

      switch (action.type) {
        case SET_FETCHING_ERRORS_REQUEST_ERROR_MESSAGE:
          return { ...state,
            fetchingErrorsRequestErrorMessage: action.fetchingErrorsRequestErrorMessage
          };

        case SET_IS_FETCHING_ERRORS:
          return { ...state,
            isFetchingErrors: action.isFetchingErrors
          };

        case SET_IS_POST_DIRTY:
          return { ...state,
            isPostDirty: action.isPostDirty
          };

        case SET_IS_SHOWING_REVIEWED:
          return { ...state,
            isShowingReviewed: action.isShowingReviewed
          };

        case SET_MAYBE_IS_POST_DIRTY:
          return { ...state,
            maybeIsPostDirty: action.maybeIsPostDirty
          };

        case SET_REVIEW_LINK:
          return { ...state,
            reviewLink: action.reviewLink
          };

        case SET_SUPPORT_LINK:
          return { ...state,
            supportLink: action.supportLink
          };

        case SET_VALIDATION_ERRORS:
          return { ...state,
            ampCompatibilityBroken: Boolean((_action$validationErr = action.validationErrors.filter(_ref => {
              let {
                status
              } = _ref;
              return status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_NEW_REJECTED_STATUS || status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_ACK_REJECTED_STATUS;
            })) === null || _action$validationErr === void 0 ? void 0 : _action$validationErr.length),
            reviewedValidationErrors: action.validationErrors.filter(_ref2 => {
              let {
                status
              } = _ref2;
              return status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_ACK_ACCEPTED_STATUS || status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_ACK_REJECTED_STATUS;
            }),
            unreviewedValidationErrors: action.validationErrors.filter(_ref3 => {
              let {
                status
              } = _ref3;
              return status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_NEW_ACCEPTED_STATUS || status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_NEW_REJECTED_STATUS;
            }),
            keptMarkupValidationErrors: action.validationErrors.filter(_ref4 => {
              let {
                status
              } = _ref4;
              return status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_NEW_REJECTED_STATUS || status === amp_block_validation__WEBPACK_IMPORTED_MODULE_0__.VALIDATION_ERROR_ACK_REJECTED_STATUS;
            }),
            validationErrors: action.validationErrors
          };

        default:
          return state;
      }
    },
    actions: {
      setFetchingErrorsRequestErrorMessage: fetchingErrorsRequestErrorMessage => ({
        type: SET_FETCHING_ERRORS_REQUEST_ERROR_MESSAGE,
        fetchingErrorsRequestErrorMessage
      }),
      setIsFetchingErrors: isFetchingErrors => ({
        type: SET_IS_FETCHING_ERRORS,
        isFetchingErrors
      }),
      setIsPostDirty: isPostDirty => ({
        type: SET_IS_POST_DIRTY,
        isPostDirty
      }),
      setIsShowingReviewed: isShowingReviewed => ({
        type: SET_IS_SHOWING_REVIEWED,
        isShowingReviewed
      }),
      setMaybeIsPostDirty: maybeIsPostDirty => ({
        type: SET_MAYBE_IS_POST_DIRTY,
        maybeIsPostDirty
      }),
      setReviewLink: reviewLink => ({
        type: SET_REVIEW_LINK,
        reviewLink
      }),
      setSupportLink: supportLink => ({
        type: SET_SUPPORT_LINK,
        supportLink
      }),
      setValidationErrors: validationErrors => ({
        type: SET_VALIDATION_ERRORS,
        validationErrors
      })
    },
    selectors: {
      getAMPCompatibilityBroken: _ref5 => {
        let {
          ampCompatibilityBroken
        } = _ref5;
        return ampCompatibilityBroken;
      },
      getFetchingErrorsRequestErrorMessage: _ref6 => {
        let {
          fetchingErrorsRequestErrorMessage
        } = _ref6;
        return fetchingErrorsRequestErrorMessage;
      },
      getIsFetchingErrors: _ref7 => {
        let {
          isFetchingErrors
        } = _ref7;
        return isFetchingErrors;
      },
      getIsPostDirty: _ref8 => {
        let {
          isPostDirty
        } = _ref8;
        return isPostDirty;
      },
      getIsShowingReviewed: _ref9 => {
        let {
          isShowingReviewed
        } = _ref9;
        return isShowingReviewed;
      },
      getMaybeIsPostDirty: _ref10 => {
        let {
          maybeIsPostDirty
        } = _ref10;
        return maybeIsPostDirty;
      },
      getReviewLink: _ref11 => {
        let {
          reviewLink
        } = _ref11;
        return reviewLink;
      },
      getSupportLink: _ref12 => {
        let {
          supportLink
        } = _ref12;
        return supportLink;
      },
      getReviewedValidationErrors: _ref13 => {
        let {
          reviewedValidationErrors
        } = _ref13;
        return reviewedValidationErrors;
      },
      getUnreviewedValidationErrors: _ref14 => {
        let {
          unreviewedValidationErrors
        } = _ref14;
        return unreviewedValidationErrors;
      },
      getKeptMarkupValidationErrors: _ref15 => {
        let {
          keptMarkupValidationErrors
        } = _ref15;
        return keptMarkupValidationErrors;
      },
      getValidationErrors: _ref16 => {
        let {
          validationErrors
        } = _ref16;
        return validationErrors;
      }
    },
    initialState
  };
}
/**
 * Register the store for block validation.
 *
 * @param {Object} initialState Initial store state.
 */

function createStore(initialState) {
  (0,_wordpress_data__WEBPACK_IMPORTED_MODULE_1__.registerStore)(BLOCK_VALIDATION_STORE_KEY, getStore(initialState));
}

/***/ }),

/***/ 184:
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2018 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
	'use strict';

	var hasOwn = {}.hasOwnProperty;

	function classNames() {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg)) {
				if (arg.length) {
					var inner = classNames.apply(null, arg);
					if (inner) {
						classes.push(inner);
					}
				}
			} else if (argType === 'object') {
				if (arg.toString === Object.prototype.toString) {
					for (var key in arg) {
						if (hasOwn.call(arg, key) && arg[key]) {
							classes.push(key);
						}
					}
				} else {
					classes.push(arg.toString());
				}
			}
		}

		return classes.join(' ');
	}

	if ( true && module.exports) {
		classNames.default = classNames;
		module.exports = classNames;
	} else if (true) {
		// register as 'classnames', consistent with npm package name
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return classNames;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else {}
}());


/***/ }),

/***/ 703:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = __webpack_require__(414);

function emptyFunction() {}
function emptyFunctionWithReset() {}
emptyFunctionWithReset.resetWarningCache = emptyFunction;

module.exports = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      // It is still safe when called from React.
      return;
    }
    var err = new Error(
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
    err.name = 'Invariant Violation';
    throw err;
  };
  shim.isRequired = shim;
  function getShim() {
    return shim;
  };
  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,

    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };

  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ 697:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (false) { var throwOnDirectAccess, ReactIs; } else {
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = __webpack_require__(703)();
}


/***/ }),

/***/ 414:
/***/ (function(module) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ 422:
/***/ (function(module) {

"use strict";
module.exports = ampBlockValidation;

/***/ }),

/***/ 196:
/***/ (function(module) {

"use strict";
module.exports = window["React"];

/***/ }),

/***/ 175:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["blockEditor"];

/***/ }),

/***/ 609:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["components"];

/***/ }),

/***/ 333:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["compose"];

/***/ }),

/***/ 818:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["data"];

/***/ }),

/***/ 67:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["editPost"];

/***/ }),

/***/ 307:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["element"];

/***/ }),

/***/ 736:
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["i18n"];

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
!function() {
"use strict";

;// CONCATENATED MODULE: external ["wp","hooks"]
var external_wp_hooks_namespaceObject = window["wp"]["hooks"];
;// CONCATENATED MODULE: external ["wp","plugins"]
var external_wp_plugins_namespaceObject = window["wp"]["plugins"];
// EXTERNAL MODULE: ./assets/src/block-validation/store/index.js
var store = __webpack_require__(883);
;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}
// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(697);
// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(818);
// EXTERNAL MODULE: external ["wp","compose"]
var external_wp_compose_ = __webpack_require__(333);
// EXTERNAL MODULE: external ["wp","blockEditor"]
var external_wp_blockEditor_ = __webpack_require__(175);
// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(609);
// EXTERNAL MODULE: ./assets/src/block-validation/components/icon/index.js
var icon = __webpack_require__(201);
// EXTERNAL MODULE: ./assets/src/block-validation/plugins/amp-block-validation.js + 15 modules
var amp_block_validation = __webpack_require__(93);
// EXTERNAL MODULE: ./assets/src/block-validation/hooks/use-amp-document-toggle.js
var use_amp_document_toggle = __webpack_require__(504);
;// CONCATENATED MODULE: ./assets/src/block-validation/components/with-amp-toolbar-button/amp-toolbar-button.js


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */




/**
 * AMP button displaying in the block toolbar.
 *
 * @param {Object} props          Component props.
 * @param {string} props.clientId Block Client ID.
 * @param {number} props.count    The number of errors associated with the block.
 */

function AMPToolbarButton(_ref) {
  let {
    clientId,
    count
  } = _ref;
  const {
    openGeneralSidebar
  } = (0,external_wp_data_.useDispatch)('core/edit-post');
  const {
    isAMPEnabled
  } = (0,use_amp_document_toggle/* useAMPDocumentToggle */.c)();

  if (!isAMPEnabled) {
    return null;
  }

  return (0,external_wp_element_.createElement)(external_wp_blockEditor_.BlockControls, null, (0,external_wp_element_.createElement)(external_wp_components_.ToolbarButton, {
    onClick: () => {
      openGeneralSidebar(`${amp_block_validation.PLUGIN_NAME}/${amp_block_validation.SIDEBAR_NAME}`); // eslint-disable-next-line @wordpress/react-no-unsafe-timeout

      setTimeout(() => {
        const buttons = Array.from(document.querySelectorAll(`.error-${clientId} button`));
        const firstButton = buttons[0]; // Ensure all errors are expanded.
        // @todo This would be more elegant if this state were captured in the store?

        buttons.reverse(); // Reverse so that the first one is focused first.

        for (const button of buttons) {
          if ('false' === button.getAttribute('aria-expanded')) {
            button.click();
          }
        } // Make sure the first is scrolled into view.


        if (firstButton) {
          firstButton.scrollIntoView({
            block: 'start',
            inline: 'nearest',
            behavior: 'smooth'
          });
        }
      });
    }
  }, (0,external_wp_element_.createElement)(icon/* ToolbarIcon */._4, {
    count: count
  })));
}
;// CONCATENATED MODULE: ./assets/src/block-validation/components/with-amp-toolbar-button/index.js



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */



/**
 * Adds the AMPToolbarButton to blocks that have one or more unreviewed validation errors.
 *
 * @param {Object}   props
 * @param {Function} props.BlockEdit Block edit function.
 * @param {string}   props.clientId  Client ID.
 */

function BlockEditWithToolbar(props) {
  const {
    BlockEdit,
    clientId
  } = props;
  const count = (0,external_wp_data_.useSelect)(select => (select(store/* BLOCK_VALIDATION_STORE_KEY */.jd).getUnreviewedValidationErrors() || []).filter(_ref => {
    let {
      clientId: validationErrorClientId
    } = _ref;
    return clientId === validationErrorClientId;
  }).length || 0, [clientId]);
  return (0,external_wp_element_.createElement)(external_wp_element_.Fragment, null, 0 < count && (0,external_wp_element_.createElement)(AMPToolbarButton, {
    clientId: clientId,
    count: count
  }), (0,external_wp_element_.createElement)(BlockEdit, props));
}

/**
 * Filters the block edit function of all blocks.
 */
const withAMPToolbarButton = (0,external_wp_compose_.createHigherOrderComponent)(BlockEdit => props => (0,external_wp_element_.createElement)(BlockEditWithToolbar, _extends({}, props, {
  BlockEdit: BlockEdit
})), 'BlockEditWithAMPToolbar');
;// CONCATENATED MODULE: ./assets/src/block-validation/index.js
/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */



(0,store/* createStore */.MT)(store/* INITIAL_STATE */.Y6);

const plugins = __webpack_require__(11);

plugins.keys().forEach(modulePath => {
  const {
    default: render,
    PLUGIN_NAME,
    PLUGIN_ICON
  } = plugins(modulePath);
  (0,external_wp_plugins_namespaceObject.registerPlugin)(PLUGIN_NAME, {
    icon: PLUGIN_ICON,
    render
  });
});
(0,external_wp_hooks_namespaceObject.addFilter)('editor.BlockEdit', 'ampBlockValidation/filterEdit', withAMPToolbarButton, -99);
}();
/******/ })()
;