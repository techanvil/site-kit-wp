/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

;// CONCATENATED MODULE: external ["wp","domReady"]
var external_wp_domReady_namespaceObject = window["wp"]["domReady"];
var external_wp_domReady_default = /*#__PURE__*/__webpack_require__.n(external_wp_domReady_namespaceObject);
;// CONCATENATED MODULE: ./assets/src/admin/paired-browsing/client.js
/**
 * WordPress dependencies
 */

const {
  parent: client_parent,
  ampPairedBrowsingClientData
} = window;
const {
  ampUrl,
  nonAmpUrl,
  isAmpDocument
} = ampPairedBrowsingClientData;
const nonAmpUrlObject = new URL(nonAmpUrl);
/**
 * Modify document for paired browsing.
 */

function modifyDocumentForPairedBrowsing() {
  // Scrolling is not synchronized if `scroll-behavior` is set to `smooth`.
  document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important');

  if (isAmpDocument) {
    // Hide the paired browsing menu item.
    const pairedBrowsingMenuItem = document.getElementById('wp-admin-bar-amp-paired-browsing');

    if (pairedBrowsingMenuItem) {
      pairedBrowsingMenuItem.remove();
    } // Hide menu item to view non-AMP version.


    const ampViewBrowsingItem = document.getElementById('wp-admin-bar-amp-view');

    if (ampViewBrowsingItem) {
      ampViewBrowsingItem.remove();
    }
  } else {
    // No need to show the AMP menu in the Non-AMP window.
    const ampMenuItem = document.getElementById('wp-admin-bar-amp');
    ampMenuItem.remove();
  }
}
/**
 * Send message to app.
 *
 * @param {Window} win  Window.
 * @param {string} type Type.
 * @param {Object} data Data.
 */


function sendMessage(win, type) {
  let data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  win.postMessage({
    type,
    ...data,
    ampPairedBrowsing: true
  }, nonAmpUrlObject.origin // Because the paired browsing app is accessed via the canonical URL.
  );
}

let initialized = false;
/**
 * Receive message.
 *
 * @param {MessageEvent} event
 */

function receiveMessage(event) {
  if (!event.data || !event.data.ampPairedBrowsing || !event.data.type || !event.source || nonAmpUrlObject.origin !== event.origin) {
    return;
  }

  switch (event.data.type) {
    case 'init':
      if (!initialized) {
        initialized = true;
        receiveInit();
      }

      break;

    case 'scroll':
      receiveScroll(event.data);
      break;

    case 'replaceLocation':
      receiveReplaceLocation(event.data);
      break;

    default:
  }
}
/**
 * Send scroll.
 */


function sendScroll() {
  sendMessage(client_parent, 'scroll', {
    x: window.scrollX,
    y: window.scrollY
  });
}
/**
 * Receive scroll.
 *
 * @param {Object} data
 * @param {number} data.x
 * @param {number} data.y
 */


function receiveScroll(_ref) {
  let {
    x,
    y
  } = _ref;
  window.scrollTo(x, y);
}
/**
 * Handle click event.
 *
 * @param {MouseEvent} event
 */


function handleClick(event) {
  const element = event.target;
  const link = element.matches('[href]') ? element : element.closest('[href]');

  if (link) {
    sendMessage(client_parent, 'navigate', {
      href: link.href
    });
  }
}
/**
 * Receive replace location.
 *
 * @param {string} href
 */


function receiveReplaceLocation(_ref2) {
  let {
    href
  } = _ref2;
  window.location.replace(href);
}
/**
 * Send loaded.
 */


function sendLoaded() {
  sendMessage(client_parent, 'loaded', {
    isAmpDocument,
    ampUrl,
    nonAmpUrl,
    documentTitle: document.title
  });
}
/**
 * Send heartbeat.
 */


function sendHeartbeat() {
  sendMessage(client_parent, 'heartbeat');
}
/**
 * Receive init.
 */


function receiveInit() {
  sendHeartbeat();
  setInterval(sendHeartbeat, 500);
  __webpack_require__.g.document.addEventListener('click', handleClick, {
    passive: true
  });
  __webpack_require__.g.addEventListener('scroll', sendScroll, {
    passive: true
  });
  external_wp_domReady_default()(modifyDocumentForPairedBrowsing);
  sendLoaded();
}

__webpack_require__.g.addEventListener('message', receiveMessage);
/******/ })()
;