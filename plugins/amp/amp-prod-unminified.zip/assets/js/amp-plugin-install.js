/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

;// CONCATENATED MODULE: external "ampPlugins"
var external_ampPlugins_namespaceObject = ampPlugins;
;// CONCATENATED MODULE: external "lodash"
var external_lodash_namespaceObject = window["lodash"];
;// CONCATENATED MODULE: external ["wp","domReady"]
var external_wp_domReady_namespaceObject = window["wp"]["domReady"];
var external_wp_domReady_default = /*#__PURE__*/__webpack_require__.n(external_wp_domReady_namespaceObject);
;// CONCATENATED MODULE: external ["wp","i18n"]
var external_wp_i18n_namespaceObject = window["wp"]["i18n"];
;// CONCATENATED MODULE: ./assets/src/admin/amp-plugin-install.js
/**
 * External dependencies
 */
 // From WP inline script.


/**
 * WordPress dependencies
 */



const ampPluginInstall = {
  /**
   * Init function.
   */
  init() {
    if (this.isAmpCompatibleTab()) {
      this.removeAdditionalInfo();
    } else {
      this.addAmpMessage();
    }

    this.addAmpMessageInSearchResult();
  },

  /**
   * Check if "AMP Compatible" tab is open or not.
   *
   * @return {boolean} Is AMP-compatible tab.
   */
  isAmpCompatibleTab() {
    const queryParams = new URLSearchParams(window.location.search.substr(1));
    return queryParams.get('tab') === external_ampPlugins_namespaceObject.AMP_COMPATIBLE;
  },

  /**
   * Add message for AMP Compatibility in AMP-compatible plugins card after search result comes in.
   */
  addAmpMessageInSearchResult() {
    const pluginFilterForm = document.getElementById('plugin-filter');
    const pluginInstallSearch = document.querySelector('.plugin-install-php .wp-filter-search');

    if (!pluginFilterForm || !pluginInstallSearch) {
      return;
    }

    const startSearchResults = (0,external_lodash_namespaceObject.debounce)(() => {
      pluginInstallSearch.removeEventListener('input', startSearchResults, {
        once: true
      }); // For IE 11 which doesn't support once events.
      // Replace the class for our custom AMP-compatible tab once doing a search.

      const wrap = document.querySelector('.plugin-install-tab-amp-compatible');

      if (wrap) {
        wrap.classList.remove('plugin-install-tab-amp-compatible');
        wrap.classList.add('plugin-install-tab-search-result');
      } // Start watching for changes the first time a search is being made.


      const mutationObserver = new MutationObserver(() => {
        this.addAmpMessage();
      });
      mutationObserver.observe(pluginFilterForm, {
        childList: true
      });
    }, 1000); // See timeout in core: <https://github.com/WordPress/WordPress/blob/b87617e2719d114d123a88ed7e489170f0204735/wp-admin/js/updates.js#L2578>

    pluginInstallSearch.addEventListener('input', startSearchResults, {
      once: true
    });
  },

  /**
   * Add message for AMP Compatibility in AMP-compatible plugins card.
   */
  addAmpMessage() {
    for (const pluginSlug of external_ampPlugins_namespaceObject.AMP_PLUGINS) {
      const pluginCardElement = document.querySelector(`.plugin-card.plugin-card-${pluginSlug}`);

      if (!pluginCardElement) {
        continue;
      } // Skip cards that have already been processed.


      if (pluginCardElement.classList.contains('amp-extension-card-message')) {
        continue;
      }

      const messageElement = document.createElement('div');
      const iconElement = document.createElement('span');
      const tooltipElement = document.createElement('span');
      messageElement.classList.add('amp-extension-card-message');
      iconElement.classList.add('amp-logo-icon');
      tooltipElement.classList.add('tooltiptext');
      tooltipElement.append((0,external_wp_i18n_namespaceObject.__)('This is known to work well with the AMP plugin.', 'amp'));
      messageElement.append(iconElement);
      messageElement.append(tooltipElement);
      pluginCardElement.appendChild(messageElement);
    }
  },

  /**
   * Remove the additional info from the plugin card in the "AMP Compatible" tab.
   */
  removeAdditionalInfo() {
    const pluginCardBottom = document.querySelectorAll('.plugin-install-tab-amp-compatible .plugin-card-bottom');

    for (const elementNode of pluginCardBottom) {
      elementNode.remove();
    }
  }

};
external_wp_domReady_default()(() => {
  ampPluginInstall.init();
});
/******/ })()
;